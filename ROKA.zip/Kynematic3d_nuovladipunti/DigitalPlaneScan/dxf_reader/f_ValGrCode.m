function c_Val = f_ValGrCode(grCode,m_GrCode,c_ValAsoc)
%Function from
% FUNCTION dxf = read_dxf(filename)
%
% Author:  Steven Michael (smichael@ll.mit.edu)
%
% Date:    3/10/2005
c_Val = c_ValAsoc(m_GrCode==grCode);
end