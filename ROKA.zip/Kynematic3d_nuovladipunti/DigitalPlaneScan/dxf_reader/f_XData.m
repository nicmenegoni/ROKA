function c_XData = f_XData(grCode,XDatNom,m_GrCode,c_ValAsoc)
%Function from
% FUNCTION dxf = read_dxf(filename)
%
% Author:  Steven Michael (smichael@ll.mit.edu)
%
% Date:    3/10/2005
m_PosXData = find(m_GrCode==1001);
if ~isempty(m_PosXData)
    indInXData = m_PosXData(strmatch(upper(XDatNom),c_ValAsoc(m_PosXData),'exact'));
    m_indFinXData = find(m_GrCode(indInXData+2:end)==1002)+indInXData+1;
    m_IndXData = indInXData+2:m_indFinXData(1)-1;
    c_XData = f_ValGrCode(grCode,m_GrCode(m_IndXData),c_ValAsoc(m_IndXData));
else
    c_XData = {[]};
end
end