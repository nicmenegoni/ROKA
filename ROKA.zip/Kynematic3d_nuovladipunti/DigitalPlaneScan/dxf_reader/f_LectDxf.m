function [c_Poi] = f_LectDxf(pathnameSL,filenameSL)
fId = fopen(fullfile(pathnameSL,filenameSL));
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
c_ValAsoc = textscan(fId,'%d%s','Delimiter','\n');
    fclose(fId);
    % Code Group Matrix
    m_GrCode = c_ValAsoc{1};
    % Associated value String Cell
    c_ValAsoc = c_ValAsoc{2};
    %[m_GrCode,c_ValAsoc] = c_ValAsoc{:};
    m_PosCero = find(m_GrCode==0);
    %Is searched by (0,SECTION),(2,ENTITIES)
    indInSecEnt = strmatch('ENTITIES',c_ValAsoc(m_PosCero(1:end-1)+1),'exact');
    %(0,ENDSEC)
    m_indFinSecEnt = strmatch('ENDSEC',c_ValAsoc(m_PosCero(indInSecEnt:end)),'exact');
    % Entities Position
    m_PosCero = m_PosCero(indInSecEnt:indInSecEnt-1+m_indFinSecEnt(1));
    % Variable initiation
    %accelerate?
    c_Poi = cell(sum(strcmp('POINT',c_ValAsoc(m_PosCero))),2);
    c_Poi = cell(1,2);
    %
    iPoi = 1;

        % Loop on the Entities
    for iEnt = 1:length(m_PosCero)-2
        m_GrCodeEnt = m_GrCode(m_PosCero(iEnt+1):m_PosCero(iEnt+2)-1);
        c_ValAsocEnt = c_ValAsoc(m_PosCero(iEnt+1):m_PosCero(iEnt+2)-1);
        nomEnt = c_ValAsocEnt{1};  %c_ValAsocEnt{m_PosCero(iEnt+1)}
        %In the entitie's name is assumed uppercase
        switch nomEnt
            case 'VERTEX'
                % (X,Y,Z) Position
                c_Poi{iPoi,1} = [str2double(f_ValGrCode(10,m_GrCodeEnt,c_ValAsocEnt)),...
                    str2double(f_ValGrCode(20,m_GrCodeEnt,c_ValAsocEnt)),...
                    str2double(f_ValGrCode(30,m_GrCodeEnt,c_ValAsocEnt))];
                % Layer
                c_Poi(iPoi,2) = f_ValGrCode(8,m_GrCodeEnt,c_ValAsocEnt);
                % Add properties
                %
                iPoi = iPoi+1;
                %case Add Entities
                
                % (X,Y,Z) vertexs
                
                
        end
    end
end

