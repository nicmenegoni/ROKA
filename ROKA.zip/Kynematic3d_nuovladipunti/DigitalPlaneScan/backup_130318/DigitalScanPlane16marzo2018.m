% DIGITAL SCAN PLANE
%This script is a tool for the virtual scan plane anlayis of fractures or
%more in general of discontinuties. This tool works in this way: (a)
%fractures are mapped as polylines and saved as '.dxf' file using
%CloudCompare (CC) v.2.9 or newer; (b)the ScanPlane is traced and saved
%using the same version of CC; (c)from dxf file, fractures plane are fitted
%using a total least square approach and (d) the scanline is plotted using
%its end-points; (d) fractures-scanline intersection are calculated.

%Modifiche:
% - figure con piani dei set intersecati e scanline;
% - aggiunta la lettura delle orientazioni medie dei set da un file.xlsx;
% - corretto il calcolo della spaziatura (gi� da versione 6), cio� corretto
%   l'errore per cui si prendeva una orientazione media del set sbagliata;
% - ora si vuole aggiungere un P21

close all
clear all
%Load fractures and scanline informations
pointcloud=0;% 1=pointcolud plot; 0=no pointcloud
%% 1) LOAD & READ XLSX CIRCULAR FRACTURE DATA

uiwait(msgbox('Select XLSX file to load'));
if ismac %For OSX operative system
    [filename, pathname] = uigetfile({'*.xlsx', 'Select a XLSX file'},'mytitle',...
        '/Volumes/F/DATI/D_data/dottorato/DATI/Antola/Outcrop_models');% <- MODIFY the PATH
elseif ispc % For WINDOWS operative system
    [filename, pathname] = uigetfile({'*.xlsx', 'Select a XLSX file'},'mytitle',...
        'F:\Menegoni\Antola\Outcrop_models');% <- MODIFY the PATH
end
Fracdata=readtable(fullfile(pathname, filename));
n=numel(Fracdata.Dip); %number of rows (= number of plane)

%% 2) LOAD & READ XLSX SET BELONGING DATA
[filenameset, pathnameset] = uigetfile({'*.xlsx', 'Select a XLSX file'},'mytitle',...
    pathname);
Fracset=readtable(fullfile(pathnameset, filenameset));
n=numel(Fracset.Set); %number of rows (= number of plane)


%% 3) DEFINE VARIABLES FOR CALCULATION
dipdir =  Fracdata.DipDirection(:);%Dip direction
dip =  Fracdata.Dip(:);%Dip angle
xyz = [Fracdata.Xcenter(:), Fracdata.Ycenter(:), Fracdata.Zcenter(:)];
Nxyz = [Fracdata.Nx(:),Fracdata.Ny(:),Fracdata.Nz(:)];
radius = Fracdata.Radius(:);
Set = Fracset.Set;
Set(isnan(Set)) = max(Set)+1;
nplane=n;
Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};% define color for set from 1 to 7


%% 4) DEFINE MEAN ORIENTATIONS OF THE SETS and DRAW STEREOPLOTS
%Steroplot of poles of disconinuities--------------------------------------
[xp, yp]=Stereogram_colourless_Schmidt(dipdir, dip, nplane);
%load file xlsx in which set mean orientations are defined
[filenameset, pathnameset] = uigetfile({'*.xlsx', 'Select a XLSX file'},'mytitle',...
    pathnameset);
MeanOrient=readtable(fullfile(pathnameset, filenameset));

DipDirDipClu=zeros(length(MeanOrient.Set),2);
for i=1:length(MeanOrient.Set) %Cycle to insert Set mean DipDirection and Dip
    DipDirDipClu (i,:) = [MeanOrient.MeanDipDirection(i),MeanOrient.MeanDip(i)];
end
nclu=length(MeanOrient.Set);
%Calculate Normal vector of Mean Orientation

V=zeros(1,3,nclu);
for r=1:nclu
    % Unit vector V, which origin is at the origo, in the orientation of the
    % dip/dip direction
    
    V(:,:,r)=[cosd(90-DipDirDipClu(r,1))*cosd(DipDirDipClu(r,2)) sind(90-DipDirDipClu(r,1))*cosd(DipDirDipClu(r,2)) -sind(DipDirDipClu(r,2))];
    % Unit vector O, which origin is at the origo, which is perpendicular to
    % the dip diprecion and is horizontal
    O(:,:,r)=[-sind(90-DipDirDipClu(r,1)) cosd(90-DipDirDipClu(r,1)) 0];
end
% Normal vector N of the surface defined with the vectors V and O
Nclu=zeros(nclu,3);

for k=1:nclu
    Nclu(k,:)=cross(V(:,:,k),O(:,:,k));
end
figure(3)

[xshp,yshp,zshp]=sphere;
s = surf(xshp,yshp,zshp,'FaceAlpha',0.3)
s.EdgeColor = 'none';
hold on
for i=1:nclu
    quiver3(0,0,0,-Nclu(i,1),-Nclu(i,2),-Nclu(i,3))
    hold on
end
legend('sphere','1','2','3','4')
axis equal
xlabel('East')
ylabel('North')
zlabel('Up')
view(0,90)
new_Nclu=Nclu;

% Draws the automated clustering results (kmeans-method) on a Schmidt's equal area net
Stereogram(dipdir, dip, nplane, Set, xp, yp)


%% 5) Define folder in which dxf scanlines files are stored
% % % [filenameSL, pathnameSL]=uigetfile({'*.dxf', 'Select a DXF file'}, 'Select a DXF file',...
% % %     'F:\Menegoni\Antola\Outcrop_models\St_280116\Stazione 1bis_new\DXF\Scanlines_DXF');% <- MODIFY the PATH
pathnameSL=uigetdir(pathname, 'Select folder in which scanline.dxf files are stored');
listing = dir(pathnameSL);


rowname = cell(sum(~cellfun(@isempty,{listing(3:end).name})),1);
for i=1:sum(~cellfun(@isempty,{listing(3:end).name}))
    rowname(i,1)={listing(i+2,1).name};
end
SLtable=zeros(sum(~cellfun(@isempty,{listing(3:end).name})),4+4*(max(Set)+1));

%% 6) CYCLE FOR EVERY SCANPLANES
for loop =  1:sum(~cellfun(@isempty,{listing(3:end).name}))
    %% 6a) ReDEFINE VARIABLES FOR CALCULATION
    clearvars -except loop listing rowname pathnameSL Fracset n Fracdata filename pathname pointcloud SLtable Set new_Nclu MeanOrient%clear variables
    dipdir =  Fracdata.DipDirection(:);%Dip direction
    dip =  Fracdata.Dip(:);%Dip angle
    xyz = [Fracdata.Xcenter(:), Fracdata.Ycenter(:), Fracdata.Zcenter(:)];
    Nxyz = [Fracdata.Nx(:),Fracdata.Ny(:),Fracdata.Nz(:)];
    radius = Fracdata.Radius(:);
    
    Set(isnan(Set)) = 0;
    n=numel(Fracdata.Dip(:));
    nplane=n;
    
    % number of plane to plot in the stereogram
    filenameSL=rowname{loop};
    
    %% 6b) CALCULATE CENTER AND NORMAL OF THE SCANPLANE
    c_Poi = f_LectDxf(pathnameSL,filenameSL)%Read scanline DXF file
    
    SP_xyz=mean([c_Poi{1,1}; c_Poi{2,1}]);
    
    SP_Nxyz=new_Nclu(1,:);
    
    %% 6c) CALCULATE INTERSECTION FRACTURES-SCANPLANE
    
    
    %calculation intersection with CricFracTraceMap function
    [L, P_interA, SP_inters]= CircFracTraceMap(nplane,xyz, Nxyz, SP_xyz, SP_Nxyz, radius);
    
    %Drawing fracture intersection 3D map
    figure(4)% open figure in which plot this Trace map
    
    xlabel('X(East)')
    ylabel('Y(Nord)')
    zlabel('Z(Elev)')
    axis equal
    hold on
    grid on
    box on
    Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};
    for i=1:nplane
        if SP_inters(i)==1
            
            figure(4)
            
            drawEdge3d(P_interA(i,:), 'color', Color{Set(i)}, 'linewidth', 4);%plot lines of intersection
            hold on
            
        end
    end
   SP = createPlane(SP_xyz, SP_Nxyz);%create ScanPlane
    drawPlane3d(SP);%draw scan plane
    view((180-MeanOrient.MeanDipDirection(1)),(90-MeanOrient.MeanDip(1)))
   
    %% 6d) Drawing intersections
    % Drawing scanplane and fractures intersected
    figure(5)% open figure in which ScanPlane and fractures intersected are plotted
    
    xlabel('X(East)')
    ylabel('Y(Nord)')
    zlabel('Z(Elev)')
    axis equal
    hold on
    grid on
    box on
    Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};
    for i=1:nplane
        if SP_inters(i)==1
            figure(5)
            title('3D planes with their original normal vector')
            theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
            v=null(Nxyz(i,:));% calculate vectors needed to plot the discs
            points=repmat(xyz(i,:)',1,size(theta,2))+radius(i)*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
            
            % Change name to the coordinate in a better and more resonable name
            X=points(1,:)';
            Y=points(2,:)';
            Z=points(3,:)';
            fill3(points(1,:),points(2,:),points(3,:),Color{Set(i)}, 'FaceAlpha', 0.5);%Plot 3D disc for each plane
            xlabel('X(East)')
            ylabel('Y(Nord)')
            zlabel('Z(Elev)')
            axis equal
            hold on
            grid on
            box on
        end
    end
    SP = createPlane(SP_xyz, SP_Nxyz);%create ScanPlane
    drawPlane3d(SP);%draw scan plane
    
   % Drawing scanplane and fractures intersected with mean plane
   % orientation of sets
    figure(6)% open figure in which ScanPlane and fractures intersected are plotted
    
    xlabel('X(East)')
    ylabel('Y(Nord)')
    zlabel('Z(Elev)')
    axis equal
    hold on
    grid on
    box on
    Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};
    for i=1:nplane
        if SP_inters(i)==1
            figure(6)
            title('3D planes with mean normal vector of sets')
            theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
            if Set(i)== max(Set)
                v=null(Nxyz(i,:));
            else
            v=null(new_Nclu(Set(i),:));% calculate vectors needed to plot the discs
            end
            points=repmat(xyz(i,:)',1,size(theta,2))+radius(i)*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
            
            % Change name to the coordinate in a better and more resonable name
            X=points(1,:)';
            Y=points(2,:)';
            Z=points(3,:)';
            fill3(points(1,:),points(2,:),points(3,:),Color{Set(i)}, 'FaceAlpha', 0.5);%Plot 3D disc for each plane
            xlabel('X(East)')
            ylabel('Y(Nord)')
            zlabel('Z(Elev)')
            axis equal
            hold on
            grid on
            box on
        end
    end
    SP = createPlane(SP_xyz, SP_Nxyz);%create ScanPlane
    drawPlane3d(SP);%draw scan plane
end
%% 7) SPACING
%% 7a) Sort intertsection by position and calculate spacing
P_intermean=zeros(nplane,3);%create a matricx where the mean point
%of the intersection fracture-scanplane are stored
for i=1:nplane
    if SP_inters(i)==1
        P_intermean(i,:)=mean([P_interA(i,1:3); P_interA(i,4:6)]);
    else
        P_intermean(i,:)=[NaN, NaN, NaN];
    end
end
 
select_Pint = P_intermean(SP_inters==1,:);%
select_Set = Set(SP_inters==1);
for s=1:max(Set)-1
    clear temp_Pint temp_Set temp_position temp_matrix temp_ordmatrix
    temp_Pint = select_Pint(select_Set==s,:);% temporary
    if numel(temp_Pint)/3 >1%if there are mpore than 1 fracture intersection
        for i=1:(numel(temp_Pint) / 3)
            position(i,1,s) = (-dot (new_Nclu(s,:), temp_Pint(i,:)));%distance from origin toward normal vector
            temp_position (i,1) = (-dot (new_Nclu(s,:), temp_Pint(i,:)));
        end
        
        temp_matrix(:,1)=temp_position;
        temp_matrix(:,2:4)=temp_Pint;
        temp_ordmatrix=sortrows(temp_matrix);
        for i=1:(numel(temp_Pint) / 3)-1
            temp_spacing(i,1,s)= abs(dot (new_Nclu(s,:), temp_Pint(i+1,:))+ (temp_position(i)));
        end
     temp_spacing( temp_spacing==0)=NaN; 
    else
       temp_spacing(1,1,s)=0; 
    end
    Spacing=nanmean(temp_spacing);
    Spacingmode=mode(temp_spacing);
    
end

%Export Spacing
for j=1:max(Set)
    FracCount(j)=numel(find(SP_inters(Set==j)==1));
    
    if j<max(Set)
        Smean(j)=Spacing(1,1,j);
        Smode(j)=Spacingmode(1,1,j)
        Sdevst(j)=nanstd(temp_spacing(:,j));
    end
end



% %% codici Interessanti
% %Per calcolare bouinding box2.5D
% no0_P_inter=P_interA;
% no0_P_inter( all(~no0_P_inter,2), : )=[]
% k = boundary([P_interA(:,1:3);P_interA(:,4:6)]) 
% trisurf(k,[P_interA(:,1);P_interA(:,4)],[P_interA(:,2);P_interA(:,5)],[P_interA(:,3);P_interA(:,6)],'Facecolor','red','FaceAlpha',0.1)

%% UNCONTROLLED OLD VERSION  of DigitalScanlLine
%3) Normals have to be oriented upward!!! (Normals have to be horiented in same
%   direction if you want to calculate spacing)
% for i=1:nplane
%     if Nxyz(i,3)<0 %if normal is oriented downward
%         Nxyz(i,1)=-Nxyz(i,1);
%         Nxyz(i,2)=-Nxyz(i,2);
%         Nxyz(i,3)=-Nxyz(i,3);
%     else %if normal is oriented upward
%         Nxyz(i,1)=Nxyz(i,1);
%         Nxyz(i,2)=Nxyz(i,2);
%         Nxyz(i,3)=Nxyz(i,3);
%     end
% end

%5) Plot the discs that represent the discontinuities
% figure(1)
% for i=1:nplane
%
%     theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
%     v=null(Nxyz(i,:));% calculate vectors needed to plot the discs
%     points=repmat(xyz(i,:)',1,size(theta,2))+radius(i)*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
%
%     % Change name to the coordinate in a better and more resonable name
%     X=points(1,:)';
%     Y=points(2,:)';
%     Z=points(3,:)';
%
%
%     hold on % hold on, box on and grid are useful for plotting
%     grid on
%     box on
%     fill3(points(1,:),points(2,:),points(3,:),'b', 'FaceAlpha', 0.5);%Plot 3D disc for each plane
%
%     xlabel('x-axis (East)')
%     ylabel('y-axis (Nord)')
%     zlabel('z-axis (Elev)')
%     hold on
%     grid on
%     box on
%
%     %     %Uncomment if you want to see the normals of the planes
%     %     quiver3(xyz(i,1), xyz(i,2), xyz(i,3), Nxyz(i,1), Nxyz(i,2), Nxyz(i,3),0.4)
%     %     hold on
%     %     grid on
%     %     box on
% end
%
%     %% ------------CALCULATE INTERSECTION PLANES-LINE -------------------------
%     IntPTuncut=zeros(nplane,3);
%
%     %1) Calculate intersection between all planes and scanline------
%     figure(7)
%
%     for i=1:nplane
%
%         PLANE = createPlane(xyz(i,:), Nxyz(i,:));%Set plane properly for 'intersectLinePlane' and 'distancePoints3D' formulas
%         LINE=createLine3d(Pscanline1, Pscanline2);%Set line properly for 'intersectLinePlane' and 'distancePoints3D' formulas
%         IntPT_uncut (i,:) = intersectLinePlane(LINE, PLANE);% Gives coordinate of points of intersection
%         %The previous formula calculate intersection points between plane and
%         %line. Dimension of line is unlimited.
%         %Next 8 strings need to select only the intersection the lye on the
%         %scanline (on the limited segment).
%         D_Pscan1_IntPT(i) = distancePoints3d(Pscanline1, IntPT_uncut(i,:));
%         D_Pscan2_IntPT(i) = distancePoints3d(Pscanline2, IntPT_uncut(i,:));
%         D_IntPT_centerPlane(i) = distancePoints3d(IntPT_uncut(i,:), xyz(i,:));
%         UnOrd_distance(i,1)=D_Pscan1_IntPT(i);
%         if D_Pscan1_IntPT(i)<Lscanline && D_Pscan2_IntPT(i)<Lscanline && D_IntPT_centerPlane(i)< radius(i)
%             IntPT_uncut(i,:)= IntPT_uncut (i,:);
%             UnOrd_distance(i,1)=UnOrd_distance(i,1);
%
%             %plot fracture discs that intersect the scanline
%             theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
%             v=null(Nxyz(i,:));% calculate vectors needed to plot the discs
%             points=repmat(xyz(i,:)',1,size(theta,2))+radius(i)*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
%
%             % Change name to the coordinate in a better and more resonable name
%             X=points(1,:)';
%             Y=points(2,:)';
%             Z=points(3,:)';
%
%
%             hold on % hold on, box on and grid are useful for plotting
%             grid on
%             box on
%             fill3(points(1,:),points(2,:),points(3,:),'b', 'FaceAlpha', 0.5);%Plot 3D disc for each plane
%
%             xlabel('x-axis (East)')
%             ylabel('y-axis (Nord)')
%             zlabel('z-axis (Elev)')
%             hold on
%             grid on
%             box on
%         else
%             IntPT_uncut(i,:)=NaN;%All points that don't belong to the scanline are unselected (defining NaN as coordinate value)
%             UnOrd_distance(i,1)=NaN;
%
%         end
%
%     end%calulate only intersection without considering order
%
%     %2) It is created a new matrix which contain only non-NaN value (only
%     %points coordinate that lies on the scanline)
%     selectIntPT_cut = ~isnan( IntPT_uncut ) ;
%     selectUnOrd_dist = ~isnan( UnOrd_distance ) ;
%     pointIntersecting=IntPT_uncut(selectIntPT_cut);
%     UnOrd_dist=UnOrd_distance(selectUnOrd_dist);
%     npointIntersecting= (numel(pointIntersecting))/3;%count number of intersection points
%     xyz_selection = xyz (selectIntPT_cut);
%     Nxyz_selection = Nxyz(selectIntPT_cut);
%     Set_unord = Set(selectUnOrd_dist);
%     IntPT_cut=zeros(npointIntersecting, 3);
%     Ord_dist=zeros(npointIntersecting,1);
%     xyz_unord=zeros(npointIntersecting, 3);
%     Nxyz_unord=zeros(npointIntersecting, 3);
%     for i=1:numel(pointIntersecting);
%         IntPT_cut(ind2sub(size(IntPT_cut), i))=pointIntersecting(i);
%         xyz_unord(ind2sub(size(IntPT_cut), i))=xyz_selection(i);
%         Nxyz_unord(ind2sub(size(IntPT_cut), i))=Nxyz_selection(i);
%
%     end
%     for i=1:npointIntersecting;
%         Ord_dist(i,1)=UnOrd_dist(i,1);
%     end
%
%     %Give order in point distribuition
%     % Matrix with all parameters
%     AllValue = zeros(npointIntersecting, 4);
%     for i = 1 : npointIntersecting
%         AllValue(i,1)=Ord_dist(i);
%         AllValue(i,2:4)=IntPT_cut(i,:);
%         AllValue(i,5:7)=xyz_unord(i,:);
%         AllValue(i,8:10)=Nxyz_unord(i,:);
%         AllValue(i,11)=Set_unord(i);
%     end
%
%     % we have to decide the order of the plane
%     IntPT_cut_ord=zeros(npointIntersecting, 3);
%     Ord_dist_ord=zeros(npointIntersecting,1);
%     xyz_ord=zeros(npointIntersecting, 3);
%     Nxyz_ord=zeros(npointIntersecting, 3);
%     Set_ord=zeros(npointIntersecting, 1);
%     AllOrd=sortrows(AllValue); %Sort order: from lower to higher value;
%     for i = 1 : npointIntersecting
%         Ord_dist_ord (i,1) = AllOrd(i,1);
%         IntPT_cut_ord(i,1:3) = AllOrd(i,2:4);
%         xyz_ord(i,1:3) = AllOrd(i,5:7);
%         Nxyz_ord(i,1:3) = AllOrd(i,8:10);
%         Set_ord(i,1)= AllOrd(i,11);
%     end
%
%     %creare una matrice dove sono storaggiati tutti i punti ordinati e il cui
%     %primo punto � il Pscanline1 e l'ultimo il P-scanline2
%     Pointsforcalc=zeros(npointIntersecting + 2, 3);
%     for i = 1 : npointIntersecting
%         for j=1:3
%             Pointsforcalc(1,j)=Pscanline1(1,j);
%             Pointsforcalc(i+1,j)=IntPT_cut_ord(i,j);
%             Pointsforcalc(npointIntersecting + 2,j)=Pscanline2(1,j);
%         end
%     end
%     %calculation of distances bewteen points for RQD estimation
%     for i=1:npointIntersecting+1
%         D_RQD(i)=distancePoints3d(Pointsforcalc(i,:), Pointsforcalc(i+1,:));
%     end
%
%     for i=1:numel(D_RQD)
%         if D_RQD(i)>0.10
%             D_RQD(i)=D_RQD(i);
%         else
%             D_RQD(i)=NaN;
%         end
%     end
%
%     %estimation of RQD
%     RQD=(nansum(D_RQD) / Lscanline)*100;
%
%     %Plot Scanline_Plane_and Intersection point
%     %Plot Scanline
%     figure(8)
%     drawEdge3d([Pscanline1,Pscanline2], 'color', 'r', 'linewidth', 4);
%     hold on
%
%     if pointcloud==1
%         pcshow(PC)
%     end
%
%     %5) Plot the point of intersection between fracturs and scanline the discontinuities
%     figure(8)
%
%     for i=1:numel(Pointsforcalc)/3
%         drawPoint3d(Pointsforcalc(i,:))
%         hold on
%     end
%
%     % % % disp('#################################')
%     % % % disp(['RQD = ', num2str(RQD)])
%     % % % disp('#################################')
%
%     %%calculation set statistic
%
%     %% calculation spacing
%     if npointIntersecting>1
%         if numel(unique(Set))==1
%             for j=min(Set):max(Set)
%                 if sum(Set_ord == j)>1
%                     xyz_ordtemp=zeros;
%                     Nxyz_ordtemp=zeros;
%                     %             Nxyz_ordtemp=zeros;
%                     Spacing_temp=zeros;
%                     P_temp=zeros;
%                     for i=1:npointIntersecting
%                         if Set_ord(i)==j
%                             if Set_ord(i)<max(Set)
%                                 if numel(xyz_ordtemp)==1
%                                     xyz_ordtemp(1,1:3)=xyz_ord(i,:);
%
%
%                                     Nxyz_ordtemp(1,1:3)=new_Nclu(Set_ord(i),:);
%
%                                 else
%
%                                     xyz_ordtemp((numel(xyz_ordtemp)/3)+1,1:3)=xyz_ord(i,:);
%                                     Nxyz_ordtemp((numel(Nxyz_ordtemp)/3)+1,1:3)=new_Nclu(Set_ord(i),:);
%
%
%                                 end
%                             else
%                                 if numel(xyz_ordtemp)==1
%                                     xyz_ordtemp(1,1:3)=xyz_ord(i,:);
%                                     Nxyz_ordtemp(1,1:3)=Nxyz_ord(i,:);
%
%                                 else
%
%                                     xyz_ordtemp((numel(xyz_ordtemp)/3)+1,1:3)=xyz_ord(i,:);
%                                     Nxyz_ordtemp((numel(Nxyz_ordtemp)/3)+1,1:3)=Nxyz_ord(i,:);
%                                 end
%                             end
%                         end%creat matrix with xyz and Nxyz values of selected fracture set
%                     end
%                     for i=1:(numel(xyz_ordtemp) / 3)-1
%                         P_temp(i) = (-dot (new_Nclu(Set_ord(i),:), xyz_ordtemp(i,:)));
%                         Spacing_temp(i)= abs(dot(new_Nclu(Set_ord(i),:), xyz_ordtemp(i+1,:)) + (P_temp(i)));%D=vector containing distances between two consequent plane
%                     end
%                     Set_Smean(1,j)=mean(Spacing_temp);
%                     Set_mode(1,j)= mode(Spacing_temp);
%                     Set_median(1,j)=median(Spacing_temp);
%                     SL_sets(1,j)=sum(Set_ord==j);%number of fractures belonging to set(j) that intersect the scanline
%
%
%
%
%                 elseif sum(Set_ord == j)==1
%                     Set_Smean(1,j)=0;
%                     Set_mode(1,j)= 0;
%                     Set_median(1,j)=0;
%                     SL_sets(1,j)=sum(Set_ord==j);
%                 else
%                     Set_Smean(1,j)=0;
%                     Set_mode(1,j)= 0;
%                     Set_median(1,j)=0;
%                     SL_sets(1,j)=0;
%                 end
%
%             end
%         else %if more than 1set
%             for j=min(Set):max(Set)-1
%                 if sum(Set_ord == j)>1
%                     xyz_ordtemp=zeros;
%                     Nxyz_ordtemp=zeros;
%                     %             Nxyz_ordtemp=zeros;
%                     Spacing_temp=zeros;
%                     P_temp=zeros;
%                     for i=1:npointIntersecting
%                         if Set_ord(i)==j
%                             if Set_ord(i)<max(Set)
%                                 if numel(xyz_ordtemp)==1
%                                     xyz_ordtemp(1,1:3)=xyz_ord(i,:);
%
%
%                                     Nxyz_ordtemp(1,1:3)=new_Nclu(Set_ord(i),:);
%
%                                 else
%
%                                     xyz_ordtemp((numel(xyz_ordtemp)/3)+1,1:3)=xyz_ord(i,:);
%                                     Nxyz_ordtemp((numel(Nxyz_ordtemp)/3)+1,1:3)=new_Nclu(Set_ord(i),:);
%
%
%                                 end
%                             else
%                                 if numel(xyz_ordtemp)==1
%                                     xyz_ordtemp(1,1:3)=xyz_ord(i,:);
%                                     Nxyz_ordtemp(1,1:3)=Nxyz_ord(i,:);
%
%                                 else
%
%                                     xyz_ordtemp((numel(xyz_ordtemp)/3)+1,1:3)=xyz_ord(i,:);
%                                     Nxyz_ordtemp((numel(Nxyz_ordtemp)/3)+1,1:3)=Nxyz_ord(i,:);
%                                 end
%                             end
%                         end%creat matrix with xyz and Nxyz values of selected fracture set
%                     end
%                     for i=1:(numel(xyz_ordtemp) / 3)-1
%                         P_temp(i) = (-dot (new_Nclu(Set_ord(i),:), xyz_ordtemp(i,:)));
%                         Spacing_temp(i)= abs(dot(new_Nclu(Set_ord(i),:), xyz_ordtemp(i+1,:)) + (P_temp(i)));%D=vector containing distances between two consequent plane
%                     end
%                     Set_Smean(1,j)=mean(Spacing_temp);
%                     Set_mode(1,j)= mode(Spacing_temp);
%                     Set_median(1,j)=median(Spacing_temp);
%                     SL_sets(1,j)=sum(Set_ord==j);%number of fractures belonging to set(j) that intersect the scanline
%
%
%
%
%                 elseif sum(Set_ord == j)==1
%                     Set_Smean(1,j)=0;
%                     Set_mode(1,j)= 0;
%                     Set_median(1,j)=0;
%                     SL_sets(1,j)=sum(Set_ord==j);
%                 else
%                     Set_Smean(1,j)=0;
%                     Set_mode(1,j)= 0;
%                     Set_median(1,j)=0;
%                     SL_sets(1,j)=0;
%                 end
%
%             end
%         end
%
%         %% Calculate statistic
%         P10=npointIntersecting/Lscanline;% fracture intesity P01 (N#fractures/scanlineLength)
%
%         % P10set1
%         % P10set2
%         % P10set3
%         % P10set4
%         % P10set5
%         % P10set6
%         % P10set7
%         % % % disp(filenameSL)
%         % % % disp([npointIntersecting,P10,numel(unique(Set_ord)),SL_sets,Set_Smean,Set_median,Set_mode])
%         SLtable(loop,1)=npointIntersecting;
%         SLtable(loop,2)=P10;
%         SLtable(loop,3)=numel(unique(Set_ord));
%         for i=1:numel(SL_sets)
%             SLtable(loop,3+i)=SL_sets(i);
%             SLtable(loop,3+numel(SL_sets)+i)=Set_Smean(i);
%             SLtable(loop,3+2*numel(SL_sets)+i)=Set_median(i);
%             SLtable(loop,3+3*numel(SL_sets)+i)=Set_mode(i);
%         end
%
%
%
%
%     elseif npointIntersecting==1
%         for j=min(Set):max(Set)
%             if Set_ord==j
%                 SL_sets(1,j+1)=1;
%             else
%                 SL_sets(1,j+1)=0;
%             end
%         end
%         P10=npointIntersecting/Lscanline;% fracture intesity P01 (N#fractures/scanlineLength)
%
%         % P10set1
%         % P10set2
%         % P10set3
%         % P10set4
%         % P10set5
%         % P10set6
%         % P10set7
%         % % % disp(filenameSL)
%         % % % disp([npointIntersecting,P10,max(Set)+1,Set_ord])
%         SLtable(loop,1)=npointIntersecting;
%         SLtable(loop,2)=P10;
%         SLtable(loop,3)=numel(unique(Set_ord));
%         for i=1:numel(SL_sets)
%             SLtable(loop,3+i)=SL_sets(i);
%         end
%     end
%
%     SLtable(loop,end)=RQD;
%
%
% %create table and export XLSX
% varname= cell(1,numel(SLtable(1,:)));
%
% varname(1,1)={'N_Fractures_tot'};
% varname(1,2)={'N_P10'};
% varname(1,3)={'N_Sets_intersected'};
% for i=1:max(Set)
%     varname(1,3+i)={['N_fractures_set',num2str(i)]};
%     varname(1,3+max(Set)+i)={['Smean_set',num2str(i)']};
%     varname(1,3+2*(max(Set))+i)={['Smedian_set',num2str(i)']};
%     varname(1,3+3*(max(Set))+i)={['Smode_set',num2str(i)']};
% end
% varname(1,end)={'RQD'};
% for i=1:length(varname)
% if isempty(varname{i})==1
%     varname(1,i) = {['NaN',num2str(i)]};
% end
% end
%
% SLT=array2table(SLtable);
% SLT.Properties.RowNames=rowname;
% SLT.Properties.VariableNames=varname;
% tablefilenameXLSX='Results.xlsx';
% writetable(SLT,fullfile(pathnameSL,tablefilenameXLSX),'WriteRowNames',true);