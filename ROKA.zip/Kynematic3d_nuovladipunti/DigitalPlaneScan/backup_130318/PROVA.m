select_Pint = P_intermean(SP_inters==1,:);%
select_Set = Set(SP_inters==1);
for s=1:max(Set)-1
    clear temp_Pint temp_Set temp_position temp_matrix temp_ordmatrix
    temp_Pint = select_Pint(select_Set==s,:);% temporary
    if numel(temp_Pint)/3 >1%if there are mpore than 1 fracture intersection
        for i=1:(numel(temp_Pint) / 3)
            position(i,1,s) = (-dot (new_Nclu(s,:), temp_Pint(i,:)));%distance from origin toward normal vector
            temp_position (i,1) = (-dot (new_Nclu(s,:), temp_Pint(i,:)));
        end
        
        temp_matrix(:,1)=temp_position;
        temp_matrix(:,2:4)=temp_Pint;
        temp_ordmatrix=sortrows(temp_matrix);
        for i=1:(numel(temp_Pint) / 3)-1
            temp_spacing(i,1,s)= abs(dot (new_Nclu(s,:), temp_Pint(i+1,:))+ (temp_position(i)))
        end
    end
end
