function [A_SP, SP_N, SP_center, v1, v2, v3, v4] = scanplanecalc(SPpoints)
%% MODS: %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2020/04/27 -  the scan plane is calculated from the points selcted by the
%               Knn procedure.
%% DESCRIPTION: %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function defines the scanplane geometry parameters (area,
% center, normals, vertices) reading the segmentation of the point cloud
% represneting the area interested.
% The point cloud must be translated because it is stored in UTM metric
% coordinates, but the measurments are stored in a specific local
% coordinate system (this is related to the problem of Cloud Compare).
% The scanplane is consider as a rectangular window with four vertices (v1,
% v2, v3 and v4)
%                       2D Sketch of rectangular scanplane
%                      v1_______v2
%                       |\      |
%                       | \     |
%                       |  \    |
%                       |   \   |      -->minvector
%                       |    \  |     |
%                       |     \ |     |
%                       |_______|     v
%                      v3      v4     maxvector
%
% the area of the polygon is equal at the area of the two triangles 
% (trianlge 134 and triangle 124)
%--------------------------------------------------------------------------
% INPUT VARIABLES:
%   SPpoints = points of the scan plane selected onto the pintcloud by the
%              Knn algorithm.
%--------------------------------------------------------------------------
% OUTPUT VARIABLES:
%   PC = point cloud entity representing the segmentation of the 3D model;
%   A_SP = area of the calculated rectangular scan plane;
%   SP_N = normal of the calculated rectangular scan plane;
%   SP_center = center of the calculated rectangular scan plane;
%   v1,v2,v3,v4 = vertices of the calculated rectangular scan plane;
%% FUNCTION: %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
n = size(SPpoints, 1);% number of points
SP_center = mean(SPpoints);% compute centroid
covPts = cov(SPpoints)/n;% compute the covariance matrix

% Perform a principal component analysis with 2 variables, to extract inertia axes
%[U, S] = svd(covPts);
[U] = svd(covPts);
[V,D] = eig(cov(SPpoints));

% extract length of each semi axis
%radii = sqrt(5) * sqrt(diag(S)*n)';
maxdir=U(1);%direction of maximum axis
%maxmagn=radii(1);%magnitude of max semiaxis
mindir=U(2);%direction minimum axes
%minmagn=radii(2);%magn. of min axis

[maxMax, minMax, maxMin,minMin]=boundingBoxPlane(SPpoints);%calculating the bounding box of the scan plane
%calculate the vertices of the rectangular scan plane.
v1=SP_center+minMax*maxdir+maxMin*mindir;
v2=SP_center+minMax*maxdir+minMin*mindir;
v3=SP_center+maxMax*maxdir+maxMin*mindir;
v4=SP_center+maxMax*maxdir+minMin*mindir;

SP_N = V(:,1)';
if SP_N(1,3)<0 %if normal is oriented downward
    SP_N(1,1)=-SP_N(1,1);
    SP_N(1,2)=-SP_N(1,2);
    SP_N(1,3)=-SP_N(1,3);
end

% Sketch of 2D polygon
% 1_______2
% |\      |
% | \     |
% |  \    |
% |   \   |      -->minvector
% |    \  |     |
% |     \ |     |
% |_______|     v
% 3       4     maxvector
%
%the area of the polygon is equal at the area of the two triangles


ons=[1 1 1];

 A_scanplane1 = 0.5*sqrt(det([v1(1),v2(1),v3(1);v1(2),v2(2),v3(2);ons])^2 +...
                         det([v1(2),v2(2),v3(2);v1(3),v2(3),v3(3);ons])^2 +...
                         det([v1(3),v2(3),v3(3);v1(1),v2(1),v3(1);ons])^2);%area triangle 1-2-3
 A_scanplane2 = 0.5*sqrt(det([v1(1),v2(1),v4(1);v1(2),v2(2),v4(2);ons])^2 +...
                         det([v1(2),v2(2),v4(2);v1(3),v2(3),v4(3);ons])^2 +...
                         det([v1(3),v2(3),v4(3);v1(1),v2(1),v4(1);ons])^2);%area triangle 1-2-4
A_SP =  A_scanplane1+A_scanplane2;% area rectangle 1-2-3-4
