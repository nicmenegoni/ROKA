%% Note of Niccol�:
%This vesion (dxf_planefit_5) works with the new library of DXF of CC v2.9 (stable release),
%but accept only polyline. You have to save a DXF file vontaining only
%polyline file.

%% function [c_Poly,c_Poi] = f_LectDxf(nomArch)
% FUNCTION dxf = read_dxf(filename)
%
% Author:  Steven Michael (smichael@ll.mit.edu)
%
% Date:    3/10/2005
%
% Description
%
%   The following compiled MATLAB file reads in an
%   ascii DXF file and loads the information into
%   the "dxf" variable
%
% Inputs:
%
%   Filename   :    The filename of the ASCII DXF File
%
% Outputs:
%
%   dxf        :    A 3-D variable of size (NX3X3).  The first
%                   index N is the number of facets.  The second
%                   index references the 3 vertices of each
%                   facet, and the third index is the
%                   (x,y,z) location of the vertex.
%
% Note:
%
%   This may not work with all DXF files.  The DXF file format
%   is complicated and continuously evolving.  This has worked
%   with every file I happened to use it on, but that will
%   not be true for everyone.
%
%   Also, the function does not load any color or texture
%   information.
%%% Read entities information of dxf file
%author = SebaTM
%Jul 27 2009
%Based in dxf2coord 1.1 matrix of lukas wischounig, but is not dependent of the Code
%Group relative position. That is better way to read dxf format. Don't fail if the
%polyline has arcs (budges), but yet don't read them. Don't read arcs as circles. Read
%properties (see case 'LINE' by examples of modifications). Group Codes and Associated
%Values is read in accurately way (accept associated values with space).
%
%Use cell2mat(cell(:,1)) to acquire geometry data in matrix,
%by example cell2mat(c_Cir(:,1))
clear all
close all
[filename, pathname]=uigetfile({'*.dxf', 'Select a DXF file'}, 'Select a DXF file',...
    'F:\Menegoni\Antola\Outcrop_models\St_211016\CANON_EOS\DCIM\St_59_plus_random\Sed_subdivsion\each_strata\dxf');
%'F:\Menegoni\Antola\Outcrop_models');% <- MODIFY the PATH
% select path in which DXF of Circular Plane will be saved
uiwait(msgbox('Select folder for CircPlane.dxf'));
pathCircPlane=uigetdir(pathname, 'Select folder for CircPlane.dxf');
disp('########### START OF FITTING PROCCES ##########')
tic
%% Read file
fId = fopen(fullfile(pathname,filename));
c_ValAsoc = textscan(fId,'%d%s','Delimiter','\n');
fclose(fId);
% Code Group Matrix
m_GrCode = c_ValAsoc{1};
% Associated value String Cell
c_ValAsoc = c_ValAsoc{2};
%[m_GrCode,c_ValAsoc] = c_ValAsoc{:};

%% Entities
m_PosCero = find(m_GrCode==0);
%Is searched by (0,SECTION),(2,ENTITIES)
indInSecEnt = strmatch('ENTITIES',c_ValAsoc(m_PosCero(1:end-1)+1),'exact');
%(0,ENDSEC)
m_indFinSecEnt = strmatch('ENDSEC',c_ValAsoc(m_PosCero(indInSecEnt:end)),'exact');
% Entities Position
m_PosCero = m_PosCero(indInSecEnt:indInSecEnt-1+m_indFinSecEnt(1));
% Variable initiation
%accelerate?
c_Line = cell(sum(strcmp('LINE',c_ValAsoc(m_PosCero))),2);
c_Poly = cell(sum(strcmp('POLYLINE',c_ValAsoc(m_PosCero))),2);
c_Cir = cell(sum(strcmp('CIRCLE',c_ValAsoc(m_PosCero))),2);
c_Arc = cell(sum(strcmp('ARC',c_ValAsoc(m_PosCero))),2);
c_Poi = cell(sum(strcmp('POINT',c_ValAsoc(m_PosCero))),2);
c_Line = cell(1,2);
c_Poly = cell(1,2);
c_Cir = cell(1,2);
c_Arc = cell(1,2);
c_Poi = cell(1,2);
%
iLine = 1;
iPoly = 1;
iCir = 1;
iArc = 1;
iPoi = 1;
% Loop on the Entities
for iEnt = 1:length(m_PosCero)-2
    m_GrCodeEnt = m_GrCode(m_PosCero(iEnt+1):m_PosCero(iEnt+2)-1);
    c_ValAsocEnt = c_ValAsoc(m_PosCero(iEnt+1):m_PosCero(iEnt+2)-1);
    nomEnt = c_ValAsocEnt{1};  %c_ValAsocEnt{m_PosCero(iEnt+1)}
    %In the entitie's name is assumed uppercase
    switch nomEnt
        case 'VERTEX'
            % (X,Y,Z) Position
            c_Poi{iPoi,1} = [str2double(f_ValGrCode(10,m_GrCodeEnt,c_ValAsocEnt)),...
                str2double(f_ValGrCode(20,m_GrCodeEnt,c_ValAsocEnt)),...
                str2double(f_ValGrCode(30,m_GrCodeEnt,c_ValAsocEnt))];
            % Layer
            c_Poi(iPoi,2) = f_ValGrCode(8,m_GrCodeEnt,c_ValAsocEnt);
            % Add properties
            %
            iPoi = iPoi+1;
            %case Add Entities
            
            % (X,Y,Z) vertexs
            
            
    end
end
%% create XYZNCloud matrix with X, Y and Z coordinate and Number of pointcloud
for i=1:numel(c_Poi)/2
    
    clear temp_name
    temp_name=char(c_Poi(i,2));
    Ncloud_c_Poi (i,1) = str2num(temp_name(10:end));
    
end
XYZNCloud=cell2mat(c_Poi(:,1));
XYZNCloud(:,4)=Ncloud_c_Poi(:,1);
%end
%% Fitting Plane step
plane=zeros(1,13);
for i=1 : max(XYZNCloud(:,4))%max(XYZNCloud(:,4)=number of planes
    
    temp_PC=zeros(1,3);
    
    for j=1:numel(XYZNCloud(:,4))%numel(XYZNCloud(:,4)=number of points (numel(XYZNCloud(:,4)== numel(XYZNCloud(:,1)== numel(XYZNCloud(:,2) == numel(XYZNCloud(:,3)
        % Write a temporary matrix containing points reffered to a plane
        if XYZNCloud(j,4)==i
            if temp_PC(1,1) == 0 && temp_PC(1,2) == 0 && temp_PC(1,3) == 0
                temp_PC(1,:)=XYZNCloud(j,1:3);
            else
                temp_PC(1+numel(temp_PC)/3,:)=XYZNCloud(j,1:3);
            end
        end
        
        
    end
    if (numel(temp_PC)/3)>2
        if plane(1,1) == 0 && plane(1,2) == 0 && plane(1,3) == 0
            plane(1,:)=fit3dplane_2(temp_PC);
        else
            plane(1+numel(plane)/13,:)=fit3dplane_2(temp_PC);
        end
    end
    
end
Tplane = table(plane(:,1),plane(:,2),plane(:,3),plane(:,4),plane(:,5),plane(:,6),plane(:,7),plane(:,8),plane(:,9),plane(:,10),plane(:,11),plane(:,12), plane(:,13));
Tplane.Properties.VariableNames = {'Dip' 'DipDirection' 'Radius' 'Xcenter' 'Ycenter' 'Zcenter' 'Nx' 'Ny' 'Nz' 'Mcoplanarity' 'Kcolinearity' 'MeanAbsError' 'StDevAbsError'};
tablefilenameTXT = (['Fit_',filename(1:end-4),'.txt']);
writetable(Tplane,fullfile(pathname,tablefilenameTXT));
tablefilenameXLSX = (['Fit_',filename(1:end-4),'.xlsx']);
writetable(Tplane,fullfile(pathname,tablefilenameXLSX));
toc
disp('########### END OF FITTING PROCCES ##########')


disp('########### START OF DISCONTINUITY PLOTTING AND SAVING PROCCESSES ##########')
tic
nplane=numel(plane(:,1));
% Plotting and saving dxf of circular plane
% figure (5)
% title(['Discontinuity plane, N = ', num2str(nplane)])
% %%--------------------Plot Circular Discontinuit Planes ------------------

N_set=zeros(nplane, 7); %matrix to storage number of plane for each set, every coloumn represent a set.

% Remember that radius of disconinuity its egual to diagonal of rectagnle
% formed by its values Horizontal and Vertical extent reached by
% CloudCompare
xyz(:,1)=plane(:,4);
xyz(:,2)=plane(:,5);
xyz(:,3)=plane(:,6);
Nxyz(:,1)=plane(:,7);
Nxyz(:,2)=plane(:,8);
Nxyz(:,3)=plane(:,9);
radius(:,1)=plane(:,3);
for i=1:nplane
    
    theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
    v=null(Nxyz(i,:));% calculate vectors needed to plot the discs
    points=repmat(xyz(i,:)',1,size(theta,2))+radius(i)*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
    
    % Change name to the coordinate in a better and more resonable name
    X=points(1,:)';
    Y=points(2,:)';
    Z=points(3,:)';
    
    % With the below loop matlab could export DXF with different color in base
    % of set
    %for j=1:nclu
    %if idx3(i)==j
    % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
    % to export DXF for each plane
    filename_mod=filename(1:end-4);
    Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};
    % name is written in this way:
    % (number of set)_CircPlane_(number of row in CSV matrix)_(name of CSV file).dxf
    dxf_name=(['CircPlane',num2str(i),'_',num2str(filename_mod),'.dxf']);
    FID=dxf_open(pathCircPlane,dxf_name);
    FID = dxf_set(FID,'Color',Color{1});
    dxf_polyline(FID, X, Y, Z);
    dxf_close(FID); % end of DXF exportation
    %end
    %end
    
    %     % Uncomment for plot of discs of discontinuities
    %     hold on % hold on, box on and grid are useful for plotting
    %     grid on
    %     box on
    %     fill3(points(1,:),points(2,:),points(3,:),'b', 'FaceAlpha', 0.5);%Plot 3D disc for each plane
    %
    %     xlabel('x-axis (East)')
    %     ylabel('y-axis (Nord)')
    %     zlabel('z-axis (Elev)')
    %     hold on
    %     grid on
    %     box on
    
    %         %Uncomment if you wnat to see the normals of the planes
    %         quiver3(xyz(i,1), xyz(i,2), xyz(i,3), Nxyz(i,1), Nxyz(i,2), Nxyz(i,3),0.4)
    %         hold on
    %         grid on
    %         box on
    %
    
    
    
    
end
%-------------------------------------------------------------------------
toc
disp('########### END OF DISCONTINUITY PLOTTING AND SAVING PROCCESSES ##########')

scatter3(Tplane.Mcoplanarity,Tplane.MeanAbsError,Tplane.Kcolinearity)
set(gca, 'YScale', 'log')
xticks(0:4:max(Tplane.Mcoplanarity))
xlabel('Colpanarity')
ylabel('Mean absolute error')
zlabel('Colinearity')
% Mlim = createPlane(4,04, SP_Nxyz);%create ScanPlane
%     drawPlane3d(SP);%draw scan plane


%%
function c_Val = f_ValGrCode(grCode,m_GrCode,c_ValAsoc)
c_Val = c_ValAsoc(m_GrCode==grCode);
end

%%
function c_XData = f_XData(grCode,XDatNom,m_GrCode,c_ValAsoc)
m_PosXData = find(m_GrCode==1001);
if ~isempty(m_PosXData)
    indInXData = m_PosXData(strmatch(upper(XDatNom),c_ValAsoc(m_PosXData),'exact'));
    m_indFinXData = find(m_GrCode(indInXData+2:end)==1002)+indInXData+1;
    m_IndXData = indInXData+2:m_indFinXData(1)-1;
    c_XData = f_ValGrCode(grCode,m_GrCode(m_IndXData),c_ValAsoc(m_IndXData));
else
    c_XData = {[]};
end
end



