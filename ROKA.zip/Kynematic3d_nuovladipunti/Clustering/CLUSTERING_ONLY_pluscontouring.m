close all
clear all
%% LOAD & READ XLSX DATA%% LOAD & READ CSV DATA
csv=0;
txt=1;
if csv==1 %Read if fracture data are a csv of CloudCompare
    uiwait(msgbox('Select CSV file to load'));
    if ismac %For OSX operative system
        [filename, pathname] = uigetfile({'*.csv', 'Select a CSV file'},'mytitle',...
            '/Volumes/F/DATI/D_data/dottorato/DATI/Antola/Outcrop_models');% <- MODIFY the PATH
    elseif ispc % For WINDOWS operative system
        [filename, pathname] = uigetfile({'*.csv', 'Select a CSV file'},'mytitle',...
            'I:\DATI\D_data\dottorato\DATI\Antola\Outcrop_models');% <- MODIFY the PATH
    end
    
    [CSV,delimiterOut]=importdata(fullfile(pathname, filename),';',1);
    n=numel(CSV.data)/16; %number of rows (= number of plane)
    disp ([filename]) % disp on Matlab command line the name of the file
    
    A=zeros(n ,6);% initializing a matrix of n rows (i) and 6 columns (j) with all zeros
    Horiz_ext=zeros(n ,6);
    Vertical_ext=zeros(n ,6);
    for i= 1 : n % rows from 1 to n (=planes)
        for j = 1 : 6 % column from 1 to 6 (=x, y, z, Nx, Ny, Nz)
            
            A(i,j)= CSV.data(i,j+1); % import value x, y, z, Nx, Ny, Nz for each plane
            Horiz_ext(i)=CSV.data(i,9);
            Vertical_ext(i)=CSV.data(i,10);
        end
    end
    % DEFINE VARIABLES FOR CALCULATION
    dipdir =  CSV.data(:,13);%Dip direction
    dip =  CSV.data(:,14);%Dip angle
    nplane=n; % number of plane to plot in the stereogram
end



if txt==1 %Read fracture data from a txt created by Matlab
 uiwait(msgbox('Select CSV file to load'));
    if ismac %For OSX operative system
        [filename, pathname] = uigetfile({'*.xlsx', 'Select a XLSX file'},'mytitle',...
            '/Volumes/F/DATI/D_data/dottorato/DATI/Antola/Outcrop_models');% <- MODIFY the PATH
    elseif ispc % For WINDOWS operative system
        [filename, pathname] = uigetfile({'*.xlsx', 'Select a XLSX file'},'mytitle',...
           'F:\Menegoni\Ormea\Nuovi voli giugno 2017\Albris_SenseFly\parete\obj\measures');% <- MODIFY the PATH
    end
Fracdata=readtable(fullfile(pathname, filename));
n=numel(Fracdata.Dip); %number of rows (= number of plane)


%% DEFINE VARIABLES FOR CALCULATION
dipdir =  Fracdata.DipDirection;%Dip direction
dip =  Fracdata.Dip;%Dip angle
nplane=n; % number of plane to plot in the stereogram
end
%%


% In this paragraph this code will use some function for plotting stereonet
% and clustering disconinuities poles from the code ' VisualScanline' of
% Markovaara-Koivisto and Laine (1).

%Steroplot of poles of disconinuities--------------------------------------
[xp, yp]=Stereogram_colourless_Schmidt(dipdir, dip, nplane);

%Steroplot of poles of disconinuities--------------------------------------
figure('name','Stereogram contour')
% Draws the oriented data into Schmidt's net (G. Middleton, November 1995)
theta=(90-dipdir); % Poles are at the opposite direction to dip direction
r=sqrt(2)*sind((90-dip-90)/2); % Poles are perpendicular to the dip

% Coordinates on the strereographic projection
m=nplane;;
for i=1:m;
    xp(i) = r(i)*cosd(theta(i));
    yp(i) = r(i)*sind(theta(i));  
end
xyp=[xp(:),yp(:)];
[n,c] = hist3(xyp,[20,20]);
[xpnew, ypnew] = meshgrid(linspace(-1,1,180));
nnew = interp2(c{1},c{2},n',xpnew,ypnew, 'spline');

contourf(xpnew, ypnew, nnew, [1:1:round(max(n))+1]);
hold on;
schmidt
hold on
scatter(xp(:), yp(:), [],'+k');
hold off
% Clustering of the discontintuities---------------------------------------

% Asks the number of joint sets in the data
prompt = {['Number of joint sets (+1 for randoms) in your data (max 7):']};
dlg_title = 'Input Number of Sets (+1 for Randoms)';
nclu = inputdlg(prompt);% number of joint selected
nclu =str2num(nclu{1});

Clustering_Modified2 % this function was modified in order to permit clustering between
% discontinuity with poles with same direction but opposit side (ex. 30/85
% and 210/85).

% Draws the automated clustering results (kmeans-method) on a Schmidt's equal area net
Stereogram(dipdir, dip, nplane, idx3, xp, yp)

% Asks is the user is satisfied with the result of the clustering
% If not, the user may change the clustering in an interactive window
Ready = [];
button=1;
prompt = {['Do you want to change the results of the automatic clustering (y/n)?']};
dlg_title = 'Do you want to change the results of the automatic clustering (y/n)?';
yes_no = inputdlg(prompt);
answer = yes_no{1,1};
while (answer == 'y' & isempty(Ready) & button==1)
    disp('Left click with mouse on the symbols as many times as it takes to change the cluster into the wanted one.')
    disp('When you are finnished, right click with mouse on the figure')
    [xcho, ycho, button]=ginput(1);
    
    % Calculates the minimun distance between the indicated point and the data
    % points and searches the closes data point, gives index to the row and
    % changes the cluster group into the next one or to the first one.
    % Refreshes the figure.
    distance=sqrt((xp-xcho).^2+(yp-ycho).^2);
    cho=find(distance==min(distance))
    % Observation is indicated to the next cluster
    if (idx3(cho)<max(idx3) & button==1)
        idx3(cho)=idx3(cho)+1;
    elseif button==1
        idx3(cho)=1;
    end
    Stereogram(dipdir, dip, nplane, idx3, xp, yp)
    
    
end

%------ K-Fisher ditributon coefficient----------------------------------
% This part was not inside the code of Markovaara-Koivisto and Laine (1).
% According Priest (2) the K-Fisher coefficient for a spherical  vector
% distribution can be approximated by the function:

%                       K = (N - 1)/ (N - R)

% where N = sum of magnitude of vectors;
%       R = magnitude of resultant of vector (sum of vector), R is allways lower than N;
% K ->infinity, for (N - R)->0; Higher K are for really thight set, Lower K
% are for broad set.

% Since pole vectors are unit vectors (magnitude=1), N represent the number
% of poles.
for  i = 1 : nplane
    for j = 1 : nclu
        if idx3(i) == j
            
            % correction that permits poles with same direction but opposit
            % side clustering
            
            if arcdistance(idx3(i), i) == antiarcdistance(idx3(i), i)
                N_corr(:,:,i)=antiN(:,:,i);
            else
                N_corr(:,:,i)=N(:,:,i);
            end
        end
    end
    
end


for i=1:nplane
    for j=1:3
        N_correct(i,j)=N_corr(1,j,i); % copy normal (pole) vector in a more appropiate matrix for further calculation
    end
end

%Calculate K-Fisher
N_SetPlane = hist( idx3, numel(unique(idx3)) );% count number of plane in each set--> N value

% Initializing resultant vector, r=(rx, ry, rz)
rx=zeros(1,nclu);
ry=zeros(1,nclu);
rz=zeros(1,nclu);

% calculate resultant of pole vectors
for i=1:nplane
    for j=1:nclu
        if idx3(i)==j
            rx(1,j)=rx(1,j)+N_correct(i,1);%resultant of value x for each set
            ry(1,j)=ry(1,j)+N_correct(i,2);%resultant of value y for each set
            rz(1,j)=rz(1,j)+N_correct(i,3);%resultant of value z for each set
        end
    end
end

% Initializing magnitude of resultant and K-fisher value
magn_r_xyz=zeros(1,nclu);
K_fisher=zeros(1,nclu);

for j=1:nclu
    magn_r_xyz(1,j)=sqrt(rx(1,j)^2 + ry(1,j)^2 + rz(1,j)^2);% calulate magnitude of resultant for each set
    K_fisher(1,j)=(N_SetPlane(1,j)-1)/(N_SetPlane(1,j)-magn_r_xyz(1,j));% calculate K-Fisher coeff. for each set
end

% %% calculate density
% calculate density 
%step_dipdir=2;%degrees 
%step_dip=2; for
% i=1:(360/step_dipdir)
%     for j=1:(90/step_dip)
%     dipdir_node((90/step_dip)*i+j-(90/step_dip))=i*2-1;
%     dip_node((90/step_dip)*i+j-45)=j*2-1; end
% end
%
% % Calculation of the surface's normal % Surface is defined with two
% perpendicular vectors V and O V_node=zeros(1,3,numel(dipdir_node)); for
% r=1:numel(dipdir_node) % Unit vector V, which origin is at the origo, in
% the orientation of the % dip/dip direction
% V_node(:,:,r)=[cosd(90-dipdir_node(r))*cosd(dip_node(r))
% sind(90-dipdir_node(r))*cosd(dip_node(r)) -sind(dip_node(r))]; % Unit
% vector O, which origin is at the origo, which is perpendicular to % the
% dip direction and is horizontal O_node(:,:,r)=[-sind(90-dipdir_node(r))
% cosd(90-dipdir_node(r)) 0]; end % Normal vector N of the surface defined
% with the vectors V and O N_node_temp=zeros(1,3,numel(dipdir_node)); for
% k=1:numel(dipdir_node)
%     N_node_temp(:,:,k)=cross(V_node(:,:,k),O_node(:,:,k)); for j=1:3
%         N_node(k,j)=N_node_temp(1,j,k);
%     end
%
% end
%
% for i=1:numel(dipdir_node)
%
% % Pole vector is counter vector of the normal vector, and it points %
% downwards N_node=-N_node; antiN_node=-N_node; % Observation are divided
% into the closest clusters arcdistance_node=zeros(m,1);
% norm_arcdistance_node=zeros(m,1); antiarcdistance_node=zeros(m,1);
% temp_arc=0;
%         for k=1:m
%
%             norm_arcdistance_node(k)=(acos(dot(N_correct(k,:),N_node(i,:))))^2;
%             % distance between the observation and the centroids, nclu
%             defines rows and number of observations columns
%             antiarcdistance(k)=(acos(dot(N_correct(k,:),antiN_node(i,:))))^2;
%             if norm_arcdistance(k)>antiarcdistance(k)
%                arcdistance_node(k)=temp_arc + antiarcdistance_node(k);
%             elseif antiarcdistance(k) >norm_arcdistance(k)
%                arcdistance_node(k)=temp_arc + norm_arcdistance_node(k);
%             end temp_arc=arcdistance_node(k);
%         end
%
%            arcdistance_node_sum(i,1)=sum(arcdistance_node);
%
%
% 

%%
% ----------- DRAWING OTHER STEREOPLOT/POLES PROJECTION --------------------
% Draws colour coded unit vectors on a stereographic sphere, in which dip 0
% degrees is at the bottom of the sphere and 90 degrees at the top.
Unitvectors_coloured(dipdir, dip, nplane, idx3)

% Calculates the mean attitudes of the clusters
[dipdireigv, dipeigv]=Eigenvector(dipdir, dip, idx3);

% Draws a stereographic projection with the mean attitudes of the clusters
StereogramEig(dipdir, dip, nplane, idx3)

thetaeig=(90-dipdireigv);
reig=sqrt(2)*sind((90-dipeigv-90)/2);
for n=1:max(idx3)
    xeigp(n) = reig(n)*cosd(thetaeig(n));
    yeigp(n) = reig(n)*sind(thetaeig(n));
end
plot(xeigp, yeigp, 'kO')

disp(['########## General Information ############'])
disp(['Total N. of Plane,      ', num2str(nplane, '%3.2f')])
for j=1:nclu
    disp(['################ Set ', num2str(j),' #####################'])
    disp(['Plane N.,           ', num2str(N_SetPlane(j), '%3.2f')])
    disp(['DipDir,             ', num2str(dipdireigv(j), '%3.2f')])
    disp(['Dip,                ', num2str(dipeigv(j), '%3.2f')])
    disp(['K Fisher`s coeff.,  ', num2str(K_fisher(j), '%3.2f')])
end

