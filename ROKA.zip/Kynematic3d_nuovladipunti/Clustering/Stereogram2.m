function Stereogram2(dipdir, dip, nplane)
% Stereogram.m takes into account clusters and uses colour coding to
% distinguis them
%
% Note: Original script to draw Schmidt's net is by Gerry Middleton,
% November 1995.
%
% 12.10.2010 M. Markovaara-Koivisto, Aalto University School of Science and
% Technology, Finland
% if plane pole plot --> plane0_Intersection1 = 0
% if line vector plot -> plane0_Intersection1 = 1

figure('name','Stereogram contour')
% Draws the oriented data into Schmidt's net (G. Middleton, November 1995)
theta=(90-dipdir); % Poles are at the opposite direction to dip direction
r=sqrt(2)*sind((90-dip-90)/2); % Poles are perpendicular to the dip

% Coordinates on the strereographic projection
m=nplane;;
for i=1:m;
    xp(i) = r(i)*cosd(theta(i));
    yp(i) = r(i)*sind(theta(i));  
end
xyp=[xp(:),yp(:)];
[n,c] = hist3(xyp,[20,20]);
[xpnew, ypnew] = meshgrid(linspace(-1,1,180));
nnew = interp2(c{1},c{2},n',xpnew,ypnew, 'spline');

contourf(xpnew, ypnew, nnew, [1:1:round(max(n))+1]);
hold on;
schmidt
hold on
scatter(xp(:), yp(:), [],'+k');
hold off