
for s=1:nclu+1
    sum_cluster(:,s)=[sum(N(1,1,find(idx3==s))) sum(N(1,2,find(idx3==s))) sum(N(1,3,find(idx3==s)))]; %Finds the rows with the same idc3 and sums them up
    % Length of the polevectors' sum
    L(s)=sqrt(sum(N(1,1,find(idx3==s)))^2+sum(N(1,2,find(idx3==s)))^2+sum(N(1,3,find(idx3==s)))^2);
    % Sumvector is normalised into a unitvector
    Nclu_new(:,s)=sum_cluster(:,s)/L(s);
end

% Points are re-divided according to the closest new cluster centroids
arcdistance=zeros(s,m);
for s=1:nclu+1
    for k=1:m
        norm_arcdistance(s,k)=(acos(dot(N(:,:,k),new_Nclu(:,s))))^2; % distance between the observation and the centroids, nclu defines rows and number of observations columns
        antiarcdistance(s,k)=(acos(dot(antiN(:,:,k),new_Nclu(:,s))))^2;
        if norm_arcdistance(s,k)>antiarcdistance(s,k)
            arcdistance(s,k)=antiarcdistance(s,k);
            
            
        elseif antiarcdistance(s,k) >norm_arcdistance(s,k)
            arcdistance(s,k)=norm_arcdistance(s,k);
            
        end
    end
end




% 
% %%%%--------------------- PARTE EDITED BY MYSELF----------------
% % All poles with distance higher than 30� form the centroid of the cluster
% % are considered belonging to the lastest set (random set)
% for s=1:nclu-1
%     for k=1:nplane
%         if s == idx3(k)
%             if norm_arcdistance(s,k) > 0.53598775
%                 idx3(k)=nclu; % Observation gets the rownumber as its cluster number.
%             else
%             end
%         else
%         end
%     end
% end
% 



