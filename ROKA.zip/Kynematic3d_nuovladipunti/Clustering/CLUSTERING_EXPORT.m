close all
clear all
%% LOAD & READ CSV DATA
uiwait(msgbox('Select CSV file to load'));
if ismac %For OSX operative system
    [filename, pathname] = uigetfile({'*.csv', 'Select a CSV file'},'Select CSV file',...
        '/Volumes/F/DATI/D_data/dottorato/DATI/Antola/Outcrop_models');% <- MODIFY the PATH
elseif ispc % For WINDOWS operative system
    [filename, pathname] = uigetfile({'*.csv', 'Select a CSV file'},'Select CSV file',...
        'G:\DATI\D_data\dottorato\DATI\Antola\Outcrop_models');% <- MODIFY the PATH
end

[CSV,delimiterOut]=importdata(fullfile(pathname, filename),';',1);
n=numel(CSV.data)/16; %number of rows (= number of plane)
disp ([filename]) % disp on Matlab command line the name of the file

A=zeros(n ,6);% initializing a matrix of n rows (i) and 6 columns (j) with all zeros
Horiz_ext=zeros(n ,6);
Vertical_ext=zeros(n ,6);
for i= 1 : n % rows from 1 to n (=planes)
    for j = 1 : 6 % column from 1 to 6 (=x, y, z, Nx, Ny, Nz)
        
        A(i,j)= CSV.data(i,j+1); % import value x, y, z, Nx, Ny, Nz for each plane
        Horiz_ext(i)=CSV.data(i,9);
        Vertical_ext(i)=CSV.data(i,10);
    end
end

%% DEFINE VARIABLES FOR CALCULATION
dipdir =  CSV.data(:,13);%Dip direction
dip =  CSV.data(:,14);%Dip angle
nplane=n; % number of plane to plot in the stereogram

% In this paragraph this code will use some function for plotting stereonet
% and clustering disconinuities poles from the code ' VisualScanline' of
% Markovaara-Koivisto and Laine (1).

%Steroplot of poles of disconinuities--------------------------------------
figure('name','Stereogram contour')
% Draws the oriented data into Schmidt's net (G. Middleton, November 1995)
theta=(90-dipdir); % Poles are at the opposite direction to dip direction
r=sqrt(2)*sind((90-dip-90)/2); % Poles are perpendicular to the dip

% Coordinates on the strereographic projection
m=nplane;;
for i=1:m;
    xp(i) = r(i)*cosd(theta(i));
    yp(i) = r(i)*sind(theta(i));  
end
xyp=[xp(:),yp(:)];
[n,c] = hist3(xyp,[20,20]);
[xpnew, ypnew] = meshgrid(linspace(-1,1,180));
nnew = interp2(c{1},c{2},n',xpnew,ypnew, 'spline');

contourf(xpnew, ypnew, nnew, [1:1:round(max(n))+1]);
hold on;
schmidt
hold on
scatter(xp(:), yp(:), [],'+k');
hold off


% Clustering of the discontintuities---------------------------------------

% Asks the number of joint sets in the data
prompt = {['Number of joint sets (+1 for randoms) in your data (max 7):']};
dlg_title = 'Input Number of Sets (+1 for Randoms)';
nclu = inputdlg(prompt);% number of joint selected
nclu =str2num(nclu{1});

Clustering_Modified2 % this function was modified in order to permit clustering between
% discontinuity with poles with same direction but opposit side (ex. 30/85
% and 210/85).

% Draws the automated clustering results (kmeans-method) on a Schmidt's equal area net
Stereogram(dipdir, dip, nplane, idx3, xp, yp)


    disp('Refine cluster drawing them')
   

    for i=1:nclu %define cluster drawing area
        if i==1 %set1
            uiwait(msgbox('Select set1 poles 1st time'));
            [clus1,xs1,ys1] = selectdata('selectionmode','lasso')
            
            for k=i:nplane %asses cluster value
                for j=1:nplane
                    
                    if xs1{k,1} == xp(j) & ys1{k,1}== yp(j)
                        idx3(1,j)=1;
                    else
                    end
                end
            end
        end
        
        if i==2 %set2
            uiwait(msgbox('Select set2 poles 1st time'));
            [clus2,xs2,ys2] = selectdata('selectionmode','lasso');
            
            for k=i:nplane %asses cluster value
                for j=1:nplane
                    
                    if xs2{k,1}==xp(j) & ys2{k,1}==yp(j)
                        idx3(1,j)=2;
                    else
                    end
                end
            end
        end
        if i==3 %set3
            uiwait(msgbox('Select set3 poles 1st time'));
            [clus3,xs3,ys3] = selectdata('selectionmode','lasso');
            
            for k=i:nplane %asses cluster value
                for j=1:nplane
                    
                    if xs3{k,1}==xp(j) & ys3{k,1}==yp(j)
                        idx3(1,j)=3;
                    else
                    end
                end
            end
        end
        
        if i==4 %set4
            uiwait(msgbox('Select set4 poles 1st time'));
            [clus4,xs4,ys4] = selectdata('selectionmode','lasso');
            
            for k=i:nplane %asses cluster value
                for j=1:nplane
                    
                    if xs4{k,1}==xp(j) & ys4{k,1}==yp(j)
                        idx3(1,j)=4;
                    else
                    end
                end
            end
        end
        
        if i==5 %set5
            uiwait(msgbox('Select set5 poles 1st time'));
            [clus5,xs5,ys5] = selectdata('selectionmode','lasso');
            
            for k=i:nplane %asses cluster value
                for j=1:nplane
                    
                    if xs5{k,1}==xp(j) & ys5{k,1}==yp(j)
                        idx3(1,j)=5;
                    else
                    end
                end
            end
        end
        if i==6 %set6
            uiwait(msgbox('Select set6 poles 1st time'));
            [clus6,xs6,ys6] = selectdata('selectionmode','lasso');
            
            for k=i:nplane %asses cluster value
                for j=1:nplane
                    
                    if xs6{k,1}==xp(j) & ys6{k,1}==yp(j)
                        idx3(1,j)=6;
                    else
                    end
                end
            end
        end
        if i==7 %set7
            uiwait(msgbox('Select set7 poles 1st time'));
            [clus7,xs7,ys7] = selectdata('selectionmode','lasso');
            
            for k=i:nplane %asses cluster value
                for j=1:nplane
                    
                    if xs7{k,1}==xp(j) & ys7{k,1}==yp(j)
                        idx3(1,j)=7;
                    else
                    end
                end
            end
        end
        Stereogram(dipdir, dip, nplane, idx3, xp, yp)
        %------------------- SECOND CHANCE TO CHANGE VALUES-------------
        if i==1 %set1
            uiwait(msgbox('Select set1 poles 2nd time'));
            [clus1,xs1,ys1] = selectdata('selectionmode','lasso')
            
            for k=i:nplane %asses cluster value
                for j=1:nplane
                    
                    if xs1{k,1} == xp(j) & ys1{k,1}== yp(j)
                        idx3(1,j)=1;
                    else
                    end
                end
            end
        end
        
        if i==2 %set2
            uiwait(msgbox('Select set2 poles 2nd time'));
            [clus2,xs2,ys2] = selectdata('selectionmode','lasso');
            
            for k=i:nplane %asses cluster value
                for j=1:nplane
                    
                    if xs2{k,1}==xp(j) & ys2{k,1}==yp(j)
                        idx3(1,j)=2;
                    else
                    end
                end
            end
        end
        if i==3 %set3
            uiwait(msgbox('Select set3 poles 2nd time'));
            [clus3,xs3,ys3] = selectdata('selectionmode','lasso');
            
            for k=i:nplane %asses cluster value
                for j=1:nplane
                    
                    if xs3{k,1}==xp(j) & ys3{k,1}==yp(j)
                        idx3(1,j)=3;
                    else
                    end
                end
            end
        end
        
        if i==4 %set4
            uiwait(msgbox('Select set4 poles 2nd time'));
            [clus4,xs4,ys4] = selectdata('selectionmode','lasso');
            
            for k=i:nplane %asses cluster value
                for j=1:nplane
                    
                    if xs4{k,1}==xp(j) & ys4{k,1}==yp(j)
                        idx3(1,j)=4;
                    else
                    end
                end
            end
        end
        
        if i==5 %set5
            uiwait(msgbox('Select set5 poles 2nd time'));
            [clus5,xs5,ys5] = selectdata('selectionmode','lasso');
            
            for k=i:nplane %asses cluster value
                for j=1:nplane
                    
                    if xs5{k,1}==xp(j) & ys5{k,1}==yp(j)
                        idx3(1,j)=5;
                    else
                    end
                end
            end
        end
        if i==6 %set6
            uiwait(msgbox('Select set6 poles 2nd time'));
            [clus6,xs6,ys6] = selectdata('selectionmode','lasso');
            
            for k=i:nplane %asses cluster value
                for j=1:nplane
                    
                    if xs6{k,1}==xp(j) & ys6{k,1}==yp(j)
                        idx3(1,j)=6;
                    else
                    end
                end
            end
        end
        if i==7 %set7
            uiwait(msgbox('Select set7 poles 2nd time'));
            [clus7,xs7,ys7] = selectdata('selectionmode','lasso');
            
            for k=i:nplane %asses cluster value
                for j=1:nplane
                    
                    if xs7{k,1}==xp(j) & ys7{k,1}==yp(j)
                        idx3(1,j)=7;
                    else
                    end
                end
            end
        end
        Stereogram(dipdir, dip, nplane, idx3, xp, yp)
    end

    for s=1:nclu%calculate new centroid
            sum_cluster(:,s)=[sum(N(1,1,find(idx3==s))) sum(N(1,2,find(idx3==s))) sum(N(1,3,find(idx3==s)))]; %Finds the rows with the same idc3 and sums them up
            % Length of the polevectors' sum
            L(s)=sqrt(sum(N(1,1,find(idx3==s)))^2+sum(N(1,2,find(idx3==s)))^2+sum(N(1,3,find(idx3==s)))^2);
            % Sumvector is normalised into a unitvector
            new_Nclu(:,s)=sum_cluster(:,s)/L(s);
    end

Centroid_calc
%------ K-Fisher ditributon coefficient----------------------------------
% This part was not inside the code of Markovaara-Koivisto and Laine (1).
% According Priest (2) the K-Fisher coefficient for a spherical  vector
% distribution can be approximated by the function:

%                       K = (N - 1)/ (N - R)

% where N = sum of magnitude of vectors;
%       R = magnitude of resultant of vector (sum of vector), R is allways lower than N;
% K ->infinity, for (N - R)->0; Higher K are for really thight set, Lower K
% are for broad set.

% Since pole vectors are unit vectors (magnitude=1), N represent the number
% of poles.
for  i = 1 : nplane
    for j = 1 : nclu
        if idx3(i) == j

            % correction that permits poles with same direction but opposit
            % side clustering

            if arcdistance(idx3(i), i) == antiarcdistance(idx3(i), i)
                N_corr(:,:,i)=antiN(:,:,i);
            else
                N_corr(:,:,i)=N(:,:,i);
            end
        end
    end

end


for i=1:nplane
    for j=1:3
        N_correct(i,j)=N_corr(1,j,i); % copy normal (pole) vector in a more appropiate matrix for further calculation
    end
end

%Calculate K-Fisher
N_SetPlane = hist( idx3, numel(unique(idx3)) );% count number of plane in each set--> N value

% Initializing resultant vector, r=(rx, ry, rz)
rx=zeros(1,nclu);
ry=zeros(1,nclu);
rz=zeros(1,nclu);

% calculate resultant of pole vectors
for i=1:nplane
    for j=1:nclu
        if idx3(i)==j
            rx(1,j)=rx(1,j)+N_correct(i,1);%resultant of value x for each set
            ry(1,j)=ry(1,j)+N_correct(i,2);%resultant of value y for each set
            rz(1,j)=rz(1,j)+N_correct(i,3);%resultant of value z for each set
        end
    end
end

% Initializing magnitude of resultant and K-fisher value
magn_r_xyz=zeros(1,nclu);
K_fisher=zeros(1,nclu);

for j=1:nclu
    magn_r_xyz(1,j)=sqrt(rx(1,j)^2 + ry(1,j)^2 + rz(1,j)^2);% calulate magnitude of resultant for each set
    K_fisher(1,j)=(N_SetPlane(1,j)-1)/(N_SetPlane(1,j)-magn_r_xyz(1,j));% calculate K-Fisher coeff. for each set
end

for i=1:180
    dipdir_node(i)=i*2;
end
for i=1:45
    dip_node(i)=i*2-1;
end


%----------- DRAWING OTHER STEREOPLOT/POLES PROJECTION --------------------
% Draws colour coded unit vectors on a stereographic sphere, in which dip 0
% degrees is at the bottom of the sphere and 90 degrees at the top.
Unitvectors_coloured(dipdir, dip, nplane, idx3)

% Calculates the mean attitudes of the clusters
[dipdireigv, dipeigv]=Eigenvector(dipdir, dip, idx3);

% Draws a stereographic projection with the mean attitudes of the clusters
StereogramEig(dipdir, dip, nplane, idx3)

thetaeig=(90-dipdireigv);
reig=sqrt(2)*sind((90-dipeigv-90)/2);
for n=1:max(idx3)
    xeigp(n) = reig(n)*cosd(thetaeig(n));
    yeigp(n) = reig(n)*sind(thetaeig(n));
end
plot(xeigp, yeigp, 'kO')

disp(['########## General Information ############'])
disp(['Total N. of Plane,      ', num2str(nplane, '%3.2f')])
for j=1:nclu
    disp(['################ Set ', num2str(j),' #####################'])
    disp(['Plane N.,           ', num2str(N_SetPlane(j), '%3.2f')])
    disp(['DipDir,             ', num2str(dipdireigv(j), '%3.2f')])
    disp(['Dip,                ', num2str(dipeigv(j), '%3.2f')])
    disp(['K Fisher`s coeff.,  ', num2str(K_fisher(j), '%3.2f')])
end

% uiwait(msgbox('Select folder for save'));
% pathsave=uigetdir(pathname, 'Select folder for save');
% save(fullfile(pathsave,'cluster_results.mat'));
