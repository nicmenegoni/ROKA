
Here[fnPC, pnPC] = uigetfile({'*.txt', 'Select a pointcloud in txt'},'Select a pointcloud');
PC=importdata(fullfile(pnPC, fnPC));

%Create a point cloud object.
ptCloud = pointCloud(xyzPoints);

%Specify a query point and the number of nearest neighbors to be identified.
K = 220;
indices=zeros(length(PC(:,1)),K);
%Get the indices and the distances of K nearest neighboring points.
%N.bb to get all the indices for a cloud ogf 174255 points and a K = 220 it
%takes 91sec
tic
for i = 1: length(PC(:,1))
    
    %[indices,dists] = findNearestNeighbors(ptCloud,PC(i,:),K);
    [indices(i,:)] = findNearestNeighbors(ptCloud,PC(i,:),K);
    
    %Display the point cloud. Plot the query point and their nearest neighbors.
end
%in this way you can call the Knn for a selected point
 tempPC=PC(indices(1,:),:)
 
 %Here plot the Knn for a slected point
toc
qplot=0;
if qplot=1
    figure
    pcshow(ptCloud)
    hold on
    plot3(point(1),point(2),point(3),'*r')
    plot3(ptCloud.Location(indices,1),ptCloud.Location(indices,2),ptCloud.Location(indices,3),'*')
    legend('Point Cloud','Query Point','Nearest Neighbors','Location','southoutside','Color',[1 1 1])
    hold off
end