function [int_in_out] = lineinsidewindow(num_Int,v1,v2,v3,v4,A_SP,SP_N,SP_center,Int_data)
line=[Int_data.x1, Int_data.y1,Int_data.z1,Int_data.x2-Int_data.x1,Int_data.y2-Int_data.y1,Int_data.z2-Int_data.z1];
int_in_out=zeros(num_Int,1);
for i=1:num_Int %Selection of plane inside the rectangular window;
%Here below the modified function of David Legland (INRA TPV URPOI - BIA IMASTE) is
%embedded
tol = 1e-14;%tolerance for line-plane intersection calclulation 
% difference between origins of plane and line
dp = SP_center - line(i,1:3);
% dot product of line direction with plane normal
denom = sum(SP_N .* line(i,4:6));
% relative position of intersection point on line (can be inf in case of a
% line parallel to the plane)
t = sum(SP_N .* dp) ./ denom;
% compute coord of intersection point
point = line(i,1:3)+ [t t t].* line(i,4:6);

% set indices of line and plane which are parallel to NaN
par = abs(denom) < tol;
point(par,:) = NaN;

if ~isnan(point)% logical operator, if point is a number =1, if si not a number (NaN) = 0
        [A1_12, A1_13, A1_24, A1_34]=SPtriangle(v1,v2,v3,v4,point);
        sumA1=sum([A1_12, A1_13, A1_24, A1_34]);
        if  abs (round(sumA1,3) - round(A_SP,3))<0.01 %if the area differs from lower than 1 cm the point is consider inside
            int_in_out(i)=1;
        end
end
end