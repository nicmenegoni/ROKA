function [maxMax, minMax, maxMin,minMin]=boundingBoxPlane(SPpoints)
% number of points
n = size(SPpoints, 1);

% compute centroid
SPcenter = mean(SPpoints);

% compute the covariance matrix
covPts = cov(SPpoints)/n;
[U, S] = svd(covPts);
[V] = eig(cov(SPpoints));
radii = sqrt(5) * sqrt(diag(S)*n)';
maxdir=U(:,1)';%direction of maximum axis
maxmagn=radii(1);%magnitude of max semiaxis
mindir=U(:,2)';%direction minimum axes
minmagn=radii(2);%magn. of min axis
maxvector=maxmagn*maxdir;
minvector=minmagn*mindir;
SP_N = V(:,1)';
if SP_N(1,3)<0 %if normal is oriented downward
    SP_N(1,1)=-SP_N(1,1);
    SP_N(1,2)=-SP_N(1,2);
    SP_N(1,3)=-SP_N(1,3);
end
out=convhull(SPpoints);
extremes=SPpoints(out,:);
SPpointPlaneMaxMagn=createPlane(SPcenter, maxvector);
SPpointPlaneMinMagn=createPlane(SPcenter, minvector);
SPPlane=createPlane(SPcenter,SP_N);
PT=zeros(n,3);
for i=1:length(extremes)
PT(i,:) = projPointOnPlane(extremes(i,:), SPPlane);
end
PTdistanzaMaxMagn=zeros(length(PT),1);
PTdistanzaMinMagn=zeros(length(PT),1);
for i=1:length(PT)
    
    PTdistanzaMaxMagn(i)=distancePointPlane(PT(i,:), SPpointPlaneMaxMagn);
    
    PTdistanzaMinMagn(i)=distancePointPlane(PT(i,:), SPpointPlaneMinMagn);
    
end
[maxMax]=max(PTdistanzaMaxMagn);
[minMax]=min(PTdistanzaMaxMagn);
[maxMin]=max(PTdistanzaMinMagn);
[minMin]=min(PTdistanzaMinMagn);
end