function expAnalysis(pathname,Fracdata,Fracset,Int_data,CDM,CIM,PC,nCritic,uselatlimits,slopeDipdirDip,PCDicsInters,PCIntInters,overhanging)
%% LOG
%modified 2020/04/27--> an 'exist' function is added before the exportation
%of the dxf in order to avoid the multiple exporting of the crticial
%discontinuity planes and intersetcions
%Modified 2020/05/19--> the matrix CDM and CIM are added in order to
%simplify calculation, and also a process toexport the point cloiud with
%the number of ceritical disconinuities was added;
%CDM matrix contains the critical value of the disconinuity in this order:
%                   1)PS; 2) FT;
%CIM matrix contains the critical value of the intersections in this order:
%                   1)WS; 2) DT; 3) OT

%% FUNCTION CODE
warning('off')
Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};
disp('Strarting to export the critical discontinuities')
for i=1:length(Fracdata{:,1}) %export critical plane
    clearvars FID
    %% export PlanarSliding critical CDM(:,1)
    if CDM(i,1)>0
        theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
        v=null(Fracdata{i,7:9});% calculate vectors needed to plot the discs
        points=repmat(Fracdata{i,4:6}',1,size(theta,2))+Fracdata{i,3}*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
        
        % Change name to the coordinate in a better and more resonable name
        X=points(1,:)'; Y=points(2,:)'; Z=points(3,:)';
        % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
        % to export DXF for each plane
        
        if ispc
            if uselatlimits==1
                if exist(fullfile(pathname,['KynAnalysis\Disc\PlanarSlidingLatLimits\Set', num2str(Fracset.Set(i)),'\Critic_Set_',num2str(Fracset.Set(i)),'Disc',num2str(i),'.dxf']),'file')
                else
                    mkdir (pathname,(['KynAnalysis\Disc\PlanarSlidingLatLimits\Set', num2str(Fracset.Set(i))]))
                    dxf_name=(['Critic_Set_',num2str(Fracset.Set(i)),'Disc',num2str(i),'.dxf']);
                    FID=dxf_open(fullfile(pathname,(['KynAnalysis\Disc\PlanarSlidingLatLimits\Set', num2str(Fracset.Set(i))])),dxf_name);
                    FID = dxf_set(FID,'Color',Color{5});
                    dxf_polyline(FID, X, Y, Z);
                    dxf_close(FID); % end of DXF exportation
                end
            elseif uselatlimits==0
                if exist(fullfile(pathname,['KynAnalysis\Disc\PlanarSlidingNoLatLimits\Set', num2str(Fracset.Set(i)),'\Critic_Set_',num2str(Fracset.Set(i)),'Disc',num2str(i),'.dxf']),'file')
                else
                    mkdir (pathname,(['KynAnalysis\Disc\PlanarSlidingNoLatLimits\Set', num2str(Fracset.Set(i))]))
                    dxf_name=(['Critic_Set_',num2str(Fracset.Set(i)),'Disc',num2str(i),'.dxf']);
                    FID=dxf_open(fullfile(pathname,(['KynAnalysis\Disc\PlanarSlidingNoLatLimits\Set', num2str(Fracset.Set(i))])),dxf_name);
                    FID = dxf_set(FID,'Color',Color{3});
                    dxf_polyline(FID, X, Y, Z);
                    dxf_close(FID); % end of DXF exportation
                end
            end
        elseif ismac
            if uselatlimits==1
                if exist(fullfile(pathname,['KynAnalysis/Disc/PlanarSlidingLatLimits/Set', num2str(Fracset.Set(i)),'/Critic_Set_',num2str(Fracset.Set(i)),'Disc',num2str(i),'.dxf']),'file')
                else
                    mkdir (pathname,(['KynAnalysis/Disc/PlanarSlidingLatLimits/Set', num2str(Fracset.Set(i))]))
                    dxf_name=(['Critic_Set_',num2str(Fracset.Set(i)),'Disc',num2str(i),'.dxf']);
                    FID=dxf_open(fullfile(pathname,(['KynAnalysis/Disc/PlanarSlidingLatLimits/Set', num2str(Fracset.Set(i))])),dxf_name);
                    FID = dxf_set(FID,'Color',Color{5});
                    dxf_polyline(FID, X, Y, Z);
                    dxf_close(FID); % end of DXF exportation
                end
            elseif uselatlimits==0
                if exist(fullfile(pathname,['KynAnalysis/Disc/PlanarSlidingNoLatLimits/Set', num2str(Fracset.Set(i)),'/Critic_Set_',num2str(Fracset.Set(i)),'Disc',num2str(i),'.dxf']),'file')
                else
                    mkdir (pathname,(['KynAnalysis/Disc/PlanarSlidingNoLatLimits/Set', num2str(Fracset.Set(i))]))
                    dxf_name=(['Critic_Set_',num2str(Fracset.Set(i)),'Disc',num2str(i),'.dxf']);
                    FID=dxf_open(fullfile(pathname,(['KynAnalysis/Disc/PlanarSlidingNoLatLimits/Set', num2str(Fracset.Set(i))])),dxf_name);
                    FID = dxf_set(FID,'Color',Color{3});
                    dxf_polyline(FID, X, Y, Z);
                    dxf_close(FID); % end of DXF exportation
                end
            end
        end
    end
    
    %% Export Flexural Toppling critical discontintuies (CDM(:,2)
    if CDM(i,2)>0
        theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
        v=null(Fracdata{i,7:9});% calculate vectors needed to plot the discs
        points=repmat(Fracdata{i,4:6}',1,size(theta,2))+Fracdata{i,3}*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
        % Change name to the coordinate in a better and more resonable name
        X=points(1,:)'; Y=points(2,:)'; Z=points(3,:)';
        % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
        % to export DXF for each plane
        if ispc
            if exist(fullfile(pathname,['KynAnalysis\Disc\FlexuralToppling\Set', num2str(Fracset.Set(i)),'\Critic_Set_',num2str(Fracset.Set(i)),'Disc',num2str(i),'.dxf']),'file')
            else
                mkdir (pathname,(['KynAnalysis\Disc\FlexuralToppling\Set', num2str(Fracset.Set(i))]))
                dxf_name=(['Critic_Set_',num2str(Fracset.Set(i)),'Disc',num2str(i),'.dxf']);
                FID=dxf_open(fullfile(pathname,(['KynAnalysis\Disc\FlexuralToppling\Set', num2str(Fracset.Set(i))])),dxf_name);
                FID = dxf_set(FID,'Color',Color{5});
                dxf_polyline(FID, X, Y, Z);
                dxf_close(FID); % end of DXF exportation
            end
            
        elseif ismac
            if exist(fullfile(pathname,['KynAnalysis/Disc/FlexuralToppling/Set', num2str(Fracset.Set(i)),'/Critic_Set_',num2str(Fracset.Set(i)),'Disc',num2str(i),'.dxf']),'file')
            else
                mkdir (pathname,(['KynAnalysis/Disc/FlexuralToppling/Set', num2str(Fracset.Set(i))]))
                dxf_name=(['Critic_Set_',num2str(Fracset.Set(i)),'Disc',num2str(i),'.dxf']);
                FID=dxf_open(fullfile(pathname,(['KynAnalysis/Disc/FlexuralToppling/Set', num2str(Fracset.Set(i))])),dxf_name);
                FID = dxf_set(FID,'Color',Color{5});
                dxf_polyline(FID, X, Y, Z);
                dxf_close(FID); % end of DXF exportation
            end
            
        end
    end
    
end
for i=1:length(Int_data{:,1}) %export critical Intersection
    %% export WedgeSliding critical: CIM(:,1)
    if CIM(i,1)>0
        % Change name to the coordinate in a better and more resonable name
        X=[Int_data.x1(i);Int_data.x2(i)]; Y=[Int_data.y1(i);Int_data.y2(i)]; Z=[Int_data.z1(i);Int_data.z2(i)];
        % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
        % to export DXF for each plane
        if ispc
            if uselatlimits==1
                if exist(fullfile(pathname,['KynAnalysis\Inters\WedgeSlidingLatLimits\','Critic_Set_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']),'file')
                else
                    mkdir (pathname,'KynAnalysis\Inters\WedgeSlidingLatLimits\')
                    dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
                    FID=dxf_open(fullfile(pathname,'KynAnalysis\Inters\WedgeSlidingLatLimits\'),dxf_name);
                    FID = dxf_set(FID,'Color',Color{5});
                    dxf_polyline(FID, X, Y, Z);
                    dxf_close(FID); % end of DXF exportation
                end
            elseif uselatlimits==0
                if exist(fullfile(pathname,['KynAnalysis\Inters\WedgeSlidingNoLatLimits\','Critic_Set_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']),'file')
                else
                    mkdir (pathname,'KynAnalysis\Inters\WedgeSlidingNoLatLimits\')
                    dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
                    FID=dxf_open(fullfile(pathname,'KynAnalysis\Inters\WedgeSlidingNoLatLimits\'),dxf_name);
                    FID = dxf_set(FID,'Color',Color{3});
                    dxf_polyline(FID, X, Y, Z);
                    dxf_close(FID); % end of DXF exportation
                end
            end
        elseif ismac
            if uselatlimits==1
                if exist(fullfile(pathname,['KynAnalysis/Inters/WedgeSlidingLatLimits/','Critic_Set_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']),'file')
                else
                    mkdir (pathname,'KynAnalysis/Inters/WedgeSlidingLatLimits/')
                    dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
                    FID=dxf_open(fullfile(pathname,'KynAnalysis/Inters/WedgeSlidingLatLimits/'),dxf_name);
                    FID = dxf_set(FID,'Color',Color{5});
                    dxf_polyline(FID, X, Y, Z);
                    dxf_close(FID); % end of DXF exportation
                end
            elseif uselatlimits==0
                if exist(fullfile(pathname,['KynAnalysis/Inters/WedgeSlidingNoLatLimits/','Critic_Set_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']),'file')
                else
                    mkdir (pathname,'KynAnalysis/Inters/WedgeSlidingNoLatLimits/')
                    dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
                    FID=dxf_open(fullfile(pathname,'KynAnalysis/Inters/WedgeSlidingNoLatLimits/'),dxf_name);
                    FID = dxf_set(FID,'Color',Color{3});
                    dxf_polyline(FID, X, Y, Z);
                    dxf_close(FID); % end of DXF exportation
                end
            end
        end
    end
    %% export DirectToppling critical Intersections: CIM(:,2)
    if CIM(i,2)>0
        
        % Change name to the coordinate in a better and more resonable name
        X=[Int_data.x1(i);Int_data.x2(i)]; Y=[Int_data.y1(i);Int_data.y2(i)]; Z=[Int_data.z1(i);Int_data.z2(i)];
        % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
        % to export DXF for each plane
        
        if ispc
            if uselatlimits==1
                if exist(fullfile(pathname,['KynAnalysis\Inters\DirectTopplingLatLimits\','Critic_Set_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']),'file')
                else
                    mkdir (pathname,'KynAnalysis\Inters\DirectTopplingLatLimits\')
                    dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
                    FID=dxf_open(fullfile(pathname,'KynAnalysis\Inters\DirectTopplingLatLimits\'),dxf_name);
                    FID = dxf_set(FID,'Color',Color{5});
                    dxf_polyline(FID, X, Y, Z);
                    dxf_close(FID); % end of DXF exportation
                end
            elseif uselatlimits==0
                if exist(fullfile(pathname,['KynAnalysis\Inters\DirectTopplingNoLatLimits\','Critic_Set_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']),'file')
                else
                    mkdir (pathname,'KynAnalysis\Inters\DirectTopplingNoLatLimits\')
                    dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
                    FID=dxf_open(fullfile(pathname,'KynAnalysis\Inters\DirectTopplingNoLatLimits\'),dxf_name);
                    FID = dxf_set(FID,'Color',Color{3});
                    dxf_polyline(FID, X, Y, Z);
                    dxf_close(FID); % end of DXF exportation
                end
            end
        elseif ismac
            if uselatlimits==1
                if exist(fullfile(pathname,['KynAnalysis/Inters/DirectTopplingLatLimits/','Critic_Set_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']),'file')
                else
                    mkdir (pathname,'KynAnalysis/Inters/DirectTopplingLatLimits/')
                    dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
                    FID=dxf_open(fullfile(pathname,'KynAnalysis/Inters/DirectTopplingLatLimits/'),dxf_name);
                    FID = dxf_set(FID,'Color',Color{5});
                    dxf_polyline(FID, X, Y, Z);
                    dxf_close(FID); % end of DXF exportation
                end
            elseif uselatlimits==0
                if exist(fullfile(pathname,['KynAnalysis/Inters/DirectTopplingNoLatLimits/','Critic_Set_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']),'file')
                else
                    mkdir (pathname,'KynAnalysis/Inters/DirectTopplingNoLatLimits/')
                    dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
                    FID=dxf_open(fullfile(pathname,'KynAnalysis/Inters/DirectTopplingNoLatLimits/'),dxf_name);
                    FID = dxf_set(FID,'Color',Color{3});
                    dxf_polyline(FID, X, Y, Z);
                    dxf_close(FID); % end of DXF exportation
                end
            end
        end
    end
    %% export ObliqueToppling critical Intersections: CIM(:,3)
    if CIM(i,3)>0
        
        % Change name to the coordinate in a better and more resonable name
        X=[Int_data.x1(i);Int_data.x2(i)]; Y=[Int_data.y1(i);Int_data.y2(i)]; Z=[Int_data.z1(i);Int_data.z2(i)];
        % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
        % to export DXF for each plane
        
        if ispc
            if exist(fullfile(pathname,['KynAnalysis\Inters\ObliqueToppling\','Critic_Set_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']),'file')
            else
                mkdir (pathname,'KynAnalysis\Inters\ObliqueToppling\')
                dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
                FID=dxf_open(fullfile(pathname,'KynAnalysis\Inters\ObliqueToppling\'),dxf_name);
                FID = dxf_set(FID,'Color',Color{5});
                dxf_polyline(FID, X, Y, Z);
                dxf_close(FID); % end of DXF exportation
            end
        elseif ismac
            if exist(fullfile(pathname,['KynAnalysis/Inters/ObliqueToppling/','Critic_Set_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']),'file')
            else
                mkdir (pathname,'KynAnalysis/Inters/ObliqueToppling/')
                dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
                FID=dxf_open(fullfile(pathname,'KynAnalysis/Inters/ObliqueToppling/'),dxf_name);
                FID = dxf_set(FID,'Color',Color{5});
                dxf_polyline(FID, X, Y, Z);
                dxf_close(FID); % end of DXF exportation
            end
            
        end
    end
end
disp('End of critical disconinuities export process')
disp('Starting to export the PointCloud')
disp(['->Exporting_results_at_= ',num2str(toc/60,'%.1f'), '(min)'])

%Previous to the result point cloud exportation, it removes the NaN value
PC(isnan(overhanging),:)=[];
slopeDipdirDip(isnan(overhanging),:)=[];
PCDicsInters(isnan(overhanging),:)=[];
PCIntInters(isnan(overhanging),:)=[];
nCritic(isnan(overhanging),:)=[];
overhanging(isnan(overhanging),:)=[];
fid = fopen(fullfile(pathname,'KynAnPC_xyz_PS_FT_WS_DT_OT.txt'),'wt');
fprintf(fid, 'X Y Z DipDir Dip Overhanging AllDisc_inters AllInt_inters PlanarSliding FlexuralToppling WedgeSliding DirectToppling ObliqueToppling \n');
for i = 1 : length(PC)
    fprintf(fid, '%.3f %.3f %.3f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f \n', [PC(i,:),slopeDipdirDip(i,:),overhanging(i,:),PCDicsInters(i,:),PCIntInters(i,:),nCritic(i,:)]);
end
fclose(fid);
disp('End of the PC export process')
warning('on')
end