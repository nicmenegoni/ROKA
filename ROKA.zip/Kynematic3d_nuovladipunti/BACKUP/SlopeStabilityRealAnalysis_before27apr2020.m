%% Informazioni 11/12/2018
%
%DA MIGLIORARE:
% 1)    creare funzione per salvare i risultati in modo da rendere pi�
%       leggibile il codice;
% 2)    Il codice fuinziona perfettamente,
%       � presente solo un problema:
%       - in presenza di parete che hanno un'immerisone negativa (immergono
%       verso l'interno della parete, es. faccia 1 pinnacolo 2b) l'analisi
%       cinematica non avviene in maniera propria, in quanto l'orientazione
%       che viene calcolata � quella della faccia negativa.
%       N.B. queste pareti sono le 'ovehanging slope'
%        ________________________________________
%       |Sketch delle porzioni problematiche     | 
%       |                                        |
%       |                     piano campagna     |
%       |                _____v_________________ |
%       |                \                       |
%       |                 \                      |
%       | _______v_________\                     |
%       |                                        |
%       |________________________________________|
%

%% SLOPE STABILITY REAL ANALYSIS
close all; clear variables; tic
%Load fractures and scanline informations
%% 1) LOAD & READ XLSX CIRCULAR FRACTURE DATA
%This Matlab code works using a xlsx file in which xyz (center), Nxyz
%(orientation) and radius (dimension) of the discontinuities are stored.
uiwait(msgbox('Select fracture geometry data (XLSX file) to load'));
[filename, pathname] = uigetfile({'*.xlsx', 'Select fracture geometry data (XLSX file) to load'},'Select fracture geometry data (XLSX file) to load',...
    'F:\Menegoni\Ormea\Nuovi voli giugno 2017\Albris_SenseFly\parete\pointcloud\specific_KynAnalysis');% <- MODIFY the PATH

Fracdata=readtable(fullfile(pathname, filename));%read  fracture data stored 
%in the previously defined XLSX file.

%% 2) LOAD & READ XLSX SET BELONGING DATA
uiwait(msgbox('Select Fracture set data (XLSX file) to load'));
[filenameset, pathnameset] = uigetfile({'*.xlsx', 'Select Fracture set data (XLSX file) to load'},...
    'Select Fracture set data (XLSX file) to load',...
    pathname);
Fracset=readtable(fullfile(pathnameset, filenameset));%read fracture set 
%stored in the previously defined XLSX file.



%% 3) DEFINE DISCONTINUITES VARIABLES FOR CALCULATION
nplane=numel(Fracdata.Dip); %number of rows (= number of plane)
dipdir =  Fracdata.DipDirection(:);%Dip direction
dip =  Fracdata.Dip(:);%Dip angle
Set = Fracset.Set;% 
Set(isnan(Set)) = max(Set)+1;
Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};% define color for set from 1 to 7


%% 4) DEFINE MEAN ORIENTATIONS OF THE SETS and DRAW STEREOPLOTS
%Steroplot of poles of disconinuities--------------------------------------
[xp, yp]=Stereogram_colourless_Schmidt(dipdir, dip, nplane);
%load file xlsx in which set mean orientations are defined
uiwait(msgbox('Select Mean Orientation of Set data (XLSX file) to load'));
[filenameset, pathnameset] = uigetfile({'*.xlsx', 'Select Mean Orientation of Set data (XLSX file) to load'},'Select Mean Orientation of Set data (XLSX file) to load',...
    pathnameset);
MeanOrient=readtable(fullfile(pathnameset, filenameset));

DipDirDipClu=zeros(length(MeanOrient.Set),2);
for i=1:length(MeanOrient.Set) %Cycle to insert Set mean DipDirection and Dip
    DipDirDipClu (i,:) = [MeanOrient.MeanDipDirection(i),MeanOrient.MeanDip(i)];
end
nclu=length(MeanOrient.Set);
%Calculate Normal vector of Mean Orientation

V=zeros(1,3,nclu);
O=zeros(1,3,nclu);%CONTOLLARE
for r=1:nclu
    % Unit vector V, which origin is at the origo, in the orientation of the
    % dip/dip direction
    
    V(:,:,r)=[cosd(90-DipDirDipClu(r,1))*cosd(DipDirDipClu(r,2)) sind(90-DipDirDipClu(r,1))*cosd(DipDirDipClu(r,2)) -sind(DipDirDipClu(r,2))];
    % Unit vector O, which origin is at the origo, which is perpendicular to
    % the dip diprecion and is horizontal
    O(:,:,r)=[-sind(90-DipDirDipClu(r,1)) cosd(90-DipDirDipClu(r,1)) 0];
end
% Normal vector N of the surface defined with the vectors V and O
Nclu=zeros(nclu,3);

for k=1:nclu
    Nclu(k,:)=cross(V(:,:,k),O(:,:,k));
end
figure(3)
[xshp,yshp,zshp]=sphere;

s = surf(xshp,yshp,zshp,'FaceAlpha',0.3);
s.EdgeColor = 'none';
hold on
for i=1:nclu
    quiver3(0,0,0,-Nclu(i,1),-Nclu(i,2),-Nclu(i,3))
    hold on
end
legend('sphere','1','2','3','4')
axis equal
xlabel('East')
ylabel('North')
zlabel('Up')
view(0,90)
new_Nclu=Nclu;

% Draws the automated clustering results (kmeans-method) on a Schmidt's equal area net
Stereogram(dipdir, dip, nplane, Set, xp, yp)
if ispc
    for j=1:max(Set)
        mkdir (pathname,(['IntersSetsDisc\Set_', num2str(j)]))
    end
elseif ismac
    for j=1:max(Set)
        mkdir (pathname,(['IntersSetsDisc/Set_', num2str(j)]))
    end
end

%% 6) CYCLE FOR EVERY SCANPLANES
uiwait(msgbox('Select PointCloud  (TXT file) to load'));
[PCfn,PCpn]=uigetfile({'*.txt', 'Select PointCloud  (TXT file) to load'},'Select PointCloud  (TXT file) to load',...
    pathname);
uiwait(msgbox('Select PC coordinate traslation file to load'));
[Tfn,Tpn]=uigetfile({'*.XLSX', 'Select PC coordinate traslation file to load'},'Select PC coordinate traslation file to load' ,...
    pathname);
[PC, A_SP, SP_N, SP_center, v1, v2, v3, v4] = scanplanecalc(Tfn, Tpn, PCfn, PCpn);

%% 6a) DEFINE DISCONTINUITIES VARIABLES FOR CALCULATION
%     clearvars -except loop listing rowname pathnameSL Fracset n Fracdata filename pathname pointcloud SLtable Set new_Nclu MeanOrient SPtable%clear variables
dipdir =  Fracdata.DipDirection(:);dip =  Fracdata.Dip(:);%Dip direction & 
%Dip angle
xyz = [Fracdata.Xcenter(:), Fracdata.Ycenter(:), Fracdata.Zcenter(:)];%center
%of the circular discontinuity plane
Nxyz = [Fracdata.Nx(:),Fracdata.Ny(:),Fracdata.Nz(:)];% normal of the
%discontinuity plane
radius = Fracdata.Radius(:);%radius of the circular discontinuity plane
Set(isnan(Set)) = 0;%set of the ciruclar plane

%% 6c) CALCULATE INTERSECTION DISCONTINUTIES-SCANPLANE
%a) calculating intersection between discontinuties and the infinite scan plane;
[L, P_interA, SP_inters]= CircFracTraceMap(nplane,xyz, Nxyz, SP_center, SP_N, radius);%find intersection with an infinitre plane
%b) calculating intersection between discontinties and finite scan plane
[in_out] = planeinsidewindow(nplane,v1,v2,v3,v4,A_SP,SP_inters,P_interA,xyz,Nxyz,radius);

%Drawing fracture intersection 3D map
figure(4)% open figure in which plot this Trace map
draw3Dintersection(PC,P_interA,Nxyz, xyz, radius, filename, nplane, pathname, Set, in_out);
%Save all the information about the analysis perfomrmed before
SP = createPlane(SP_center, SP_N);%create ScanPlane
drawPlane3d(SP);%draw scan plane
view((180-MeanOrient.MeanDipDirection(1)),(90-MeanOrient.MeanDip(1)))

selFracdata=Fracdata(in_out>0,:);
selFracset=Fracset(in_out>0,:);

[Int_data]=intersectionCalculator(pathname,selFracdata,selFracset);
[PlanarSliding,FlexuralToppling,WedgeSliding,DirectToppling,ObliqueToppling,BasalPlane]=KynematicAnalysis(selFracset,Int_data, SP_N,pathname);

%Exporting Critical Discontinuites and Intersections
expAnalysis(pathname,filename,selFracdata,Int_data,PlanarSliding,FlexuralToppling,WedgeSliding,DirectToppling,ObliqueToppling,selFracset)
disp('#######################')
disp('END OF TOTAL PROCESSES')
toc
disp('#######################')
