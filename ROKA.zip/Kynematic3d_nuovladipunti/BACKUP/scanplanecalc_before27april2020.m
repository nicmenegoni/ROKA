function [PC, A_SP, SP_N, SP_center, v1, v2, v3, v4] = scanplanecalc(Tfn, Tpn, PCfn, PCpn)
% DESCRIPTION: %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function defines the scanplane geometry parameters (area,
% center, normals, vertices) reading the segmentation of the point cloud
% represneting the area interested.
% The point cloud must be translated because it is stored in UTM metric
% coordinates, but the measurments are stored in a specific local
% coordinate system (this is related to the problem of Cloud Compare).
% The scanplane is consider as a rectangular window with four vertices (v1,
% v2, v3 and v4)
%                       2D Sketch of rectangular scanplane
%                      v1_______v2
%                       |\      |
%                       | \     |
%                       |  \    |
%                       |   \   |      -->minvector
%                       |    \  |     |
%                       |     \ |     |
%                       |_______|     v
%                      v3      v4     maxvector
%
% the area of the polygon is equal at the area of the two triangles 
% (trianlge 134 and triangle 124)
%--------------------------------------------------------------------------
% INPUT VARIABLES:
%   PCfn, PCpn = filename (fn) and pathname (pn) of the file in which the
%                segmented point clouds (PC) is stored;
%   Tfn, Tpn = filename (fn) and pathname (pn) of the file in which the
%              translation values (x, y and z) to be applied to the PC are
%              stored.
%--------------------------------------------------------------------------
% OUTPUT VARIABLES:
%   PC = point cloud entity representing the segmentation of the 3D model;
%   A_SP = area of the calculated rectangular scan plane;
%   SP_N = normal of the calculated rectangular scan plane;
%   SP_center = center of the calculated rectangular scan plane;
%   v1,v2,v3,v4 = vertices of the calculated rectangular scan plane;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Traslftable=readtable(fullfile(Tpn,Tfn));
trasl=Traslftable{:,1:3};
PCtable=readtable(fullfile(PCpn,PCfn));
SPpoints=PCtable{:,1:3};
% Translate PC Coordinates
SPpoints(:,1)=SPpoints(:,1)+trasl(1);
SPpoints(:,2)=SPpoints(:,2)+trasl(2);
SPpoints(:,3)=SPpoints(:,3)+trasl(3);
PC = pointCloud(SPpoints);
figure(11)
pcshow(PC);
title('pointcloud')
hold on
%calculate elipsoid and draw it
ell = inertiaEllipsoid(SPpoints);
%drawEllipsoid(ell);
hold on

% number of points
n = size(SPpoints, 1);

% compute centroid
SP_center = mean(SPpoints);

% compute the covariance matrix
covPts = cov(SPpoints)/n;

% perform a principal component analysis with 2 variables,
% to extract inertia axes
[U, S] = svd(covPts);
[V, D] = eig(cov(SPpoints));
% extract length of each semi axis
radii = sqrt(5) * sqrt(diag(S)*n)';
quiver3(SP_center(1),SP_center(2),SP_center(3),U(1,1),U(2,1),U(3,1));
maxdir=U(:,1)';%direction of maximum axis
maxmagn=radii(1);%magnitude of max semiaxis
mindir=U(:,2)';%direction minimum axes
minmagn=radii(2);%magn. of min axis
maxvector=maxmagn*maxdir;
minvector=minmagn*mindir;
figure(4)
hold on
[maxMax, minMax, maxMin,minMin]=boundingBoxPlane(SPpoints);
v1=SP_center+minMax*maxdir+maxMin*mindir;
v2=SP_center+minMax*maxdir+minMin*mindir;
v3=SP_center+maxMax*maxdir+maxMin*mindir;
v4=SP_center+maxMax*maxdir+minMin*mindir;
scatter3(v1(1),v1(2),v1(3))
scatter3(v2(1),v2(2),v2(3))
scatter3(v3(1),v3(2),v3(3))
scatter3(v4(1),v4(2),v4(3))

SP_N = V(:,1)';
if SP_N(1,3)<0 %if normal is oriented downward
    SP_N(1,1)=-SP_N(1,1);
    SP_N(1,2)=-SP_N(1,2);
    SP_N(1,3)=-SP_N(1,3);
end

% Sketch of 2D polygon
% 1_______2
% |\      |
% | \     |
% |  \    |
% |   \   |      -->minvector
% |    \  |     |
% |     \ |     |
% |_______|     v
% 3       4     maxvector
%
%the area of the polygon is equal at the area of the two triangles

ons=[1 1 1];

 A_scanplane1 = 0.5*sqrt(det([v1(1),v2(1),v3(1);v1(2),v2(2),v3(2);ons])^2 +...
                         det([v1(2),v2(2),v3(2);v1(3),v2(3),v3(3);ons])^2 +...
                         det([v1(3),v2(3),v3(3);v1(1),v2(1),v3(1);ons])^2);%area triangle 1-2-3
 A_scanplane2 = 0.5*sqrt(det([v1(1),v2(1),v4(1);v1(2),v2(2),v4(2);ons])^2 +...
                         det([v1(2),v2(2),v4(2);v1(3),v2(3),v4(3);ons])^2 +...
                         det([v1(3),v2(3),v4(3);v1(1),v2(1),v4(1);ons])^2);%area triangle 1-2-4
A_SP =  A_scanplane1+A_scanplane2;% area rectangle 1-2-3-4
