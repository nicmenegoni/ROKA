% Digital Outcrop Model to Scan Line (DOM2SL)
%This cript is a tool for the virtual scan line anlayis of fractures or
%more in general of discontinuties. This tool works in this way: (a)
%fractures are mapped as polylines and saved as '.dxf' file using
%CloudCompare (CC) v.2.9 or newer; (b)the scanline is traced and saved
%using the same version of CC; (c)from dxf file, fractures plane are fitted
%using a total least square approach and (d) the scanline is plotted using
%its end-points; (d) fractures-scanline intersection are calculated.
close all
clear all
%Load fractures and scanline informations
%% LOAD & READ CSV DATA
uiwait(msgbox('Select XLSX file to load'));
if ismac %For OSX operative system
    [filename, pathname] = uigetfile({'*.xlsx', 'Select a XLSX file'},'mytitle',...
        '/Volumes/F/DATI/D_data/dottorato/DATI/Antola/Outcrop_models');% <- MODIFY the PATH
elseif ispc % For WINDOWS operative system
    [filename, pathname] = uigetfile({'*.xlsx', 'Select a CSV file'},'mytitle',...
        'C:\Users\Dr.Menegoni\Desktop\Antola\St1new');% <- MODIFY the PATH
end

Fracdata=readtable(fullfile(pathname, filename));
n=numel(Fracdata.Dip); %number of rows (= number of plane)


%% DEFINE VARIABLES FOR CALCULATION
dipdir =  Fracdata.DipDirection(:);%Dip direction
dip =  Fracdata.Dip(:);%Dip angle
xyz = [Fracdata.Xcenter(:), Fracdata.Ycenter(:), Fracdata.Zcenter(:)];
Nxyz = [Fracdata.Nx(:),Fracdata.Ny(:),Fracdata.Nz(:)];
radius = Fracdata.Radius(:);
nplane=n; % number of plane to plot in the stereogram

%% Read scanline DXF file
[filenameSL, pathnameSL]=uigetfile({'*.dxf', 'Select a DXF file'}, 'Select a DXF file',...
    'C:\Users\Dr.Menegoni\Desktop\Antola\St1new');% <- MODIFY the PATH
fId = fopen(fullfile(pathname,filenameSL));
c_ValAsoc = textscan(fId,'%d%s','Delimiter','\n');
fclose(fId);
% Code Group Matrix
m_GrCode = c_ValAsoc{1};
% Associated value String Cell
c_ValAsoc = c_ValAsoc{2};
%[m_GrCode,c_ValAsoc] = c_ValAsoc{:};
m_PosCero = find(m_GrCode==0);
%Is searched by (0,SECTION),(2,ENTITIES)
indInSecEnt = strmatch('ENTITIES',c_ValAsoc(m_PosCero(1:end-1)+1),'exact');
%(0,ENDSEC)
m_indFinSecEnt = strmatch('ENDSEC',c_ValAsoc(m_PosCero(indInSecEnt:end)),'exact');
% Entities Position
m_PosCero = m_PosCero(indInSecEnt:indInSecEnt-1+m_indFinSecEnt(1));
% Variable initiation
%accelerate?
c_Poi = cell(sum(strcmp('POINT',c_ValAsoc(m_PosCero))),2);
c_Poi = cell(1,2);
%
iPoi = 1;
% Loop on the Entities
for iEnt = 1:length(m_PosCero)-2
    m_GrCodeEnt = m_GrCode(m_PosCero(iEnt+1):m_PosCero(iEnt+2)-1);
    c_ValAsocEnt = c_ValAsoc(m_PosCero(iEnt+1):m_PosCero(iEnt+2)-1);
    nomEnt = c_ValAsocEnt{1};  %c_ValAsocEnt{m_PosCero(iEnt+1)}
    %In the entitie's name is assumed uppercase
    switch nomEnt
        case 'VERTEX'
            % (X,Y,Z) Position
            c_Poi{iPoi,1} = [str2double(f_ValGrCode(10,m_GrCodeEnt,c_ValAsocEnt)),...
                str2double(f_ValGrCode(20,m_GrCodeEnt,c_ValAsocEnt)),...
                str2double(f_ValGrCode(30,m_GrCodeEnt,c_ValAsocEnt))];
            % Layer
            c_Poi(iPoi,2) = f_ValGrCode(8,m_GrCodeEnt,c_ValAsocEnt);
            % Add properties
            %
            iPoi = iPoi+1;
            %case Add Entities
            
            % (X,Y,Z) vertexs
            
            
    end
end
Pscanline1=c_Poi{1,1};
Pscanline2=c_Poi{2,1};
Cscanline=mean(iPoi);%center of the scanline
Lscanline=   sqrt((Pscanline1(1)-Pscanline2(1))^2 ...
    + (Pscanline1(2)-Pscanline2(2))^2 ...
    + (Pscanline1(3)-Pscanline2(3))^2);%length of the scanline
%% Add Pointcloud to plot
[filenamePC, pathnamePC] = uigetfile({'*.txt', 'Select a txt file'},'mytitle',...
    'C:\Users\Dr.Menegoni\Desktop\Antola\St1new');%
PC=importdata(fullfile(pathnamePC, filenamePC));
%% CALCULATION INTERSECTION FRACTURES-SCANLINE

% -----------PLOT OF 3D DISCONTINUITIES AND SCANLINE -------------------------


%2)Find coefficients D of plane equations ( Maybe this Values is
%  meaningless, I have to check the code another time)
Dplane=zeros(nplane,1);% D parameters of plane equation (Ax+By+Cz+D=0)
for i= 1: nplane
    Dplane (i)= -dot(Nxyz(i,:),xyz(i,:));
end

%3) Normals have to be oriented upward!!! (Normals have to be horiented in same
%   direction if you want to calculate spacing)
for i=1:nplane
    if Nxyz(i,3)<0 %if normal is oriented downward
        Nxyz(i,1)=-Nxyz(i,1);
        Nxyz(i,2)=-Nxyz(i,2);
        Nxyz(i,3)=-Nxyz(i,3);
    else %if normal is oriented upward
        Nxyz(i,1)=Nxyz(i,1);
        Nxyz(i,2)=Nxyz(i,2);
        Nxyz(i,3)=Nxyz(i,3);
    end
end

%5) Plot the discs that represent the discontinuities
% figure(1)
% for i=1:nplane
%
%     theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
%     v=null(Nxyz(i,:));% calculate vectors needed to plot the discs
%     points=repmat(xyz(i,:)',1,size(theta,2))+radius(i)*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
%
%     % Change name to the coordinate in a better and more resonable name
%     X=points(1,:)';
%     Y=points(2,:)';
%     Z=points(3,:)';
%
%
%     hold on % hold on, box on and grid are useful for plotting
%     grid on
%     box on
%     fill3(points(1,:),points(2,:),points(3,:),'b', 'FaceAlpha', 0.5);%Plot 3D disc for each plane
%
%     xlabel('x-axis (East)')
%     ylabel('y-axis (Nord)')
%     zlabel('z-axis (Elev)')
%     hold on
%     grid on
%     box on
%
%     %     %Uncomment if you want to see the normals of the planes
%     %     quiver3(xyz(i,1), xyz(i,2), xyz(i,3), Nxyz(i,1), Nxyz(i,2), Nxyz(i,3),0.4)
%     %     hold on
%     %     grid on
%     %     box on
% end

% ------------CALCULATE INTERSECTION PLANES-LINE -------------------------
IntPTuncut=zeros(nplane,3);

%1) Calculate intersection between all planes and scanline------
figure(2)
for i=1:nplane
    
    PLANE = createPlane(xyz(i,:), Nxyz(i,:));%Set line properly for 'intersectLinePlane' and 'distancePoints3D' formulas
    LINE=createLine3d(Pscanline1, Pscanline2);%Set line properly for 'intersectLinePlane' and 'distancePoints3D' formulas
    IntPT_uncut (i,:) = intersectLinePlane(LINE, PLANE);% Gives coordinate of points of intersection
    %The previous formula calculate intersection points between plane and
    %line. Dimension of line is unlimited.
    %Next 8 strings need to select only the intersection the lye on the
    %scanline (on the limited segment).
    D_Pscan1_IntPT(i) = distancePoints3d(Pscanline1, IntPT_uncut(i,:));
    D_Pscan2_IntPT(i) = distancePoints3d(Pscanline2, IntPT_uncut(i,:));
    D_IntPT_centerPlane(i) = distancePoints3d(IntPT_uncut(i,:), xyz(i,:));
    UnOrd_distance(i,1)=D_Pscan1_IntPT(i);
    if D_Pscan1_IntPT(i)<Lscanline && D_Pscan2_IntPT(i)<Lscanline && D_IntPT_centerPlane(i)< radius(i)
        IntPT_uncut(i,:)= IntPT_uncut (i,:);
        UnOrd_distance(i,1)=UnOrd_distance(i,1)
        
        %plot fracture discs that intersect the scanline
        theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
        v=null(Nxyz(i,:));% calculate vectors needed to plot the discs
        points=repmat(xyz(i,:)',1,size(theta,2))+radius(i)*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
        
        % Change name to the coordinate in a better and more resonable name
        X=points(1,:)';
        Y=points(2,:)';
        Z=points(3,:)';
        
        
        hold on % hold on, box on and grid are useful for plotting
        grid on
        box on
        fill3(points(1,:),points(2,:),points(3,:),'b', 'FaceAlpha', 0.5);%Plot 3D disc for each plane
        
        xlabel('x-axis (East)')
        ylabel('y-axis (Nord)')
        zlabel('z-axis (Elev)')
        hold on
        grid on
        box on
    else
        IntPT_uncut(i,:)=NaN;%All points that don't belong to the scanline are unselected (defining NaN as coordinate value)
        UnOrd_distance(i,1)=NaN
    end
    
end

%2) It is created a new matrix which contain only non-NaN value (only
%points coordinate that lies on the scanline)
selectIntPT_cut = ~isnan( IntPT_uncut ) ;
selectUnOrd_dist = ~isnan( UnOrd_distance ) ;
pointIntersecting=IntPT_uncut(selectIntPT_cut);
UnOrd_dist=UnOrd_distance(selectUnOrd_dist);
npointIntersecting= (numel(pointIntersecting))/3;%count number of intersection points
IntPT_cut=zeros(npointIntersecting, 3);
Ord_dist=zeros(npointIntersecting,1);
for i=1:numel(pointIntersecting);
    IntPT_cut(ind2sub(size(IntPT_cut), i))=pointIntersecting(i);
    
end
for i=1:npointIntersecting;
    Ord_dist(i,1)=UnOrd_dist(i,1);
end

%Give order in point distribuition
% Matrix with all parameters
AllValue = zeros(npointIntersecting, 4);
for i = 1 : npointIntersecting
    AllValue(i,1)=Ord_dist(i);
    AllValue(i,2)=IntPT_cut(i,1);
    AllValue(i,3)=IntPT_cut(i,2);
    AllValue(i,4)=IntPT_cut(i,3);
end

% we have to decide the order of the plane
IntPT_cut_ord=zeros(npointIntersecting, 3);
Ord_dist_ord=zeros(npointIntersecting,1);
AllOrd=sortrows(AllValue); %Sort order: from lower to higher value;
for i = 1 : npointIntersecting
    Ord_dist_ord (i,1) = AllOrd(i,1);
    IntPT_cut_ord(i,1) = AllOrd(i,2);
    IntPT_cut_ord(i,2) = AllOrd(i,3);
    IntPT_cut_ord(i,3) = AllOrd(i,4);
end

%creare una matrice dove sono storaggiati tutti i punti ordinati e il cui
%primo punto � il Pscanline1 e l'ultimo il P-scanline2
Pointsforcalc=zeros(npointIntersecting + 2, 3);
for i = 1 : npointIntersecting
    for j=1:3
        Pointsforcalc(1,j)=Pscanline1(1,j);
        Pointsforcalc(i+1,j)=IntPT_cut_ord(i,j);
        Pointsforcalc(npointIntersecting + 2,j)=Pscanline2(1,j);
    end
end
%calculation of distances bewteen points for RQD estimation
for i=1:npointIntersecting+1
    D_RQD(i)=distancePoints3d(Pointsforcalc(i,:), Pointsforcalc(i+1,:));
end

for i=1:numel(D_RQD)
    if D_RQD(i)>0.10
        D_RQD(i)=D_RQD(i);
    else
        D_RQD(i)=NaN;
    end
end

%estimation of RQD
RQD=(nansum(D_RQD) / Lscanline)*100;

%Plot Scanline_Plane_and Intersection point
%Plot Scanline
figure(2)
drawEdge3d([Pscanline1,Pscanline2], 'color', 'r', 'linewidth', 4);
hold on
figure(2)
hold on
pcshow(PC)

figure(3)
drawEdge3d([Pscanline1,Pscanline2], 'color', 'r', 'linewidth', 4);
hold on

%5) Plot the point of intersection between fracturs and scanline the discontinuities
figure(2)

for i=1:numel(Pointsforcalc)/3
    drawPoint3d(Pointsforcalc(i,:))
    hold on
end
figure(3)
for i=1:numel(Pointsforcalc)/3
    drawPoint3d(Pointsforcalc(i,:))
    hold on
end
disp('#################################')
disp(['RQD = ', num2str(RQD)])
disp('#################################')

%% Calculate statistic

P10=npointIntersecting/Lscanline;% fracture intesity P01 (N#fractures/scanlineLength)
P

