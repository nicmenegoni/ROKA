%% Informazioni 29/03/2018
%DA MIGLIORARE:
% 1) creare funzione per salvare i risultati in modo da rendere pi�
% leggibile il codice;
% 2)
% Il codice fuinziona perfettamente,
% � presente solo un problema:
% ----> in presenza di parete che hanno un'immerisone negativa (immergono
% verso l'interno della parete, es. faccia 1 pinnacolo 2b) l'analisi
% cinematica non avviene in maniera propria, in quanto l'orrientazione che
% viene calcolata � quella della faccia negativa.
%                     
%                     piano campagna
%                _____v_________________
%                \
%                 \
% _______v_________\
%
%Sketch delle porzioni problematiche 







%% SLOPE STABILITY REAL ANALYSIS
close all
clear all
tic
%Load fractures and scanline informations
%% 1) LOAD & READ XLSX CIRCULAR FRACTURE DATA
%This Matlab code works using a xlsx file in which xyz (center), Nxyz
%(orientation) and radius (dimension) of the discontinuities are stored.

uiwait(msgbox('Select fracture geometry data (XLSX file) to load'));
[filename, pathname] = uigetfile({'*.xlsx', 'Select fracture geometry data (XLSX file) to load'},'Select fracture geometry data (XLSX file) to load',...
    'F:\Menegoni\Ormea\Nuovi voli giugno 2017\Albris_SenseFly\parete\pointcloud\specific_KynAnalysis');% <- MODIFY the PATH

Fracdata=readtable(fullfile(pathname, filename));
n=numel(Fracdata.Dip); %number of rows (= number of plane)

%% 2) LOAD & READ XLSX SET BELONGING DATA
uiwait(msgbox('Select Fracture set data (XLSX file) to load'));
[filenameset, pathnameset] = uigetfile({'*.xlsx', 'Select Fracture set data (XLSX file) to load'},'Select Fracture set data (XLSX file) to load',...
    pathname);
Fracset=readtable(fullfile(pathnameset, filenameset));
n=numel(Fracset.Set); %number of rows (= number of plane)


%% 3) DEFINE VARIABLES FOR CALCULATION
dipdir =  Fracdata.DipDirection(:);%Dip direction
dip =  Fracdata.Dip(:);%Dip angle
xyz = [Fracdata.Xcenter(:), Fracdata.Ycenter(:), Fracdata.Zcenter(:)];%x, y and z coordinates of the center of the planes
Nxyz = [Fracdata.Nx(:),Fracdata.Ny(:),Fracdata.Nz(:)];% components of the normal vectors of the planes that define the orientations
radius = Fracdata.Radius(:);% maximum dimension of the discontinuities mapped on the model
Set = Fracset.Set;% 
Set(isnan(Set)) = max(Set)+1;
nplane=n;
Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};% define color for set from 1 to 7


%% 4) DEFINE MEAN ORIENTATIONS OF THE SETS and DRAW STEREOPLOTS
%Steroplot of poles of disconinuities--------------------------------------
[xp, yp]=Stereogram_colourless_Schmidt(dipdir, dip, nplane);
%load file xlsx in which set mean orientations are defined
uiwait(msgbox('Select Mean Orientation of Set data (XLSX file) to load'));
[filenameset, pathnameset] = uigetfile({'*.xlsx', 'Select Mean Orientation of Set data (XLSX file) to load'},'Select Mean Orientation of Set data (XLSX file) to load',...
    pathnameset);
MeanOrient=readtable(fullfile(pathnameset, filenameset));

DipDirDipClu=zeros(length(MeanOrient.Set),2);
for i=1:length(MeanOrient.Set) %Cycle to insert Set mean DipDirection and Dip
    DipDirDipClu (i,:) = [MeanOrient.MeanDipDirection(i),MeanOrient.MeanDip(i)];
end
nclu=length(MeanOrient.Set);
%Calculate Normal vector of Mean Orientation

V=zeros(1,3,nclu);
for r=1:nclu
    % Unit vector V, which origin is at the origo, in the orientation of the
    % dip/dip direction
    
    V(:,:,r)=[cosd(90-DipDirDipClu(r,1))*cosd(DipDirDipClu(r,2)) sind(90-DipDirDipClu(r,1))*cosd(DipDirDipClu(r,2)) -sind(DipDirDipClu(r,2))];
    % Unit vector O, which origin is at the origo, which is perpendicular to
    % the dip diprecion and is horizontal
    O(:,:,r)=[-sind(90-DipDirDipClu(r,1)) cosd(90-DipDirDipClu(r,1)) 0];
end
% Normal vector N of the surface defined with the vectors V and O
Nclu=zeros(nclu,3);

for k=1:nclu
    Nclu(k,:)=cross(V(:,:,k),O(:,:,k));
end
figure(3)

[xshp,yshp,zshp]=sphere;
s = surf(xshp,yshp,zshp,'FaceAlpha',0.3)
s.EdgeColor = 'none';
hold on
for i=1:nclu
    quiver3(0,0,0,-Nclu(i,1),-Nclu(i,2),-Nclu(i,3))
    hold on
end
legend('sphere','1','2','3','4')
axis equal
xlabel('East')
ylabel('North')
zlabel('Up')
view(0,90)
new_Nclu=Nclu;

% Draws the automated clustering results (kmeans-method) on a Schmidt's equal area net
Stereogram(dipdir, dip, nplane, Set, xp, yp)

for j=1:max(Set)
    mkdir (pathname,(['IntersSetsDisc\Set_', num2str(j)]))
end


%% 6) CYCLE FOR EVERY SCANPLANES
uiwait(msgbox('Select PointCloud  (TXT file) to load'));
[PCfn,PCpn]=uigetfile({'*.txt', 'Select PointCloud  (TXT file) to load'},'Select PointCloud  (TXT file) to load',...
    pathname);
uiwait(msgbox('Select PC coordinate traslation file to load'));
[Tfn,Tpn]=uigetfile({'*.XLSX', 'Select PC coordinate traslation file to load'},'Select PC coordinate traslation file to load' ,...
    pathname);
Traslftable=readtable(fullfile(Tpn,Tfn));
trasl=Traslftable{:,1:3};
PCtable=readtable(fullfile(PCpn,PCfn));
SPpoints=PCtable{:,1:3};
% Translate PC Coordinates
SPpoints(:,1)=SPpoints(:,1)+trasl(1);
SPpoints(:,2)=SPpoints(:,2)+trasl(2);
SPpoints(:,3)=SPpoints(:,3)+trasl(3);
PC = pointCloud(SPpoints);
figure(1)
pcshow(PC);
title('pointcloud')
hold on
%calculate elipsoid and draw it
ell = inertiaEllipsoid(SPpoints);
drawEllipsoid(ell);
hold on

% number of points
n = size(SPpoints, 1);

% compute centroid
SPcenter = mean(SPpoints);

% compute the covariance matrix
covPts = cov(SPpoints)/n;

% perform a principal component analysis with 2 variables,
% to extract inertia axes
[U, S] = svd(covPts);
[V, D] = eig(cov(SPpoints));
% extract length of each semi axis
radii = sqrt(5) * sqrt(diag(S)*n)';
quiver3(SPcenter(1),SPcenter(2),SPcenter(3),U(1,1),U(2,1),U(3,1));
maxdir=U(:,1)';%direction of maximum axis
maxmagn=radii(1);%magnitude of max semiaxis
mindir=U(:,2)';%direction minimum axes
minmagn=radii(2);%magn. of min axis
maxvector=maxmagn*maxdir;
minvector=minmagn*mindir;
figure(4)
hold on
[maxMax, minMax, maxMin,minMin]=boundingBoxPlane(SPpoints);
v1=SPcenter+minMax*maxdir+maxMin*mindir;
v2=SPcenter+minMax*maxdir+minMin*mindir;
v3=SPcenter+maxMax*maxdir+maxMin*mindir;
v4=SPcenter+maxMax*maxdir+minMin*mindir;
scatter3(v1(1),v1(2),v1(3))
scatter3(v2(1),v2(2),v2(3))
scatter3(v3(1),v3(2),v3(3))
scatter3(v4(1),v4(2),v4(3))

SP_N = V(:,1)';
if SP_N(1,3)<0 %if normal is oriented downward
    SP_N(1,1)=-SP_N(1,1);
    SP_N(1,2)=-SP_N(1,2);
    SP_N(1,3)=-SP_N(1,3);
end

% Sketch of 2D polygon
% 1_______2
% |\      |
% | \     |
% |  \    |
% |   \   |      -->minvector
% |    \  |     |
% |     \ |     |
% |_______|     v
% 3       4     maxvector
%
%the area of the polygon is equal at the area of the two triangles

ons=[1 1 1];

 A_scanplane1 = 0.5*sqrt(det([v1(1),v2(1),v3(1);v1(2),v2(2),v3(2);ons])^2 +...
                         det([v1(2),v2(2),v3(2);v1(3),v2(3),v3(3);ons])^2 +...
                         det([v1(3),v2(3),v3(3);v1(1),v2(1),v3(1);ons])^2);%area triangle 1-2-3
 A_scanplane2 = 0.5*sqrt(det([v1(1),v2(1),v4(1);v1(2),v2(2),v4(2);ons])^2 +...
                         det([v1(2),v2(2),v4(2);v1(3),v2(3),v4(3);ons])^2 +...
                         det([v1(3),v2(3),v4(3);v1(1),v2(1),v4(1);ons])^2);%area triangle 1-2-4
A_SP =  A_scanplane1+A_scanplane2;% area rectangle 1-2-3-4
%% 6a) ReDEFINE VARIABLES FOR CALCULATION
%     clearvars -except loop listing rowname pathnameSL Fracset n Fracdata filename pathname pointcloud SLtable Set new_Nclu MeanOrient SPtable%clear variables
dipdir =  Fracdata.DipDirection(:);%Dip direction
dip =  Fracdata.Dip(:);%Dip angle
xyz = [Fracdata.Xcenter(:), Fracdata.Ycenter(:), Fracdata.Zcenter(:)];
Nxyz = [Fracdata.Nx(:),Fracdata.Ny(:),Fracdata.Nz(:)];
radius = Fracdata.Radius(:);

Set(isnan(Set)) = 0;
n=numel(Fracdata.Dip(:));
nplane=n;

%% 6c) CALCULATE INTERSECTION FRACTURES-SCANPLANE


%calculation intersection with CricFracTraceMap function
[L, P_interA, SP_inters]= CircFracTraceMap(nplane,xyz, Nxyz, SPcenter, SP_N, radius);%find intersection with an infinitre plane

for i=1:nplane %Selection of plane inside the rectangular windows
    if SP_inters(i)==1
        %define type of intersection 1, 2 and 3
        clearvars A1_12 A1_13 A1_24 A1_34 A2_12 A2_13 A2_24 A2_34 point12 point13 point24 point34 fracplane
        [A1_12, A1_13, A1_24, A1_34]=SPtriangle(v1,v2,v3,v4,P_interA(i,1:3));
        [A2_12, A2_13, A2_24, A2_34]=SPtriangle(v1,v2,v3,v4,P_interA(i,4:6));
        sumA1=sum([A1_12, A1_13, A1_24, A1_34]);
        sumA2=sum([A2_12, A2_13, A2_24, A2_34]);
        if  round(sumA1,3) == round(A_SP,3) && round(sumA2,3) == round(A_SP,3)
            
            in_out(i)=1;%type 1--> intersection end-points are inside the window
            
        elseif (round(sumA1,3) > round(A_SP,3) && round(sumA2,3) == round(A_SP,3)) || (round(sumA1,3) == round(A_SP,3) && round(sumA2,3) > round(A_SP,3))
            in_out(i)=2;%type 2--> an intersection end-point is inside the window and the other is outside
        else
            %type of intersection 3
            fracplane=createPlane(xyz(i,:), Nxyz(i,:));
            point12 = intersectEdgePlane([v1,v2], fracplane);
            point13 = intersectEdgePlane([v1,v3], fracplane);
            point24 = intersectEdgePlane([v2,v4], fracplane);
            point34 = intersectEdgePlane([v3,v4], fracplane);
            d12=distancePoints3d(xyz(i,:), point12);
            d13=distancePoints3d(xyz(i,:), point13);
            d24=distancePoints3d(xyz(i,:), point24);
            d34=distancePoints3d(xyz(i,:), point34);
            if d12 <= radius(i) || d13 <= radius(i) || d24 <= radius(i) || d34 <= radius(i)
                in_out(i)=3;
            else
                in_out(i)=0;
            end
        end
    elseif SP_inters(i)==0
        in_out(i)=0;
        
    end
end

%Drawing fracture intersection 3D map
figure(4)% open figure in which plot this Trace map
pcshow(PC);
hold on
xlabel('X(East)')
ylabel('Y(Nord)')
zlabel('Z(Elev)')
axis equal
hold on
grid on
box on
Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};
for i=1:nplane
    if in_out(i)>0
        
        figure(4)
        
        drawEdge3d(P_interA(i,:), 'color', Color{Set(i)}, 'linewidth', 4);%plot lines of intersection
        
        hold on
        
        
        theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
        v=null(Nxyz(i,:));% calculate vectors needed to plot the discs
        points=repmat(xyz(i,:)',1,size(theta,2))+radius(i)*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
        
        % Change name to the coordinate in a better and more resonable name
        X=points(1,:)';
        Y=points(2,:)';
        Z=points(3,:)';
        fill3(points(1,:),points(2,:),points(3,:),Color{Set(i)}, 'FaceAlpha', 0.5);%Plot 3D disc for each plane
        % With the below loop matlab could export DXF with different color in base
        % of set
        for j=1:max(Set)
            if Set(i)==j
                % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
                % to export DXF for each plane
                filename_mod=filename(1:end-4);
                % name is written in this way:
                % (number of set)_CircPlane_(number of row in CSV matrix)_(name of CSV file).dxf
                dxf_name=(['Set',num2str(Set(i)),'Disc',num2str(i),'.dxf']);
                FID=dxf_open(fullfile(pathname,(['IntersSetsDisc\Set_', num2str(j)])),dxf_name);
                FID = dxf_set(FID,'Color',Color{j});
                dxf_polyline(FID, X, Y, Z);
                dxf_close(FID); % end of DXF exportation
            end
        end
        
    end
end
%salvare info fratture intersecanti



SP = createPlane(SPcenter, SP_N);%create ScanPlane
drawPlane3d(SP);%draw scan plane
view((180-MeanOrient.MeanDipDirection(1)),(90-MeanOrient.MeanDip(1)))

selFracdata=Fracdata(in_out>0,:);
selFracset=Fracset(in_out>0,:);

[Int_data]=intersectionCalculator(pathname,selFracdata,selFracset);
[PlanarSliding,FlexuralToppling,WedgeSliding,DirectToppling,ObliqueToppling,BasalPlane]=KynematicAnalysis(selFracset,Int_data, SP_N,pathname);


Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};
for i=1:length(selFracdata{:,1}) %export critical plane
    clearvars FID
    %% export PlanarSliding critical
    if PlanarSliding(i)>0
        
        
        theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
        v=null(selFracdata{i,7:9});% calculate vectors needed to plot the discs
        points=repmat(selFracdata{i,4:6}',1,size(theta,2))+selFracdata{i,3}*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
        
        % Change name to the coordinate in a better and more resonable name
        X=points(1,:)';
        Y=points(2,:)';
        Z=points(3,:)';
        % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
        % to export DXF for each plane
        filename_mod=filename(1:end-4);
        % name is written in this way:
        % (number of set)_CircPlane_(number of row in CSV matrix)_(name of CSV file).dxf
        if PlanarSliding(i)==1
            mkdir (pathname,(['KynAnalysis\Disc\PlanarSliding\LowCrit\Set', num2str(selFracset.Set(i))]))
            dxf_name=(['Critic_Set_',num2str(selFracset.Set(i)),'Disc',num2str(i),'.dxf']);
            FID=dxf_open(fullfile(pathname,(['KynAnalysis\Disc\PlanarSliding\LowCrit\Set', num2str(selFracset.Set(i))])),dxf_name);
            FID = dxf_set(FID,'Color',Color{j});
            dxf_polyline(FID, X, Y, Z);
            dxf_close(FID); % end of DXF exportation
        elseif PlanarSliding(i)==2
            mkdir (pathname,(['KynAnalysis\Disc\PlanarSliding\HighCrit\Set', num2str(selFracset.Set(i))]))
            dxf_name=(['Critic_Set_',num2str(selFracset.Set(i)),'Disc',num2str(i),'.dxf']);
            FID=dxf_open(fullfile(pathname,(['KynAnalysis\Disc\PlanarSliding\HighCrit\Set', num2str(selFracset.Set(i))])),dxf_name);
            FID = dxf_set(FID,'Color',Color{j});
            dxf_polyline(FID, X, Y, Z);
            dxf_close(FID); % end of DXF exportation
        end
    end

    %% Export Flexural Toppling critical discontintuies
        if FlexuralToppling(i)>0
        
        
        theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
        v=null(selFracdata{i,7:9});% calculate vectors needed to plot the discs
        points=repmat(selFracdata{i,4:6}',1,size(theta,2))+selFracdata{i,3}*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
        
        % Change name to the coordinate in a better and more resonable name
        X=points(1,:)';
        Y=points(2,:)';
        Z=points(3,:)';
        % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
        % to export DXF for each plane
        filename_mod=filename(1:end-4);
        % name is written in this way:
        % (number of set)_CircPlane_(number of row in CSV matrix)_(name of CSV file).dxf

        if FlexuralToppling(i)==2
            mkdir (pathname,(['KynAnalysis\Disc\FlexuralToppling\Crit\Set', num2str(selFracset.Set(i))]))
            dxf_name=(['Critic_Set_',num2str(selFracset.Set(i)),'Disc',num2str(i),'.dxf']);
            FID=dxf_open(fullfile(pathname,(['KynAnalysis\Disc\FlexuralToppling\Crit\Set', num2str(selFracset.Set(i))])),dxf_name);
            FID = dxf_set(FID,'Color',Color{j});
            dxf_polyline(FID, X, Y, Z);
            dxf_close(FID); % end of DXF exportation
        end
    end

end
for i=1:length(Int_data{:,1}) %export critical Intersection
    %% export WedgeSliding critical
    if WedgeSliding(i)>0
        
        
        
        
        % Change name to the coordinate in a better and more resonable name
        X=[Int_data.x1(i);Int_data.x2(i)];
        Y=[Int_data.y1(i);Int_data.y2(i)];
        Z=[Int_data.z1(i);Int_data.z2(i)];
        % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
        % to export DXF for each plane
        filename_mod=filename(1:end-4);
        % name is written in this way:
        % (number of set)_CircPlane_(number of row in CSV matrix)_(name of CSV file).dxf
        if WedgeSliding(i)==1
            mkdir (pathname,(['KynAnalysis\Inters\WedgeSliding\LowCrit\']))
            dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
            FID=dxf_open(fullfile(pathname,(['KynAnalysis\Inters\WedgeSliding\LowCrit\'])),dxf_name);
            FID = dxf_set(FID,'Color',Color{5});
            dxf_polyline(FID, X, Y, Z);
            dxf_close(FID); % end of DXF exportation
        elseif WedgeSliding(i)==2
            mkdir (pathname,(['KynAnalysis\Inters\WedgeSliding\HighCrit']))
            dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
            FID=dxf_open(fullfile(pathname,(['KynAnalysis\Inters\WedgeSliding\HighCrit\'])),dxf_name);
            FID = dxf_set(FID,'Color',Color{3});
            dxf_polyline(FID, X, Y, Z);
            dxf_close(FID); % end of DXF exportation
        end
    end
    %% export DirectToppling critical Intersections
    if DirectToppling(i)>0
        
        
        
        
        % Change name to the coordinate in a better and more resonable name
        X=[Int_data.x1(i);Int_data.x2(i)];
        Y=[Int_data.y1(i);Int_data.y2(i)];
        Z=[Int_data.z1(i);Int_data.z2(i)];
        % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
        % to export DXF for each plane
        filename_mod=filename(1:end-4);
        % name is written in this way:
        % (number of set)_CircPlane_(number of row in CSV matrix)_(name of CSV file).dxf
        if DirectToppling(i)==1
            mkdir (pathname,(['KynAnalysis\Inters\DirectToppling\LowCrit\']))
            dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
            FID=dxf_open(fullfile(pathname,(['KynAnalysis\Inters\DirectToppling\LowCrit\'])),dxf_name);
            FID = dxf_set(FID,'Color',Color{5});
            dxf_polyline(FID, X, Y, Z);
            dxf_close(FID); % end of DXF exportation
        elseif DirectToppling(i)==2
            mkdir (pathname,(['KynAnalysis\Inters\DirectToppling\HighCrit']))
            dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
            FID=dxf_open(fullfile(pathname,(['KynAnalysis\Inters\DirectToppling\HighCrit\'])),dxf_name);
            FID = dxf_set(FID,'Color',Color{3});
            dxf_polyline(FID, X, Y, Z);
            dxf_close(FID); % end of DXF exportation
        end
    end
    %% export ObliqueToppling critical Intersections
    if ObliqueToppling(i)>0
        
        
        
        
        % Change name to the coordinate in a better and more resonable name
        X=[Int_data.x1(i);Int_data.x2(i)];
        Y=[Int_data.y1(i);Int_data.y2(i)];
        Z=[Int_data.z1(i);Int_data.z2(i)];
        % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
        % to export DXF for each plane
        filename_mod=filename(1:end-4);
        % name is written in this way:
        % (number of set)_CircPlane_(number of row in CSV matrix)_(name of CSV file).dxf
        if ObliqueToppling(i)==1
            mkdir (pathname,(['KynAnalysis\Inters\ObliqueToppling\Crit\']))
            dxf_name=(['Critic_Sets_',num2str(Int_data.Set_i(i)),'_',num2str(Int_data.Set_j(i)),'Inters',num2str(i),'.dxf']);
            FID=dxf_open(fullfile(pathname,(['KynAnalysis\Inters\ObliqueToppling\Crit\'])),dxf_name);
            FID = dxf_set(FID,'Color',Color{5});
            dxf_polyline(FID, X, Y, Z);
            dxf_close(FID); % end of DXF exportation
        end
    end
end
disp('#######################')
disp('END OF TOTAL PROCESSES')
toc
disp('#######################')
