%% ------------------------- INTERSECTION ---------------------------------
clear all
close all
%% Select datasets to load
[filename, pathname] = uigetfile({'*.xlsx', 'Select a XLSX file of fit plane information'},...
    'Select a XLSX file of fit plane information',...
    'D:\Menegoni_data\Ormea\Nuovi voli giugno 2017\Albris_SenseFly\parete\obj\measures\Fit_Matlab')
data=readtable(fullfile(pathname,filename));

[filename2, pathname2] = uigetfile({'*.xlsx', 'Select a XLSX file of set interpretation with Dips'},...
    'Select a XLSX file of set interpretation with Dips',...
    'D:\Menegoni_data\Ormea\Nuovi voli giugno 2017\Albris_SenseFly\parete\obj\measures\Fit_Matlab')
dataDips=readtable(fullfile(pathname2,filename2));

uiwait(msgbox('Select folder for Intersection elaboration results'));
pathIntersection=uigetdir([...
    'D:\Menegoni_data\Ormea\Nuovi voli giugno 2017\Albris_SenseFly\parete\obj\measures\Fit_Matlab']);

tic
%% Read data and write vectors
num_disc = numel(data)/13;
nplane = num_disc;
Dip = data.Dip(:);%read Dip value of discontinuities
DipDir = data.DipDirection(:);%read Dip Direction value of discontinuities
radius = data.Radius(:);
xyz(:,1) = data.Xcenter(:);
xyz(:,2) = data.Ycenter(:);
xyz(:,3) = data.Zcenter(:);
Nxyz(:,1) = data.Nx(:);
Nxyz(:,2)= data.Ny(:);
Nxyz(:,3) = data.Nz(:);
Set=dataDips.Set(:);%read Set value of discontinuities (random values are defined as NaN as default)
Set(isnan(Set))=0;%change Set value of random discontinuities from NaN to 0
nSet=numel(unique(Set));
Setval=(unique(Set));
for i = 1: nSet%Create directory in which the intersection file.dxf are saved
    for j = 1:nSet
        Int_directory (1,1) = Setval(i);
        Int_directory (2,1) = Setval(j);
        Int_directory = sort(Int_directory);
        
        if Int_directory (1,1) == 0 && Int_directory (2,1)== 0
            mkdir([pathIntersection,'\SetRandom_SetRandom']);
        elseif Int_directory (1,1) == 0 && Int_directory (2,1) > 0
            mkdir([pathIntersection,'\SetRandom_Set',num2str(Int_directory (2,1))]);
        else
            mkdir([pathIntersection,'\Set', num2str(Int_directory (1,1)),'_Set', num2str(Int_directory (2,1))]);
        end
        
    end
end


%find max and min of central points
xyzMax=max(xyz);
xyzMin=min(xyz);





% Normals have to be oriented upward!!! (Normals have to be horiented in same
% direction if you want to calculate spacing)
for i=1:nplane
    if Nxyz(i,3)<0 %if normal is oriented downward
        Nxyz(i,1)=-Nxyz(i,1);
        Nxyz(i,2)=-Nxyz(i,2);
        Nxyz(i,3)=-Nxyz(i,3);
    else %if normal is oriented upward
        Nxyz(i,1)=Nxyz(i,1);
        Nxyz(i,2)=Nxyz(i,2);
        Nxyz(i,3)=Nxyz(i,3);
    end
end





N_SetPlane = hist( Set(:), numel(unique(Set)) );%Count number of discontinuity plane for each set

% Read and plot Mesh (the PLY file
figure (5)
title(['Discontinuity plane, N = ', num2str(nplane)])
% [mesh_vertex,mesh_face] = read_mesh(fullfile(mesh_pathname,mesh_filename));
% plot_mesh(mesh_vertex, mesh_face);
%--------------------Plot Circular Discontinuit Planes ------------------

N_set=zeros(nplane, 7); %matrix to storage number of plane for each set, every coloumn represent a set.

% Remember that radius of disconinuity its egual to diagonal of rectagnle
% formed by its values Horizontal and Vertical extent reached by
% CloudCompare
figure(5)
for i=1:nplane
    
    theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
    v=null(Nxyz(i,:));% calculate vectors needed to plot the discs
    points=repmat(xyz(i,:)',1,size(theta,2))+radius(i)*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
    
    % Change name to the coordinate in a better and more resonable name
    Xplot=points(1,:)';
    Yplot=points(2,:)';
    Zplot=points(3,:)';
%     
%     % With the below loop matlab could export DXF with different color in base
%     % of set
%     for j=1:nclu
%         if idx3(i)==j
%             % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
%             % to export DXF for each plane
%             filename_mod=filename(1:end-4);
%             % name is written in this way:
%             % (number of set)_CircPlane_(number of row in CSV matrix)_(name of CSV file).dxf
%             dxf_name=([num2str(idx3(i)),'CircPlane',num2str(i),'_',num2str(filename_mod),'.dxf']);
%             FID=dxf_open(pathCircPlane,dxf_name);
%             FID = dxf_set(FID,'Color',Color{j});
%             dxf_polyline(FID, X, Y, Z);
%             dxf_close(FID); % end of DXF exportation
%         end
%     end
    
    % Uncomment for plot of discs of discontinuities
    hold on % hold on, box on and grid are useful for plotting
    grid on
    box on
    fill3(points(1,:),points(2,:),points(3,:),'b', 'FaceAlpha', 0.5);%Plot 3D disc for each plane
    
    xlabel('x-axis (East)')
    ylabel('y-axis (Nord)')
    zlabel('z-axis (Elev)')
    hold on
    grid on
    box on
    
    %     %Uncomment if you wnat to see the normals of the planes
    %     quiver3(xyz(i,1), xyz(i,2), xyz(i,3), Nxyz(i,1), Nxyz(i,2), Nxyz(i,3),0.4)
    %     hold on
    %     grid on
    %     box on
    
    
    
    
    
end
disp('End of discontinuities plot')
toc
%-------------------------------------------------------------------------
%% Intersection calclulation
%% ------------------------- INTERSECTION ---------------------------------
countintersection=zeros(nplane,nplane);
countedge=zeros(nplane,nplane);
figure(5)
hold on
Intersvalues=zeros(1,13);



%this paragrpah works in the same way of the MTL 2D calulation
%(disconituinies are considered insetad CW).
for i= 1 : nplane-1
    for j= i+1 :nplane
        n1(i,:)=Nxyz(i,:);
        n2(j,:)=Nxyz(j,:);
        tol = 1e-14;
        
        % Uses Hessian form, ie : N.p = d
        % I this case, d can be found as : -N.p0, when N is normalized
        d1 = dot(n1(i,:), xyz(i,:), 2);
        d2 = dot(n2(j,:), xyz(j,:), 2);
        
        % compute dot products
        dot1 = dot(n1(i,:), n1(i,:), 2);
        dot2 = dot(n2(j,:), n2(j,:), 2);
        dot12 = dot(n1(i,:), n2(j,:), 2);
        
        % intermediate computations
        det= dot1*dot2 - dot12*dot12;
        c1= (d1*dot2 - d2*dot12)./det;
        c2= (d2*dot1 - d1*dot12)./det;
        
        % compute line origin and direction
        p0= c1*n1(i,:) + c2*n2(j,:);
        dp = cross(n1(i,:), n2(j,:), 2);
        % test if planes are parallel
        if abs(cross(n1(i,:), n2(j,:), 2)) < tol
            p0x(i,j)= NaN;
            p0y(i,j)= NaN;
            p0z(i,j)= NaN;
            dpx(i,j)= NaN;
            dpy(i,j)= NaN;
            dpz(i,j)= NaN;
            
        else
            
            p0x(i,j)= p0(1,1);
            p0y(i,j)= p0(1,2);
            p0z(i,j)= p0(1,3);
            dpx(i,j)= dp(1,1);
            dpy(i,j)= dp(1,2);
            dpz(i,j)= dp(1,3);
            line=[p0x(i,j), p0y(i,j), p0z(i,j), dpx(i,j), dpy(i,j), dpz(i,j)];
            
            point1= [xyz(i,1), xyz(i,2), xyz(i,3)];
            point2= [xyz(j,1), xyz(j,2), xyz(j,3)];
            dpointL_P1 = bsxfun(@rdivide, vectorNorm3d( ...
                vectorCross3d(line(:,4:6), bsxfun(@minus, line(:,1:3), point1)) ), ...
                vectorNorm3d(line(:,4:6)));
            dpointL_P2= bsxfun(@rdivide, vectorNorm3d( ...
                vectorCross3d(line(:,4:6), bsxfun(@minus, line(:,1:3), point2)) ), ...
                vectorNorm3d(line(:,4:6)));
            %define radius
            
                radius1=radius(i);
                radius2=radius(j);
            
            if dpointL_P1<radius1 && dpointL_P2<radius2
                
                select=zeros(4,4);
                %Define Sphere for Sphere-Line Intersection
                SPHERE1 = [xyz(i,1), xyz(i,2), xyz(i,3),  radius1];
                SPHERE2 = [xyz(j,1), xyz(j,2), xyz(j,3),  radius2];
                
                %Use Spehere-Line intersection function of geom3d package
                %(INRA)
                PTS1 = intersectLineSphere(line, SPHERE1);
                PTS2 = intersectLineSphere(line, SPHERE2);
                PTS=[PTS1; PTS2];
                
                %calcolo dei punti dalle sfere (es d_point11= distanza punto 1
                %da sfera 1)
                
                %Point1
                d_point11=distancePoints3d(PTS(1,:), xyz(i,:));
                d_point12=distancePoints3d(PTS(1,:), xyz(j,:));
                if (-d_point11+radius1)>-0.0005 && (-d_point12+radius2)>-0.0005
                    PTS(1,1)=PTS(1,1);
                    PTS(1,2)=PTS(1,2);
                    PTS(1,3)=PTS(1,3);
                else
                    PTS(1,1)=NaN;
                    PTS(1,2)=NaN;
                    PTS(1,3)=NaN;
                end
                %Point 2
                d_point21=distancePoints3d(PTS(2,:), xyz(i,:));
                d_point22=distancePoints3d(PTS(2,:), xyz(j,:));
                if (-d_point21+radius1)>-0.0005 && (-d_point22+radius2)>-0.0005
                    PTS(2,1)=PTS(2,1);
                    PTS(2,2)=PTS(2,2);
                    PTS(2,3)=PTS(2,3);
                else
                    PTS(2,1)=NaN;
                    PTS(2,2)=NaN;
                    PTS(2,3)=NaN;
                end
                %Point 3
                d_point31=distancePoints3d(PTS(3,:), xyz(i,:));
                d_point32=distancePoints3d(PTS(3,:), xyz(j,:));
                if (-d_point31+radius1)>-0.0005 && (-d_point32+radius2)>-0.005
                    PTS(3,1)=PTS(3,1);
                    PTS(3,2)=PTS(3,2);
                    PTS(3,3)=PTS(3,3);
                else
                    PTS(3,1)=NaN;
                    PTS(3,2)=NaN;
                    PTS(3,3)=NaN;
                end
                %Point 4
                d_point41=distancePoints3d(PTS(4,:), xyz(i,:));
                d_point42=distancePoints3d(PTS(4,:), xyz(j,:));
                if (-d_point41+radius1)>-0.0005 && (-d_point42+radius2)>-0.0005
                    PTS(4,1)=PTS(4,1);
                    PTS(4,2)=PTS(4,2);
                    PTS(4,3)=PTS(4,3);
                else
                    PTS(4,1)=NaN;
                    PTS(4,2)=NaN;
                    PTS(4,3)=NaN;
                end
                
                
                
                d_pp13 = distancePoints3d(PTS(1,:), PTS(3,:));
                d_pp14 = distancePoints3d(PTS(1,:), PTS(4,:));
                d_pp23 = distancePoints3d(PTS(2,:), PTS(3,:));
                d_pp24 = distancePoints3d(PTS(2,:), PTS(4,:));
                
                % Eliminare i punti 3 e 4 se coindidono con 1 e 2
                if (d_pp13<0.005 & d_pp24<0.0005)
                    PTS(3,1)=NaN;
                    PTS(3,2)=NaN;
                    PTS(3,3)=NaN;
                    PTS(4,1)=NaN;
                    PTS(4,2)=NaN;
                    PTS(4,3)=NaN;
                    countedge(i,j)=1;
                end
                if (d_pp23<0.0005 & d_pp14<0.0005)
                    PTS(3,1)=NaN;
                    PTS(3,2)=NaN;
                    PTS(3,3)=NaN;
                    PTS(4,1)=NaN;
                    PTS(4,2)=NaN;
                    PTS(4,3)=NaN;
                    countedge(i,j)=1;
                end
                
                % selezionare solo i valori non nulli
                select = ~isnan( PTS ) ;
                pointIntersecting=PTS(select);
                
                npointIntersecting= (numel(pointIntersecting))/3;
                
                if  npointIntersecting==1
                    Point_intersection=[pointIntersecting(1), pointIntersecting(2), pointIntersecting(3)];
                    
                    drawPoint3d(Point_intersection,'marker', '+', 'markerSize', 10, 'linewidth', 3);
                    hold on
                end
                if npointIntersecting>1
                    Point_intersection=[pointIntersecting(1), pointIntersecting(3), pointIntersecting(5),...
                        pointIntersecting(2), pointIntersecting(4), pointIntersecting(6)];
                    figure(5)
                    drawEdge3d(Point_intersection, 'color', 'r', 'linewidth', 4);
                    hold on
                    countedge(i,j)=1;
                    
                    
                    if pointIntersecting(5)>pointIntersecting(6)
                        %set the point with higher Z coord. as Point1 (not Point i !!)
                        %in the final table Point i could be not equal to
                        %Point1. Point1 has to be the point with higher Z
                        %to obtain the correct plunge and trend values
                        X=[pointIntersecting(1); pointIntersecting(2)];
                        Y=[pointIntersecting(3); pointIntersecting(4)];
                        Z=[pointIntersecting(5); pointIntersecting(6)];
                    else
                        X=[pointIntersecting(2); pointIntersecting(1)];
                        Y=[pointIntersecting(4); pointIntersecting(3)];
                        Z=[pointIntersecting(6); pointIntersecting(5)];
                    end
                    
                    %Calculation of plunge and trend/azimuth
                     Int_Length= sqrt((X(2,1) - X(1,1))^2 + (Y(2,1) - Y(1,1))^2 + (Z(2,1) - Z(1,1))^2);
                     cosAlpha=(X(2,1) - X(1,1))/Int_Length;
                     cosBeta=(Y(2,1) - Y(1,1))/Int_Length;
                     cosGamma=(Z(2,1) - Z(1,1))/Int_Length;
                     plungeRad = asin(-cosGamma);
                     azimuthRad = atan(cosAlpha/cosBeta);
                     plungeDeg=radtodeg(plungeRad);
                     azimuthDeg=radtodeg(azimuthRad);                     
                     if cosBeta<0
                         azimuthDeg_c= 180 + azimuthDeg;
                     else
                         if cosAlpha>0
                             azimuthDeg_c= azimuthDeg;
                         elseif cosAlpha<0
                             azimuthDeg_c= 360+azimuthDeg;
                         end
                     end
                     azimuthDeg=azimuthDeg_c;
                     
 
                    
                    %Writing a XLSX file where Point1 and Point2 XYZ, trend
                    %and plunge are saved
                    nwrite= numel(Intersvalues)/13;
                    if nwrite ==1 && sum(Intersvalues(1,:))== 0
                   
                        Intersvalues(1,1)=azimuthDeg;
                        Intersvalues(1,2)=plungeDeg;
                        Intersvalues(1,3)=Set(i);
                        Intersvalues(1,4)=Set(j);
                        Intersvalues(1,5)=(i);
                        Intersvalues(1,6)=(j);
                        Intersvalues(1,7)=Int_Length;
                        Intersvalues(1,8)=pointIntersecting(1);
                        Intersvalues(1,9)=pointIntersecting(3);
                        Intersvalues(1,10)=pointIntersecting(5);
                        Intersvalues(1,11)=pointIntersecting(2);
                        Intersvalues(1,12)=pointIntersecting(4);
                        Intersvalues(1,13)=pointIntersecting(6);
                        
                    else
                        Intersvalues(nwrite+1,1)=azimuthDeg;
                        Intersvalues(nwrite+1,2)=plungeDeg;
                        Intersvalues(nwrite+1,3)=Set(i);
                        Intersvalues(nwrite+1,4)=Set(j);
                        Intersvalues(nwrite+1,5)=(i);
                        Intersvalues(nwrite+1,6)=(j);
                        Intersvalues(nwrite+1,7)=Int_Length;
                        Intersvalues(nwrite+1,8)=pointIntersecting(1);
                        Intersvalues(nwrite+1,9)=pointIntersecting(3);
                        Intersvalues(nwrite+1,10)=pointIntersecting(5);
                        Intersvalues(nwrite+1,11)=pointIntersecting(2);
                        Intersvalues(nwrite+1,12)=pointIntersecting(4);
                        Intersvalues(nwrite+1,13)=pointIntersecting(6);
                        
                    end

                    %Save DXF intersection file
                    dxf_name=(['Int',num2str(i),'_',num2str(j),'.dxf']);
                    Int_directory = [Set(i); Set(j)];
                    Int_directory =sort(Int_directory);
                    if Int_directory(1,1)==0 && Int_directory(2,1)==0
                    FID=dxf_open(([pathIntersection,'\SetRandom_SetRandom']),dxf_name);
                    elseif Int_directory(1,1)==0 && Int_directory(2,1)>0
                    FID=dxf_open(([pathIntersection,'\SetRandom_Set',num2str(Int_directory(2,1))]),dxf_name);
                    elseif Int_directory(1,1)>0 && Int_directory(2,1)>0
                    FID=dxf_open(([pathIntersection,'\Set',num2str(Int_directory(1,1)),'_Set',num2str(Int_directory(2,1))]),dxf_name);
                    end
                    
                    FID = dxf_set(FID,'Color',[1 0 0]);
                    dxf_polyline(FID, X, Y, Z);
                    dxf_close(FID);
                end
                
                
                
                
                
                %                 drawLine3d(line, 'color', 'y', 'linewidth', 2);
                %                 hold on
                
                countintersection(i,j)=1;
                
                
                
            else
                countintersection(i,j)=0;
                countedge(i,j)=0;
            end
            
        end
    end
    
    
end
Tplane = table(Intersvalues(:,1),Intersvalues(:,2),Intersvalues(:,3),...
    Intersvalues(:,4),Intersvalues(:,5),Intersvalues(:,6),...
    Intersvalues(:,7),Intersvalues(:,8),Intersvalues(:,9),...
    Intersvalues(:,10),Intersvalues(:,11),Intersvalues(:,12),...
    Intersvalues(:,13));
Tplane.Properties.VariableNames = {'Trend' 'Plunge' 'Set_i'...
    'Set_j' 'Nplane_i' 'Nplane_j'...
    'Length_Intersection' 'x1' 'y1'...
    'z1' 'x2' 'y2'...
    'z2' };
tablefilenameTXT = (['Intersection_',filename(1:end-4),'.txt']);
writetable(Tplane,fullfile(pathIntersection,tablefilenameTXT));
tablefilenameXLSX = (['Intersection_',filename(1:end-4),'.xlsx']);
writetable(Tplane,fullfile(pathIntersection,tablefilenameXLSX));
disp('###EnD oF iNtErSeCtIoN eLaBoRaTiOn PrOcEsS ###')
toc
disp('����������')
disp('������������')
disp('������������')
disp('������������')
disp('�����������')
disp('����������������')
disp('�����������������')
disp('����������������')
disp('�����������������')
disp('������������������')
disp('������������������')
disp('�����������������')
disp('����������������')
disp('���������������')


% % Save matlab figure of fracture trace on circular window
% savefig(fullfile(pathIntersection,'FractureIntersection'))

% n_intersection=nnz(countintersection);
% ncountedge=nnz(countedge);
% Int_set=zeros(1,nclu);
% for i=1:nplane
%     for j=1:nplane
%         for k=1:nSet
%             
%             if Set(i)==k && countintersection(i,j)==1
%                 Int_set(1,k)=Int_set(1,k)+1;
%             end
%             if Set(j)==k && countintersection(i,j)==1
%                 Int_set(1,k)=Int_set(1,k)+1;
%             end
%         end
%     end
% end
