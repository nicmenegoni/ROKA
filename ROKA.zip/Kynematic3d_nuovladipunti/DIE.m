
% Asks if you want to use the previous data
prompt = {['YOU WANT TO USE PREVIOUS DATA? YES=1 NO=0']};
dlg_title = 'YOU WANT TO USE PREVIOUS DATA? YES=1 NO=0';
initial_Q = inputdlg(prompt);
initial_Q =str2num(initial_Q{1});

%% -------------------------- IMPORT DATA ---------------------------------
if initial_Q == 0
    close all
    clear all
    
    
    
    
    %  Select CSV file containing all plane
    uiwait(msgbox('Select CSV file to load'));
    if ismac %For OSX operative system
        [filename, pathname] = uigetfile({'*.csv', 'Select a CSV file'},'mytitle',...
            '/Volumes/F/DATI/D_data/dottorato/DATI/Antola/Outcrop_models');% <- MODIFY the PATH
    elseif ispc % For WINDOWS operative system
        [filename, pathname] = uigetfile({'*.csv', 'Select a CSV file'},'mytitle',...
            'I:\DATI\D_data\dottorato\DATI\Antola\Outcrop_models');% <- MODIFY the PATH
    end
    % Select CSV file of Circular Window fitted plane
    uiwait(msgbox('Select CIRCULAR WINDOWS CSV file to load'));
    if ismac
        [filenameCW, pathnameCW] = uigetfile({'*.csv', 'Select a CSV file'},'Select Circular Window CSV file', pathname);
    elseif ispc
        [filenameCW, pathnameCW] = uigetfile({'*.csv', 'Select a CSV file'},'Select Circular Window CSV file', pathname);
    end
    %Select mesh PLY file
    uiwait(msgbox('Select PLY file to load'));
    [mesh_filename, mesh_pathname]=uigetfile({'*.ply', 'Select a PLY file'},'mytitle',...
        pathname);
    
    %% ------------------  DEFINE PATH IN WHICH DXF WILL BE SAVED ------------------------------------
    % select path in which DXF of intersection will be saved
    uiwait(msgbox('Select folder for Intersection.dxf'));
    pathIntersection=uigetdir(pathname, 'Select folder for Intersection.dxf');
    % select path in which DXF of Circular Plane will be saved
    uiwait(msgbox('Select folder for CircPlane.dxf'));
    pathCircPlane=uigetdir(pathname, 'Select folder for CircPlane.dxf');
    % select path in which DXF of Trace Map will be saved
    uiwait(msgbox('Select folder for Trace Map.dxf'));
    pathTraceMap=uigetdir(pathname, 'Select folder for Trace Map.dxf');
    
    %% -------------------- ENTER RADIUS OF CIRCULAR WINDOWS -----------------------------------------
    % Display box to insert the value of the radius of the circular window
    prompt = {['Enter Radius of Circular Window for', num2str(filenameCW), ':']};
    dlg_title = 'Input radius CW';
    radiusCW=inputdlg(prompt);
    radiusCW=str2num(radiusCW{1});
    
    
    if isequal(filename,0)
        disp('User selected Cancel')
    else
        disp(['User selected ', fullfile(pathname, filename)])
    end
    
end

%% -------------------- READING CSV FILE OF DISCONTINUITIES------------------------------------

%reading csv file in which coloumn (j) are:

% j1, j2, j3 = x, y, z (coordinates of center of plane)

% j4, j5, j6 = Nx, Ny, Nz

% etc...

% WARNING!!! The CSV file is the CSV file exported with CloudCompare

[CSV,delimiterOut]=importdata(fullfile(pathname, filename),';',1);
n=numel(CSV.data)/16; %number of rows (= number of plane)
disp ([filename]) % disp on Matlab command line the name of the file

A=zeros(n ,6);% initializing a matrix of n rows (i) and 6 columns (j) with all zeros
Horiz_ext=zeros(n ,6);
Vertical_ext=zeros(n ,6);
for i= 1 : n % rows from 1 to n (=planes)
    for j = 1 : 6 % column from 1 to 6 (=x, y, z, Nx, Ny, Nz)
        
        A(i,j)= CSV.data(i,j+1); % import value x, y, z, Nx, Ny, Nz for each plane
        Horiz_ext(i)=CSV.data(i,9);
        Vertical_ext(i)=CSV.data(i,10);
    end
end



nplane=n; % change variable name for the number of planes

Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]}% define color for set from 1 to 7
%ex. Set1=k=Kian, Set2=b=blue, Set3=r=red, Set4=g=green, Set5=yellow, etc.

%% ------------------ STEREONET & CLUSTERING ------------------------------------------
% Read Dip direction and Dip from CSV file of discontinuities--------------

dipdir =  CSV.data(:,13);%Dip direction
dip =  CSV.data(:,14);%Dip angle

nplane=n; % number of plane to plot in the stereogram

% In this paragraph this code will use some function for plotting stereonet
% and clustering disconinuities poles from the code ' VisualScanline' of
% Markovaara-Koivisto and Laine (1).

%Steroplot of poles of disconinuities--------------------------------------
[xp, yp]=Stereogram_colourless_Schmidt(dipdir, dip, nplane);
savefig(fullfile(pathIntersection,'Stereoplot_Unclustered'))
% Clustering of the discontintuities---------------------------------------

% Asks the number of joint sets in the data
prompt = {['Number of joint sets (+1 for randoms) in your data (max 7):']};
dlg_title = 'Input Number of Sets (+1 for Randoms)';
nclu = inputdlg(prompt);% number of joint selected
nclu =str2num(nclu{1});

Clustering_M % this function was modified in order to permit clustering between
% discontinuity with poles with same direction but opposit side (ex. 30/85
% and 210/85).

% Draws the automated clustering results (kmeans-method) on a Schmidt's equal area net
Stereogram(dipdir, dip, nplane, idx3, xp, yp)

% Asks is the user is satisfied with the result of the clustering
% If not, the user may change the clustering in an interactive window
Ready = [];
button=1;
answer = input('Do you want to change the results of the automatic clustering (y/n):', 's');
while (answer == 'y' & isempty(Ready) & button==1)
    disp('Left click with mouse on the symbols as many times as it takes to change the cluster into the wanted one.')
    disp('When you are finnished, right click with mouse on the figure')
    [xcho, ycho, button]=ginput(1);
    
    % Calculates the minimun distance between the indicated point and the data
    % points and searches the closes data point, gives index to the row and
    % changes the cluster group into the next one or to the first one.
    % Refreshes the figure.
    distance=sqrt((xp-xcho).^2+(yp-ycho).^2);
    cho=find(distance==min(distance))
    % Observation is indicated to the next cluster
    if (idx3(cho)<max(idx3) & button==1)
        idx3(cho)=idx3(cho)+1;
    elseif button==1
        idx3(cho)=1;
    end
    Stereogram(dipdir, dip, nplane, idx3, xp, yp)
    
    
end
savefig(fullfile(pathIntersection,'Stereoplot_Clustered'))
%------ K-Fisher ditributon coefficient----------------------------------
% This part was not inside the code of Markovaara-Koivisto and Laine (1).
% According Priest (2) the K-Fisher coefficient for a spherical  vector
% distribution can be approximated by the function:

%                       K = (N - 1)/ (N - R)

% where N = sum of magnitude of vectors;
%       R = magnitude of resultant of vector (sum of vector), R is allways lower than N;
% K ->infinity, for (N - R)->0; Higher K are for really thight set, Lower K
% are for broad set.

% Since pole vectors are unit vectors (magnitude=1), N represent the number
% of poles.



for  i = 1 : nplane
    for j = 1 : nclu
        if idx3(i) == j
            
            % correction that permits poles with same direction but opposit
            % side clustering
            
            if arcdistance(idx3(i), i) == antiarcdistance(idx3(i), i)
                N_corr(:,:,i)=antiN(:,:,i);
            else
                N_corr(:,:,i)=N(:,:,i);
            end
        end
    end
    
end


for i=1:nplane
    for j=1:3
        N_correct(i,j)=N_corr(1,j,i); % copy normal (pole) vector in a more appropiate matrix for further calculation
    end
end

%Calculate K-Fisher

N_SetPlane = hist( idx3, numel(unique(idx3)) );% count number of plane in each set--> N value

% Initializing resultant vector, r=(rx, ry, rz)
rx=zeros(1,nclu);
ry=zeros(1,nclu);
rz=zeros(1,nclu);

% calculate resultant of pole vectors
for i=1:nplane
    for j=1:nclu
        if idx3(i)==j
            rx(1,j)=rx(1,j)+N_correct(i,1);%resultant of value x for each set
            ry(1,j)=ry(1,j)+N_correct(i,2);%resultant of value y for each set
            rz(1,j)=rz(1,j)+N_correct(i,3);%resultant of value z for each set
        end
    end
end

% Initializing magnitude of resultant and K-fisher value
magn_r_xyz=zeros(1,nclu);
K_fisher=zeros(1,nclu);

for j=1:nclu
    magn_r_xyz(1,j)=sqrt(rx(1,j)^2 + ry(1,j)^2 + rz(1,j)^2);% calulate magnitude of resultant for each set
    K_fisher(1,j)=(N_SetPlane(1,j)-1)/(N_SetPlane(1,j)-magn_r_xyz(1,j));% calculate K-Fisher coeff. for each set
end

%----------- DRAWING OTHER STEREOPLOT/POLES PROJECTION --------------------
% Draws colour coded unit vectors on a stereographic sphere, in which dip 0
% degrees is at the bottom of the sphere and 90 degrees at the top.
Unitvectors_coloured(dipdir, dip, nplane, idx3)
savefig(fullfile(pathIntersection,'unitvectors_sphere'))
% Calculates the mean attitudes of the clusters
[dipdireigv, dipeigv]=Eigenvector(dipdir, dip, idx3);

% Draws a stereographic projection with the mean attitudes of the clusters
StereogramEig(dipdir, dip, nplane, idx3)

thetaeig=(90-dipdireigv);
reig=sqrt(2)*sind((90-dipeigv-90)/2);
for n=1:max(idx3)
    xeigp(n) = reig(n)*cosd(thetaeig(n));
    yeigp(n) = reig(n)*sind(thetaeig(n));
end
plot(xeigp, yeigp, 'kO')
savefig(fullfile(pathIntersection,'mean_attitudes_cluster'))

%% -----------PLOT OF 3D DISCONTINUITIES AND MESH OF CIRCULAR WINDOWS-----

% Setting normals, D-parameters of plane equations and radius of discontinuity planes

xyz=zeros(nplane,3);%initializing coord matrix of plane central point
Nxyz=zeros(nplane,3);% initializing plane normals matrix

% Fill  central point matrix (x,y,z) and normal matrix (Nx,Ny,Nz)
for i=1:nplane
    
    %xyz matrix
    xyz(i,1)=A(i,1);
    xyz(i,2)=A(i,2);
    xyz(i,3)=A(i,3);
    
    %N matrix
    Nxyz(i,1)=A(i,4);
    Nxyz(i,2)=A(i,5);
    Nxyz(i,3)=A(i,6);
end

%find max and min of central points
xyzMax=max(xyz);
xyzMin=min(xyz);

% Find coefficients D of plane equations ( Maybe this Values is
% meaningless, I have to check the code another time)
Dplane=zeros(nplane,1);% D parameters of plane equation (Ax+By+Cz+D=0)
for i= 1: nplane
    Dplane (i)= -dot(Nxyz(i,:),xyz(i,:));
end

%create a grid basing on min and max values of the central points
Xgrid = xyzMin(1,1): 0.1 :xyzMax(1,1);
Ygrid = xyzMin(1,2): 0.1 :xyzMax(1,2);
[X,Y]=meshgrid(Xgrid,Ygrid);


% Normals have to be oriented upward!!! (Normals have to be horiented in same
% direction if you want to calculate spacing)
for i=1:nplane
    if Nxyz(i,3)<0 %if normal is oriented downward
        Nxyz(i,1)=-Nxyz(i,1);
        Nxyz(i,2)=-Nxyz(i,2);
        Nxyz(i,3)=-Nxyz(i,3);
    else %if normal is oriented upward
        Nxyz(i,1)=Nxyz(i,1);
        Nxyz(i,2)=Nxyz(i,2);
        Nxyz(i,3)=Nxyz(i,3);
    end
end

% Setting radius--> radius is considered as the diagonal of the rectangle
% formed by Horizontal_extent and Vertical_extent values of the CSV file
for i=1:nplane
    %radius(i)=(sqrt(Horiz_ext(i)^2 + Vertical_ext(i)^2))/2;
    if Horiz_ext(i)<Vertical_ext(i)
        radius(i)= Vertical_ext(i);
    else
        radius(i)= Horiz_ext(i);
    end
end


N_SetPlane = hist( idx3, numel(unique(idx3)) );%Count number of discontinuity plane for each set

% Read and plot Mesh (the PLY file
figure (5)
title(['Discontinuity plane, N = ', num2str(nplane)])
% [mesh_vertex,mesh_face] = read_mesh(fullfile(mesh_pathname,mesh_filename));
% plot_mesh(mesh_vertex, mesh_face);
%-------------------------------------------------------------------------


% %%--------------------Plot Circular Discontinuit Planes ------------------

N_set=zeros(nplane, 7); %matrix to storage number of plane for each set, every coloumn represent a set.

% Remember that radius of disconinuity its egual to diagonal of rectagnle
% formed by its values Horizontal and Vertical extent reached by
% CloudCompare
for i=1:nplane
    
    theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
    v=null(Nxyz(i,:));% calculate vectors needed to plot the discs
    points=repmat(xyz(i,:)',1,size(theta,2))+radius(i)*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
    
    % Change name to the coordinate in a better and more resonable name
    X=points(1,:)';
    Y=points(2,:)';
    Z=points(3,:)';
    
    % With the below loop matlab could export DXF with different color in base
    % of set
    for j=1:nclu
        if idx3(i)==j
            % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
            % to export DXF for each plane
            filename_mod=filename(1:end-4);
            % name is written in this way:
            % (number of set)_CircPlane_(number of row in CSV matrix)_(name of CSV file).dxf
            dxf_name=([num2str(idx3(i)),'CircPlane',num2str(i),'_',num2str(filename_mod),'.dxf']);
            FID=dxf_open(pathCircPlane,dxf_name);
            FID = dxf_set(FID,'Color',Color{j});
            dxf_polyline(FID, X, Y, Z);
            dxf_close(FID); % end of DXF exportation
        end
    end
    
    % Uncomment for plot of discs of discontinuities
    hold on % hold on, box on and grid are useful for plotting
    grid on
    box on
    fill3(points(1,:),points(2,:),points(3,:),'b', 'FaceAlpha', 0.5);%Plot 3D disc for each plane
    
    xlabel('x-axis (East)')
    ylabel('y-axis (Nord)')
    zlabel('z-axis (Elev)')
    hold on
    grid on
    box on
    
    %     %Uncomment if you wnat to see the normals of the planes
    %     quiver3(xyz(i,1), xyz(i,2), xyz(i,3), Nxyz(i,1), Nxyz(i,2), Nxyz(i,3),0.4)
    %     hold on
    %     grid on
    %     box on
    
    
    
    
    
end
savefig(fullfile(pathIntersection,'Fracture_3Dplot'))
%-------------------------------------------------------------------------


%% ----------------------- MEAN TRACE LENGTH ------------------------------

% This code calulate 2 different values for MTL
%
%       1) the 3D MTL, for which trace of the discontinuities are egual to the radius;
%
%       2) the 2D MTL for which trace of discontinuities are egual to the intersection
%          trace between discontinuity discs and the plane fitted for the
%          "topographical" circular window.
%
% For the 3D method is present also another MTL, MTL3D_norm, calculated in base of a different
% radius (2*radius = to the higher values between Horizontal and Vertical
% extent).


% Method 3D
Diagonal_ext=zeros(nplane,1);
radius_diag=zeros(nplane,1);
TL3D_norm=zeros(nplane,nclu);
TL3D_diag=zeros(nplane,nclu);
for i=1:nplane
    %calculation radius_diagExt= 1/2 * diagonal
    Diagonal_ext(i)= sqrt(Horiz_ext(i)^2 + Vertical_ext(i)^2);
    radius_diag(i)=Diagonal_ext(i)/2;
    for j=1:nclu
        if idx3(i)==j
            TL3D_norm(i,j)=2*radius(i); % trace is egual to the diameter of the discontinuity circle
            TL3D_diag(i,j)=2*radius_diag(i);
        else
            TL3D_norm(i,j)=0;
            TL3D_diag(i,j)=0;
        end
    end
end
MTL3D_norm=zeros(1,nclu);% Initializing Mean Trace Length with 0 values
MTL3D_diag=zeros(1,nclu);%


for i=1:nplane
    for j=1:nclu
        if TL3D_norm(i,j)==0 && TL3D_diag(i,j)==0
            TL3D_norm(i,j)=NaN; %Changing 0 value of trace lengths in NaN value to permit mean and st. dev calculation
            TL3D_diag(i,j)=NaN;
        end
    end
end
for j=1:nclu %calculation of mean (MTL) and st. dev. for each set
    MTL3D_norm(1,j)=nanmean(TL3D_norm(:,j));
    MTL3D_diag(1,j)=nanmean(TL3D_diag(:,j));
    st_dev3D_norm(1,j)=nanstd(TL3D_norm(:,j));
    st_dev3D_diag(1,j)=nanstd(TL3D_diag(:,j));
end
for j=1:nclu% calulation of min and max trace lengths for each value
    max_length_norm(1,j)=max(TL3D_norm(:,j));
    max_length_diag(1,j)=max(TL3D_diag(:,j));
    min_length_norm(1,j)=min(TL3D_norm(:,j));
    min_length_diag(1,j)=min(TL3D_diag(:,j));
end

% %% Method 2D %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Reading CSV of Circualr Window
[CircWind,delimiterOut]=importdata(fullfile(pathnameCW, filenameCW),';',1);
n=numel(CircWind.data)/16; %number of rows (=1, in this case)
disp ([filenameCW])
A_CW=zeros(1 ,6);

for j = 1 : 6
    
    A_CW(1,j)= CircWind.data(1,j+1);
    
end

N_CW(1,1:3)=A_CW(1, 4:6);
xyz_CW(1,1:3)=A_CW(1, 1:3);




% Calulation Intersection between Discontinuities and plane fitted for
% Circ. Wind.

%---You have to select between two types of radius (comment and uncomment
%in base of yur choise)

%radiusA=radius;
radiusA=radius_diag;
%------------------------------------
figure(7)% open figure in which plot this Trace map

%fit disc of circular window
thetaCW=0:0.1:2*pi;
vCW=null(N_CW);
pointsCW=repmat(xyz_CW',1,size(thetaCW,2))+radiusCW*(vCW(:,1)*cos(thetaCW)+vCW(:,2)*sin(thetaCW));

XCW=pointsCW(1,:)';
YCW=pointsCW(2,:)';
ZCW=pointsCW(3,:)';

fill3(pointsCW(1,:),pointsCW(2,:),pointsCW(3,:),'b', 'FaceAlpha', 0.5);%plot disc of circular window

xlabel('x-axis (East)')
ylabel('y-axis (Nord)')
zlabel('z-axis (Elev)')
hold on
grid on
box on

m_mauldon=zeros(nplane,1);%initializing m and n MAuldon value
n_mauldon=zeros(nplane,1);


figure(7)
countCWDisc_inter=zeros(nplane,nplane);%initializig a matrix for counting the intersection of each discontinuity and set

for i=1:nplane
    nA(i,:)=Nxyz(i,:);% Normal vector of discontinuity
    nB=N_CW;% Circular Window normal
    tol = 1e-14;% setting the angle cutoff for which pseudo parallel planes (parallel at the CW plane) are not consider.
    
    
    %The string below are copied from the "Geom3D" code (Copyright (c) 2016,
    %INRA) and modified in order to permit calulation of trace lenth and
    %ntersection woth the circular window needed in Mauldon method
    
    % Uses Hessian form, ie : N.p = d
    % I this case, d can be found as : -N.p0, when N is normalized
    dA = dot(nA(i,:), xyz(i,:), 2);
    dB = dot(nB, xyz_CW, 2);
    
    % compute dot products
    dotA = dot(nA(i,:), nA(i,:), 2);
    dotB = dot(nB, nB, 2);
    dotAB = dot(nA(i,:), nB, 2);
    
    % intermediate computations
    detAB= dotA*dotB - dotAB*dotAB;
    cA= (dA*dotB - dB*dotAB)./detAB;
    cB= (dB*dotA - dA*dotAB)./detAB;
    
    % compute line origin and direction
    p0AB= cA*nA(i,:) + cB*nB;
    dpAB = cross(nA(i,:), nB, 2);
    
    % test if planes are parallel
    if abs(cross(nA(i,:), nB, 2)) < tol
        p0ABx(i)= NaN;
        p0ABy(i)= NaN;
        p0ABz(i)= NaN;
        dpABx(i)= NaN;
        dpABy(i)= NaN;
        dpABz(i)= NaN;
        
    else
        
        p0ABx(i)= p0AB(1,1);
        p0ABy(i)= p0AB(1,2);
        p0ABz(i)= p0AB(1,3);
        dpABx(i)= dpAB(1,1);
        dpABy(i)= dpAB(1,2);
        dpABz(i)= dpAB(1,3);
        
        lineAB(i, 1:6)=[p0ABx(i), p0ABy(i), p0ABz(i), dpABx(i), dpABy(i), dpABz(i)];%%Infinite line representing intersection between two infinte planes of discontinuity and CW
        
        point1AB(i,:)= xyz(i,:);% Center of discontinuity
        point2AB= xyz_CW;% center of Circular Window
        
        %Distance between disconintuity and previous intersection line
        dpointL_PA(i) = bsxfun(@rdivide, vectorNorm3d( ...
            vectorCross3d(lineAB(i,4:6), bsxfun(@minus, lineAB(i,1:3), point1AB(i,:))) ), ...
            vectorNorm3d(lineAB(i,4:6)));
        %Distance between circular window and previous intersection line
        
        dpointL_PB(i) = bsxfun(@rdivide, vectorNorm3d( ...
            vectorCross3d(lineAB(i,4:6), bsxfun(@minus, lineAB(i,1:3), point2AB(1,:))) ), ...
            vectorNorm3d(lineAB(i,4:6)));
        
        
        
        if dpointL_PA(i)<radiusA(i) && dpointL_PB(i)<radiusCW %if distance is lower than radius of 2 discs (discont. and CW) intersection is considered
            
            selectAB=zeros(4,4);
            
            %Define Sphere (fitted for the 2 considered discs) for Sphere-Line Intersection
            SPHEREA = [xyz(i,1), xyz(i,2), xyz(i,3),  radiusA(i)];%definisco la sfera per la discontinuit�
            SPHEREB = [xyz_CW(1,1), xyz_CW(1,2), xyz_CW(1,3),  radiusCW];%definisco la sfera per la CW
            
            %Use Spehere-Line intersection function of geom3d package
            %(INRA) to find points of intersection
            PTSA= intersectLineSphere(lineAB(i,:), SPHEREA);% for line and discontinuity sphere
            P_interA(i,1:6)=[PTSA(1,1:3), PTSA(2,1:3)];
            PTSB = intersectLineSphere(lineAB(i,:), SPHEREB);% for line and CW sphere
            P_interB(i,1:6)=[PTSB(1,1:3), PTSB(2,1:3)];
            
            PTSAB=[PTSA; PTSB];% grouping points of intersection
            
            %---TRACE LENGTH (L) OF ENTIRE DISCONTINUITY (NOT CUTTED FROM
            %CW)
            
            L(i)=distancePoints3d(PTSA(1,:), PTSA(2,:));%ENTIRE TRACE OF DISCONTINUITY
            
            % Calculation of l, the cutted trace length, trace visble
            % inside the CW
            
            %calculation distance between sphere-line intersection points
            %and centers of discontinuity and CW
            %Point1
            d_point1A=distancePoints3d(PTSAB(1,:), xyz(i,:));
            d_point1B=distancePoints3d(PTSAB(1,:), xyz_CW);
            radiusB=radiusCW;
            
            %Mauldon method
            if ((-d_point1B+radiusCW)>0.0000)%if point are inside thw CW is counted as m
                m_mauldon(i)=1;
            else
                n_mauldon(i)=1; %else point are counted as n
            end
            
            if ((-d_point1A+radiusA(i))>-0.0005) && ((-d_point1B+radiusCW)>-0.0005)
                PTSAB(1,1)=PTSAB(1,1);
                PTSAB(1,2)=PTSAB(1,2);
                PTSAB(1,3)=PTSAB(1,3);
            else
                PTSAB(1,1)=NaN;
                PTSAB(1,2)=NaN;
                PTSAB(1,3)=NaN;
            end
            %Same procedure is done for all other 3 spheres-line intersection points calculated
            %Point 2
            d_point2A=distancePoints3d(PTSAB(2,:), xyz(i,:));
            d_point2B=distancePoints3d(PTSAB(2,:), xyz_CW);
            
            %Mauldon method
            if ((-d_point2B+radiusCW)>-0.0000)
                m_mauldon(i)=m_mauldon(i)+1;
            else
                n_mauldon(i)=n_mauldon(i)+1;
            end
            
            if ((-d_point2A+radiusA(i))>-0.0005) && ((-d_point2B+radiusB)>-0.0005)
                PTSAB(2,1)=PTSAB(2,1);
                PTSAB(2,2)=PTSAB(2,2);
                PTSAB(2,3)=PTSAB(2,3);
            else
                PTSAB(2,1)=NaN;
                PTSAB(2,2)=NaN;
                PTSAB(2,3)=NaN;
            end
            %Point 3
            d_point3A=distancePoints3d(PTSAB(3,:), xyz(i,:));
            d_point3B=distancePoints3d(PTSAB(3,:), xyz_CW);
            if ((-d_point3A+radiusA(i))>-0.0005) && ((-d_point3B+radiusB)>-0.005)
                PTSAB(3,1)=PTSAB(3,1);
                PTSAB(3,2)=PTSAB(3,2);
                PTSAB(3,3)=PTSAB(3,3);
            else
                PTSAB(3,1)=NaN;
                PTSAB(3,2)=NaN;
                PTSAB(3,3)=NaN;
            end
            %Point 4
            d_point4A=distancePoints3d(PTSAB(4,:), xyz(i,:));
            d_point4B=distancePoints3d(PTSAB(4,:), xyz_CW);
            if ((-d_point4A+radiusA(i))>-0.0005) && ((-d_point4B+radiusB)>-0.0005)
                PTSAB(4,1)=PTSAB(4,1);
                PTSAB(4,2)=PTSAB(4,2);
                PTSAB(4,3)=PTSAB(4,3);
            else
                PTSAB(4,1)=NaN;
                PTSAB(4,2)=NaN;
                PTSAB(4,3)=NaN;
            end
            
            %--Distances between the points
            d_pp13AB = distancePoints3d(PTSAB(1,:), PTSAB(3,:));
            d_pp14AB = distancePoints3d(PTSAB(1,:), PTSAB(4,:));
            d_pp23AB = distancePoints3d(PTSAB(2,:), PTSAB(3,:));
            d_pp24AB = distancePoints3d(PTSAB(2,:), PTSAB(4,:));
            
            % Erase similar point (save only 1 point for two or more
            % similar points)
            if (d_pp13AB<0.005 && d_pp24AB<0.0005)
                PTSAB(3,1)=NaN;
                PTSAB(3,2)=NaN;
                PTSAB(3,3)=NaN;
                PTSAB(4,1)=NaN;
                PTSAB(4,2)=NaN;
                PTSAB(4,3)=NaN;
                countedge(i,j)=1;
            end
            if (d_pp23AB<0.0005 && d_pp14AB<0.0005)
                PTSAB(3,1)=NaN;
                PTSAB(3,2)=NaN;
                PTSAB(3,3)=NaN;
                PTSAB(4,1)=NaN;
                PTSAB(4,2)=NaN;
                PTSAB(4,3)=NaN;
                countedge(i,j)=1;
            end
            
            
            
            
            % Select non-NaN values
            selectAB = ~isnan( PTSAB ) ;
            pointIntersecting=PTSAB(selectAB);
            
            npointIntersecting= (numel(pointIntersecting))/3;%count number of intersection points
            
            if  npointIntersecting==1 %if n. point int. =1 only a point of intersection between discont. and CW
                Point_intersection=[pointIntersecting(1), pointIntersecting(2), pointIntersecting(3)];
                
                drawPoint3d(Point_intersection,'marker', '+', 'markerSize', 10, 'linewidth', 3);
                
                if idx3(i)==j
                    countCWDisc_inter(i,j)=1;
                    
                end
                
                hold on
            end
            if npointIntersecting>1 %if point int. bigger than 1 a line of intersection are present
                Point_intersection=[pointIntersecting(1), pointIntersecting(3), pointIntersecting(5), pointIntersecting(2), pointIntersecting(4), pointIntersecting(6)];
                Point_intersCW_disc(i,1:6)=Point_intersection;
                
                
                
                
                
                initial_XYZ_CWplane(i,1:3)=[pointIntersecting(1), pointIntersecting(3), pointIntersecting(5)];
                final_XYZ_CWPlane(i,1:3)=[pointIntersecting(2), pointIntersecting(4), pointIntersecting(6)];
                
                X=[pointIntersecting(1); pointIntersecting(2)];
                Y=[pointIntersecting(3); pointIntersecting(4)];
                Z=[pointIntersecting(5); pointIntersecting(6)];
                
                %trace length included in CW
                l(i)=distancePoints3d([pointIntersecting(1), pointIntersecting(3), pointIntersecting(5)], [pointIntersecting(2), pointIntersecting(4), pointIntersecting(6)]);
                for j=1:nclu
                    if idx3(i)==j
                        drawEdge3d(Point_intersection, 'color', Color{j}, 'linewidth', 4);%plot lines of intersection
                        hold on
                        grid on
                        countCWDisc_inter(i,j)=2;
                        
                        filename_mod=strrep(filename,'.csv','');
                        %DXF names are saved in the same way
                        dxf_name=(['Set', num2str(idx3(i)),'_Trace',num2str(i),'_',num2str(filename_mod),'.dxf']);
                        FID=dxf_open(pathTraceMap,dxf_name);
                        FID = dxf_set(FID,'Color',Color{j});
                        dxf_polyline(FID, X, Y, Z);
                        dxf_close(FID);
                    end
                end
            end
            
        else
            
        end
        
    end
    
end
savefig(fullfile(pathIntersection,'CW_tracemap'))


%% CALULATION PARAMTERS (MTL, St.DEV, P21, mu, I, etc.)
L_corr=zeros(nplane, nclu);
l_corr=zeros(nplane, nclu);

for i=1:nplane
    for j=1:nclu
        if idx3(i)==j
            
            if countCWDisc_inter(i,j)==2
                l_corr(i,j)=l(i)';
                L_corr(i,j)=L(i)';
            else
                l_corr(i,j)=0;
                L_corr(i,j)=0;
            end
        end
    end
end
m_mauldon2=zeros(nplane, nclu);
n_mauldon2=zeros(nplane, nclu);

for i=1:nplane
    for j=1:nclu
        if idx3(i)==j
            m_mauldon2(i,j)=m_mauldon(i);
            n_mauldon2(i,j)=n_mauldon(i);
        end
    end
end

for j=1:(nclu)
    
    M_mauldon(1,j)=sum(m_mauldon2(:,j));
    N_mauldon(1,j)=sum(n_mauldon2(:,j));
end



for j=1:nclu
    if (M_mauldon(1,j)+N_mauldon(1,j))>(sum(countCWDisc_inter(:,j)))
        N_mauldon(1,j)=N_mauldon(1,j)-(M_mauldon(1,j)+N_mauldon(1,j)- sum(countCWDisc_inter(:,j)));
    end
end

for j=1:nclu
    mu(1,j)=((pi*radiusCW)/2)*(N_mauldon(1,j)/M_mauldon(1,j));
    I(1,j)=N_mauldon(1,j)/(4*radiusCW);
    density(1,j)=((pi*radiusCW)/2)*(M_mauldon(1,j)/radiusCW);
    P21(1,j)=sum(l_corr(:,j))/(pi*radiusCW^2);
end




for i=1:nplane
    for j=1:nclu
        if L_corr(i,j)==0
            L_corr(i,j)=NaN;
            l_corr(i,j)=NaN;
            
        end
    end
end

for j=1:nclu
    MTL2D(1,j)=nanmean(L_corr(:,j));
    stdev2D(1,j)=nanstd(L_corr(:,j));
end

for j=1:nclu
    max_Length2D_uncut(1,j)=max(L_corr(:,j));
    min_Length2D_uncut(1,j)=min(L_corr(:,j));
    max_length2D_cut(1,j)=max(l_corr(:,j));
    min_length2D_cut(1,j)=min(l_corr(:,j));
end

%% ------------------------- INTERSECTION ---------------------------------
countintersection=zeros(nplane,nplane);
countedge=zeros(nplane,nplane);
figure(5)
hold on




%this paragrpah works in the same way of the MTL 2D calulation
%(disconituinies are considered insetad CW).
for i= 1 : nplane-1
    for j= i+1 :nplane
        n1(i,:)=Nxyz(i,:);
        n2(j,:)=Nxyz(j,:);
        tol = 1e-14;
        
        % Uses Hessian form, ie : N.p = d
        % I this case, d can be found as : -N.p0, when N is normalized
        d1 = dot(n1(i,:), xyz(i,:), 2);
        d2 = dot(n2(j,:), xyz(j,:), 2);
        
        % compute dot products
        dot1 = dot(n1(i,:), n1(i,:), 2);
        dot2 = dot(n2(j,:), n2(j,:), 2);
        dot12 = dot(n1(i,:), n2(j,:), 2);
        
        % intermediate computations
        det= dot1*dot2 - dot12*dot12;
        c1= (d1*dot2 - d2*dot12)./det;
        c2= (d2*dot1 - d1*dot12)./det;
        
        % compute line origin and direction
        p0= c1*n1(i,:) + c2*n2(j,:);
        dp = cross(n1(i,:), n2(j,:), 2);
        % test if planes are parallel
        if abs(cross(n1(i,:), n2(j,:), 2)) < tol
            p0x(i,j)= NaN;
            p0y(i,j)= NaN;
            p0z(i,j)= NaN;
            dpx(i,j)= NaN;
            dpy(i,j)= NaN;
            dpz(i,j)= NaN;
            
        else
            
            p0x(i,j)= p0(1,1);
            p0y(i,j)= p0(1,2);
            p0z(i,j)= p0(1,3);
            dpx(i,j)= dp(1,1);
            dpy(i,j)= dp(1,2);
            dpz(i,j)= dp(1,3);
            line=[p0x(i,j), p0y(i,j), p0z(i,j), dpx(i,j), dpy(i,j), dpz(i,j)];
            
            point1= [xyz(i,1), xyz(i,2), xyz(i,3)];
            point2= [xyz(j,1), xyz(j,2), xyz(j,3)];
            dpointL_P1 = bsxfun(@rdivide, vectorNorm3d( ...
                vectorCross3d(line(:,4:6), bsxfun(@minus, line(:,1:3), point1)) ), ...
                vectorNorm3d(line(:,4:6)));
            dpointL_P2= bsxfun(@rdivide, vectorNorm3d( ...
                vectorCross3d(line(:,4:6), bsxfun(@minus, line(:,1:3), point2)) ), ...
                vectorNorm3d(line(:,4:6)));
            %define radius
            if CSV.data(i,9)>CSV.data(i,10)
                radius1=CSV.data(i,9)/2;
            else
                radius1=CSV.data(i,10)/2;
            end
            if CSV.data(j,9)>CSV.data(j,10)
                radius2=CSV.data(j,9)/2;
            else
                radius2=CSV.data(j,10)/2;
            end
            
            if dpointL_P1<radius1 && dpointL_P2<radius2
                
                select=zeros(4,4);
                %Define Sphere for Sphere-Line Intersection
                SPHERE1 = [xyz(i,1), xyz(i,2), xyz(i,3),  radius1];
                SPHERE2 = [xyz(j,1), xyz(j,2), xyz(j,3),  radius2];
                
                %Use Spehere-Line intersection function of geom3d package
                %(INRA)
                PTS1 = intersectLineSphere(line, SPHERE1);
                PTS2 = intersectLineSphere(line, SPHERE2);
                PTS=[PTS1; PTS2];
                
                %calcolo dei punti dalle sfere (es d_point11= distanza punto 1
                %da sfera 1)
                
                %Point1
                d_point11=distancePoints3d(PTS(1,:), xyz(i,:));
                d_point12=distancePoints3d(PTS(1,:), xyz(j,:));
                if (-d_point11+radius1)>-0.0005 && (-d_point12+radius2)>-0.0005
                    PTS(1,1)=PTS(1,1);
                    PTS(1,2)=PTS(1,2);
                    PTS(1,3)=PTS(1,3);
                else
                    PTS(1,1)=NaN;
                    PTS(1,2)=NaN;
                    PTS(1,3)=NaN;
                end
                %Point 2
                d_point21=distancePoints3d(PTS(2,:), xyz(i,:));
                d_point22=distancePoints3d(PTS(2,:), xyz(j,:));
                if (-d_point21+radius1)>-0.0005 && (-d_point22+radius2)>-0.0005
                    PTS(2,1)=PTS(2,1);
                    PTS(2,2)=PTS(2,2);
                    PTS(2,3)=PTS(2,3);
                else
                    PTS(2,1)=NaN;
                    PTS(2,2)=NaN;
                    PTS(2,3)=NaN;
                end
                %Point 3
                d_point31=distancePoints3d(PTS(3,:), xyz(i,:));
                d_point32=distancePoints3d(PTS(3,:), xyz(j,:));
                if (-d_point31+radius1)>-0.0005 && (-d_point32+radius2)>-0.005
                    PTS(3,1)=PTS(3,1);
                    PTS(3,2)=PTS(3,2);
                    PTS(3,3)=PTS(3,3);
                else
                    PTS(3,1)=NaN;
                    PTS(3,2)=NaN;
                    PTS(3,3)=NaN;
                end
                %Point 4
                d_point41=distancePoints3d(PTS(4,:), xyz(i,:));
                d_point42=distancePoints3d(PTS(4,:), xyz(j,:));
                if (-d_point41+radius1)>-0.0005 && (-d_point42+radius2)>-0.0005
                    PTS(4,1)=PTS(4,1);
                    PTS(4,2)=PTS(4,2);
                    PTS(4,3)=PTS(4,3);
                else
                    PTS(4,1)=NaN;
                    PTS(4,2)=NaN;
                    PTS(4,3)=NaN;
                end
                
                
                
                d_pp13 = distancePoints3d(PTS(1,:), PTS(3,:));
                d_pp14 = distancePoints3d(PTS(1,:), PTS(4,:));
                d_pp23 = distancePoints3d(PTS(2,:), PTS(3,:));
                d_pp24 = distancePoints3d(PTS(2,:), PTS(4,:));
                
                % Eliminare i punti 3 e 4 se coindidono con 1 e 2
                if (d_pp13<0.005 & d_pp24<0.0005)
                    PTS(3,1)=NaN;
                    PTS(3,2)=NaN;
                    PTS(3,3)=NaN;
                    PTS(4,1)=NaN;
                    PTS(4,2)=NaN;
                    PTS(4,3)=NaN;
                    countedge(i,j)=1;
                end
                if (d_pp23<0.0005 & d_pp14<0.0005)
                    PTS(3,1)=NaN;
                    PTS(3,2)=NaN;
                    PTS(3,3)=NaN;
                    PTS(4,1)=NaN;
                    PTS(4,2)=NaN;
                    PTS(4,3)=NaN;
                    countedge(i,j)=1;
                end
                
                % selezionare solo i valori non nulli
                select = ~isnan( PTS ) ;
                pointIntersecting=PTS(select);
                
                npointIntersecting= (numel(pointIntersecting))/3;
                
                if  npointIntersecting==1
                    Point_intersection=[pointIntersecting(1), pointIntersecting(2), pointIntersecting(3)];
                    
                    drawPoint3d(Point_intersection,'marker', '+', 'markerSize', 10, 'linewidth', 3);
                    hold on
                end
                if npointIntersecting>1
                    Point_intersection=[pointIntersecting(1), pointIntersecting(3), pointIntersecting(5), pointIntersecting(2), pointIntersecting(4), pointIntersecting(6)];
                    figure(5)
                    drawEdge3d(Point_intersection, 'color', 'r', 'linewidth', 4);
                    hold on
                    countedge(i,j)=1;
                    
                    X=[pointIntersecting(1); pointIntersecting(2)];
                    Y=[pointIntersecting(3); pointIntersecting(4)];
                    Z=[pointIntersecting(5); pointIntersecting(6)];
                    
                    filename_mod=strrep(filename,'.csv','');
                    dxf_name=(['Intersec',num2str(i),'_',num2str(j),'_',num2str(filename_mod),'.dxf']);
                    FID=dxf_open(pathIntersection,dxf_name);
                    FID = dxf_set(FID,'Color',[1 0 0]);
                    dxf_polyline(FID, X, Y, Z);
                    dxf_close(FID);
                end
                
                
                
                
                
                %                 drawLine3d(line, 'color', 'y', 'linewidth', 2);
                %                 hold on
                
                countintersection(i,j)=1;
                
                
                
            else
                countintersection(i,j)=0;
                countedge(i,j)=0;
            end
            
        end
    end
    
    
end
% Save matlab figure of fracture trace on circular window
savefig(fullfile(pathIntersection,'FractureIntersection'))

n_intersection=nnz(countintersection);
ncountedge=nnz(countedge);
Int_set=zeros(1,nclu);
for i=1:nplane
    for j=1:nplane
        for k=1:nclu
            if idx3(i)==k && countintersection(i,j)==1
                Int_set(1,k)=Int_set(1,k)+1;
            end
            if idx3(j)==k && countintersection(i,j)==1
                Int_set(1,k)=Int_set(1,k)+1;
            end
        end
    end
end

%% WRITE AND SHOW RESULTS
disp(['########## General Information ############'])
disp(['Total N. of Plane,      ', num2str(nplane, '%3.2f')])
disp(['Total N. Intersections, ', num2str(ncountedge, '%3.2f')])
for j=1:nclu
    disp(['################ Set ', num2str(j),' #####################'])
    disp(['Plane N.,           ', num2str(N_SetPlane(j), '%3.2f')])
    disp(['DipDir,             ', num2str(dipdireigv(j), '%3.2f')])
    disp(['Dip,                ', num2str(dipeigv(j), '%3.2f')])
    disp(['K Fisher`s coeff.,  ', num2str(K_fisher(j), '%3.2f')])
    disp('--------3D Trace Length Analysis-----------')
    disp(['MTL3D norm,         ', num2str(MTL3D_norm(j), '%3.2f')])
    disp(['St.Dev.norm,        ', num2str(st_dev3D_norm(j), '%3.2f')])
    disp(['Max L. norm,        ', num2str(max_length_norm(j), '%3.2f')])
    disp(['Min L. norm,        ', num2str(min_length_norm(j), '%3.2f')])
    disp(['MTL3D diag,         ', num2str(MTL3D_diag(j), '%3.2f')])
    disp(['St.Dev.diag,        ', num2str(st_dev3D_diag(j), '%3.2f')])
    disp(['Max L. diag,        ', num2str(max_length_diag(j), '%3.2f')])
    disp(['Min L. diag,        ', num2str(min_length_diag(j), '%3.2f')])
    disp(['N. Intersections,   ', num2str(Int_set(j), '%3.2f')])
    disp('--------2D Trace Length Analysis-----------')
    disp(['MTL2D,              ', num2str(MTL2D(j), '%3.2f')])
    disp(['St.Dev.norm,        ', num2str(stdev2D(j), '%3.2f')])
    disp(['Max L. uncut,        ', num2str(max_Length2D_uncut(j), '%3.2f')])
    disp(['Min L. uncut,        ', num2str(min_Length2D_uncut(j), '%3.2f')])
    disp(['p21,                ', num2str(P21(j), '%3.2f')])
    disp(['Max L. cut,        ', num2str(max_length2D_cut(j), '%3.2f')])
    disp(['Min L. cut,        ', num2str(min_length2D_cut(j), '%3.2f')])
    disp('----Mauldon Estimators (2D analysis)-------')
    disp(['MeanTraceLengt (mu),', num2str(mu(j), '%3.2f')])
    disp(['Trace Intensity (I),', num2str(I(j), '%3.2f')])
    disp(['Trace Density (ro), ', num2str(density(j), '%3.2f')])
    disp('')
end

%Rewrite string of value in way that matlab could export a xls file
total_plane=zeros(nclu,1);
total_plane(1,1)=nplane;
total_intersection=zeros(nclu,1);
total_intersection(1,1)=ncountedge;
N_SetPlane=N_SetPlane';
dipdireigv=dipdireigv';
dipeigv=dipeigv';
K_fisher=K_fisher';
MTL3D_norm=MTL3D_norm';
% st_dev3D_norm=st_dev3D_norm';
max_length_norm=max_length_norm';
min_length_norm=min_length_norm';
MTL3D_diag=MTL3D_diag';
st_dev3D_diag=st_dev3D_diag';
max_length_diag=max_length_diag';
min_length_diag=min_length_diag';
Int_set=Int_set';
MTL2D=MTL2D';
stdev2D=stdev2D';
max_Length2D_uncut=max_Length2D_uncut';
min_Length2D_uncut=min_Length2D_uncut';
P21=P21';
max_length2D_cut=max_length2D_cut';
min_length2D_cut=min_length2D_cut';
mu=mu';
I=I';
density=density';
%CSV_printMatrix=['Plane N.','DipDir ','Dip','MTL3D norm','Max L. norm','Min L. norm','MTL3D diag','St.Dev.diag', 'Max L. diag','Min L. diag','N. Intersections','MTL2D','St.Dev.norm','Max L. norm','Min L. norm','p21','MeanTraceLengt (mu)','Trace Intensity (I)','Trace Density (ro)';
%    N_SetPlane',dipdireigv',dipeigv',MTL3D_norm',st_dev3D_norm',max_length_norm',min_length_norm',MTL3D_diag',st_dev3D_diag',max_length_diag',min_length_diag',Int_set',MTL2D',st_dev3D_norm',max_length_norm',min_length_norm',P21',mu',I',density']

T = table(total_plane,        total_intersection, N_SetPlane,     dipdireigv,...
    dipeigv, K_fisher,   MTL3D_norm,         st_dev3D_norm',  max_length_norm,...
    min_length_norm,    MTL3D_diag,         st_dev3D_diag,  max_length_diag,...
    min_length_diag,    Int_set,            MTL2D,          stdev2D,...
    max_Length2D_uncut, min_Length2D_uncut, P21,            max_length2D_cut,...
    min_length2D_cut,   mu,                 I,              density);
tablefilename = (['Matlab_analysis.xlsx']);
writetable(T,fullfile(pathIntersection, tablefilename));


%% REFERENCES
% 1) Markovaara-Koivisto, M., & Laine, E. (2012). MATLAB script for analyzing and visualizing scanline data. Computers & Geosciences, 40, 185-193.