function draw3Dintersection(PC,P_interA,Nxyz, xyz, radius, filename, nplane, pathname, Set, in_out)
% DESCRIPTION: %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function draw and save the 3D intersection between discontinuties
% and the 3D scanplane and save also the intersection.
%--------------------------------------------------------------------------
% INPUT VARIABLES:
%   PC = matrix that contain the Point Cloud segmented  
%   Set = vector that express the set of each discontinuity
%   nplane = number of plane;
%   P_interA = Matrix containg the end point of the intersection traces;
%   xyz,Nxyz,radius = center coordinates, normal components and radius of 
%                     the circular planes;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pcshow(PC);
hold on
xlabel('X(East)')
ylabel('Y(Nord)')
zlabel('Z(Elev)')
axis equal
hold on
grid on
box on
Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};
for i=1:nplane
    if in_out(i)>0
        
        figure(4)
        
        drawEdge3d(P_interA(i,:), 'color', Color{Set(i)}, 'linewidth', 4);%plot lines of intersection
        
        hold on
        
        
        theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
        v=null(Nxyz(i,:));% calculate vectors needed to plot the discs
        points=repmat(xyz(i,:)',1,size(theta,2))+radius(i)*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
        
        % Change name to the coordinate in a better and more resonable name
        X=points(1,:)';
        Y=points(2,:)';
        Z=points(3,:)';
        fill3(points(1,:),points(2,:),points(3,:),Color{Set(i)}, 'FaceAlpha', 0.5);%Plot 3D disc for each plane
        % With the below loop matlab could export DXF with different color in base
        % of set
        for j=1:max(Set)
            if Set(i)==j
                % use DXFLib, Version 0.9.1 (Copyright (c) 2009-2011 Grzegorz Kwiatek)
                % to export DXF for each plane
                filename_mod=filename(1:end-4);
                % name is written in this way:
                % (number of set)_CircPlane_(number of row in CSV matrix)_(name of CSV file).dxf
                dxf_name=(['Set',num2str(Set(i)),'Disc',num2str(i),'.dxf']);
                if ispc
                FID=dxf_open(fullfile(pathname,(['IntersSetsDisc\Set_', num2str(j)])),dxf_name);
                elseif ismac
                FID=dxf_open(fullfile(pathname,(['IntersSetsDisc/Set_', num2str(j)])),dxf_name);  
                end
                FID = dxf_set(FID,'Color',Color{j});
                dxf_polyline(FID, X, Y, Z);
                dxf_close(FID); % end of DXF exportation
            end
        end
        
    end
end