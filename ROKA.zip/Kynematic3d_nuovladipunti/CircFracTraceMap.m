function [L, P_interA, SP_inters] = CircFracTraceMap(nplane,xyz, Nxyz, SP_xyz, SP_Nxyz, radius)
% DESCRIPTION:%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   CircFracTraceMap function calculates intersection between a scan plane
%   (infinite) and the circular fracture plane (finite);
%   This function works in this way:
%       1) it calculates intersection line between scan planes and fracture
%          plane considering both as infinite;
%       2) calculate the intersection points of the intersection line
%          (previously calulated) and a sphere with center and radius 
%          equal to those of the circular fracture considered
%--------------------------------------------------------------------------
% INPUT VARIABLES:
%   nplane = number of planes/discontinuties;
%   xyz,Nxyz,radius = center coordinates, normal components and radius of 
%                     the circular planes;
%   SP_xyz,SP_Nxyz = center and normal components of the infinite scan 
%                    plane.
%--------------------------------------------------------------------------
% OUTPUT VARIABLES:
%   L = trace length (L) of the intersection Discontinuity-ScanPlane
%   P_interA = matrix containg the end point of the intersection traces;
%   SP_inters = matrix containg the logical value of the intersection
%               fracture-scanplane (0 = no intersection; 1 = intersection) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Pre-allocating variables memory
nA=zeros(nplane,3);
p0ABx = zeros(nplane,1);
p0ABy = zeros(nplane,1);
p0ABz = zeros(nplane,1);
dpABx = zeros(nplane,1);
dpABy = zeros(nplane,1);
dpABz = zeros(nplane,1);
lineAB = zeros(nplane,6);
point1AB = zeros(nplane,3);
P_interA = zeros(nplane,6);
dpointL_PA = zeros(nplane,1);
L = zeros(nplane,1);
SP_inters = zeros(nplane,1);
    for i=1:nplane
    nA(i,:)=Nxyz(i,:);% Normal vector of discontinuity
    nB=SP_Nxyz;% Circular Window normal
    tol = 1e-14;% setting the angle cutoff for which pseudo parallel planes 
                % (parallel at the CW plane) are not consider.
    
    %The string below are copied from the "Geom3D" code (Copyright (c) 2016,
    %INRA) and modified in order to permit calulation of trace lenth and
    %ntersection with the circular window needed in Mauldon method
    
    % Uses Hessian form, ie : N.p = d
    % I this case, d can be found as : -N.p0, when N is normalized
    dA = dot(nA(i,:), xyz(i,:), 2);
    dB = dot(nB, SP_xyz, 2);
    
    % compute dot products
    dotA = dot(nA(i,:), nA(i,:), 2);
    dotB = dot(nB, nB, 2);
    dotAB = dot(nA(i,:), nB, 2);
    
    % intermediate computations
    detAB= dotA*dotB - dotAB*dotAB;
    cA= (dA*dotB - dB*dotAB)./detAB;
    cB= (dB*dotA - dA*dotAB)./detAB;
    
    % compute line origin and direction
    p0AB= cA*nA(i,:) + cB*nB;
    dpAB = cross(nA(i,:), nB, 2);
    
    % test if planes are parallel
    if abs(cross(nA(i,:), nB, 2)) < tol
        p0ABx(i)= NaN;
        p0ABy(i)= NaN;
        p0ABz(i)= NaN;
        dpABx(i)= NaN;
        dpABy(i)= NaN;
        dpABz(i)= NaN;
        
    else
        
        p0ABx(i)= p0AB(1,1);
        p0ABy(i)= p0AB(1,2);
        p0ABz(i)= p0AB(1,3);
        dpABx(i)= dpAB(1,1);
        dpABy(i)= dpAB(1,2);
        dpABz(i)= dpAB(1,3);
        
        lineAB(i, 1:6)=[p0ABx(i), p0ABy(i), p0ABz(i), dpABx(i), dpABy(i), dpABz(i)];%%Infinite line representing intersection between two infinte planes of discontinuity and CW
        
        point1AB(i,:)= xyz(i,:);% Center of discontinuity
        %point2AB= SP_xyz;% center of Circular Window
        
        %Distance between disconintuity center and previous intersection line
        dpointL_PA(i) = bsxfun(@rdivide, vectorNorm3d( ...
            vectorCross3d(lineAB(i,4:6), bsxfun(@minus, lineAB(i,1:3), point1AB(i,:))) ), ...
            vectorNorm3d(lineAB(i,4:6)));
        
        
        if dpointL_PA(i)<radius(i)
            
            
            %Define Sphere (fitted for the 2 considered discs) for Sphere-Line Intersection
            SPHEREA = [xyz(i,1), xyz(i,2), xyz(i,3),  radius(i)];
            
            
            %Use Spehere-Line intersection function of geom3d package
            %(INRA) to find points of intersection
            PTSA= intersectLineSphere(lineAB(i,:), SPHEREA);% for line and discontinuity sphere
            P_interA(i,1:6)=[PTSA(1,1:3), PTSA(2,1:3)];
            
            
            
            %Trace length (L) of the discontinuity intersection            
            L(i)=distancePoints3d(PTSA(1,:), PTSA(2,:));
            SP_inters(i)=1;
        else
            SP_inters(i)=0;
        end
    end
    end
    
end

