function [in_out] = planeinsidewindow(nplane,v1,v2,v3,v4,A_SP,SP_inters,P_interA,xyz,Nxyz,radius)
% DESCRIPTION: %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function calculates the intersections of the discontinuties with the
% limited and rectangular window (Scan Plane).
%--------------------------------------------------------------------------
% INPUT VARIABLES:
%   nplane = number of plane;
%   v1,v2,v3,v4 = vertices of the rectangular window, also called Scan 
%                 Plane (SP);
%   A_SP =area of the SP;
%   SP_Inters = logical vector of intersection discontinuties-SP (0 = no
%               intersection; 1 = intersection);
%   P_interA = Matrix containg the end point of the intersection traces;
%   xyz,Nxyz,radius = center coordinates, normal components and radius of 
%                     the circular planes;
%--------------------------------------------------------------------------
%OUTPUT VARIABLES:
% in_out is the vector containg the type of intersection between 
% discontinuties and SP:
%           in_out = 1 -->type 1, intersection end-points are inside the
%                         window;
%           in_out = 2 -->type 2, one intersection end-point is inside the 
%                         window and the other is outside;       
%           in_out = 3 -->type 3, intersection end-points are outside the 
%                         window
%           
%           in_out = 0 means that the discontintuy does not intersect the
%           scan plane.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pre-allocating variable memeory
in_out=zeros(nplane,1);

% Calculation
for i=1:nplane %Selection of plane inside the rectangular window;
    
    if SP_inters(i)==1
        %define type of intersection 1, 2 and 3
        clearvars A1_12 A1_13 A1_24 A1_34 A2_12 A2_13 A2_24 A2_34 point12 point13 point24 point34 fracplane
        [A1_12, A1_13, A1_24, A1_34]=SPtriangle(v1,v2,v3,v4,P_interA(i,1:3));
        [A2_12, A2_13, A2_24, A2_34]=SPtriangle(v1,v2,v3,v4,P_interA(i,4:6));
        sumA1=sum([A1_12, A1_13, A1_24, A1_34]);
        sumA2=sum([A2_12, A2_13, A2_24, A2_34]);
        if  round(sumA1,3) == round(A_SP,3) && round(sumA2,3) == round(A_SP,3)
            
            in_out(i)=1;%type 1--> both intersection end-points are inside the window
            
        elseif (round(sumA1,3) > round(A_SP,3) && round(sumA2,3) == round(A_SP,3)) || (round(sumA1,3) == round(A_SP,3) && round(sumA2,3) > round(A_SP,3))
            in_out(i)=2;%type 2--> an intersection end-point is inside the window and the other is outside
        else
            %type of intersection 3 (both end-points outside the window
            fracplane=createPlane(xyz(i,:), Nxyz(i,:));
            point12 = intersectEdgePlane([v1,v2], fracplane);
            point13 = intersectEdgePlane([v1,v3], fracplane);
            point24 = intersectEdgePlane([v2,v4], fracplane);
            point34 = intersectEdgePlane([v3,v4], fracplane);
            d12=dist2points(xyz(i,:), point12);
            d13=dist2points(xyz(i,:), point13);
            d24=dist2points(xyz(i,:), point24);
            d34=dist2points(xyz(i,:), point34);
            if d12 <= radius(i) || d13 <= radius(i) || d24 <= radius(i) || d34 <= radius(i)
                in_out(i)=3;
            else
                in_out(i)=0;
            end
        end
    elseif SP_inters(i)==0
        in_out(i)=0;
        
    end
end