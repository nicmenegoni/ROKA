% number of points
n = size(points, 1);

% compute centroid
center = mean(points);

% compute the covariance matrix
covPts = cov(points)/n;

% perform a principal component analysis with 2 variables, 
% to extract inertia axes
[U, S] = svd(covPts);
% extract length of each semi axis
radii = sqrt(5) * sqrt(diag(S)*n)';
quiver3(center(1),center(2),center(3),U(1,1),U(1,2),U(1,3))
maxdir=U(:,1)';%direction of maximum axis
maxmagn=radii(1);%magnitude of max semiaxis
mindir=U(:,2)';%direction minimum axes
minmagn=radii(2);%magn. of min axis
maxvector=maxmagn*maxdir;
minvector=minmagn*mindir;
figure(2)
hold on
v1=center-maxvector+minvector;
v2=center-maxvector-minvector;
v3=center+maxvector+minvector;
v4=center+maxvector-minvector;
scatter3(v1(1),v1(2),v1(3))
scatter3(v2(1),v2(2),v2(3))
scatter3(v3(1),v3(2),v3(3))
scatter3(v4(1),v4(2),v4(3))



% Sketch of 2D polygon
% 1_______2
% |\      |
% | \     |
% |  \    |
% |   \   |      -->minvector
% |    \  |     |
% |     \ |     |
% |_______|     v
% 3       4     maxvector
%
%the area of the polygon is equal at the area of the two triangles
ons = [1 1 1];
A_scanplane = maxmagn*minmagn;

A_scanplane1 = 0.5*sqrt(det([v1(1),v2(1),v3(1);v1(2),v2(2),v3(2);ons])^2 +...
                        det([v1(2),v2(2),v3(2);v1(3),v2(3),v3(3);ons])^2 +...
                        det([v1(3),v2(3),v3(3);v1(1),v2(1),v3(1);ons])^2)%area triangle 1-2-3
A_scanplane2 = 0.5*sqrt(det([v1(1),v2(1),v4(1);v1(2),v2(2),v4(2);ons])^2 +...
                        det([v1(2),v2(2),v4(2);v1(3),v2(3),v4(3);ons])^2 +...
                        det([v1(3),v2(3),v4(3);v1(1),v2(1),v4(1);ons])^2)%area triangle 1-2-4
            


