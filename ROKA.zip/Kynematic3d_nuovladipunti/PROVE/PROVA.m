

tic
rn=randi([1 length(PC(:,1))],1,10000);
for i = 1:length(rn)
[idxKrn, ptdistrn] = findNearestNeighbors(ptCloud,PC(rn(i),:),5);
meandrn(i)=mean(ptdistrn(2:end));
end
Arn=pi *mean(meandrn)^2;
ptRho=5/Arn;
toc
figure(1)
subplot(2,1,1)
histogram(meandrn)
xlim([0.2 0.4])

tic
userSPr=10;
Auser=pi * userSPr^2;
reqKnn=ceil(Auser*1.65*(ptRho));
for i = 1:length(rn)
[idxK, ptdist] = findNearestNeighbors(ptCloud,PC(rn(i),:),reqKnn);
meand(i)=mean(ptdist(2:end));
end
toc
figure(1)
subplot(2,1,2)
histogram(meand)
mean(meand)


for i = 1:10000
    