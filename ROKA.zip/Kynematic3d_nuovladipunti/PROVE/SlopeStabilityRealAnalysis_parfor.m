%% Informazioni 11/12/2018
%
%DA MIGLIORARE:
% 1)    creare funzione per salvare i risultati in modo da rendere pi�
%       leggibile il codice;
% 2)    Il codice fuinziona perfettamente,
%       � presente solo un problema:
%       - in presenza di parete che hanno un'immerisone negativa (immergono
%       verso l'interno della parete, es. faccia 1 pinnacolo 2b) l'analisi
%       cinematica non avviene in maniera propria, in quanto l'orientazione
%       che viene calcolata � quella della faccia negativa.
%       N.B. queste pareti sono le 'ovehanging slope'
%        ________________________________________
%       |Sketch delle porzioni problematiche     | 
%       |                                        |
%       |                     piano campagna     |
%       |                _____v_________________ |
%       |                \                       |
%       |                 \                      |
%       | _______v_________\                     |
%       |                                        |
%       |________________________________________|
%
%% Mods timeline
% 2020/05/18   The modality for the exportation of the results will be
% changed in order to simplify the calculation. In particularduring the
% calculation of the KA for all the points of the PC, the critical
% disconinuity will be exported only at the end of all the calculation.
% Their 'criticality' will be signed into a matrix composed by n rows (as
% the disconinuity) and 5 columns (as Planar Sliding, WS, FT, OT, DT).
% Moreover, the criticality will be stored also onto the PointCloud, but it
% will be not distinguished in low and high criticallity--> it will be
% equal to the number of critical disconinuities.
%
% 20/04/27  (1) the possiblity to select the Knn of the points of the cloud
% is implemented using a Matlab function ('findNearestNeighbors') embedded 
% the Matlab software since the version 2015a. This function will be used
% to select the Knn and to calculate the local attitude of the slope.
%           (2) the scanplanecalc function is removed, because now it is
%           used a scan disc with a radius in function of the Knn.
%           (3) the transformation matrix requrments is removed: you must
%           insert the Pointcloud and the measurments in a local coordinate
%           system.
% 2019/10/30 - last tested version 

%% SLOPE STABILITY REAL ANALYSIS
close all; clear variables; tic

%% 0) DEFINITION OF SOME PARAMETERS
% Set the correct number for the K-nearest neighnour
Knn=2000;%define the number of K-nearest neighbour points

% Define if you use the lateral limits or not, and give a value
uselatlimits=1;% YES=1 and NO=0
latlimits=20;%Godmann report 20�
frictionangle=30;%Define the friction angle

%Define if you want to export all the disconinuity intersection (also the
%not crtitical)
export_AllIntersection=0;

%Load fractures and scanline informations
%% 1) IMPORT FRACTURE GEOMETRY DATA
%This Matlab code works using a xlsx file in which xyz (center), Nxyz
%(orientation) and radius (dimension) of the discontinuities are stored.
uiwait(msgbox('Select fracture geometry data (XLSX file) to load'));
[filename, pathname] = uigetfile({'*.xlsx', 'Select fracture geometry data (XLSX file) to load'},'Select fracture geometry data (XLSX file) to load',...
    'F:\Menegoni\Ormea\Nuovi voli giugno 2017\Albris_SenseFly\parete\pointcloud\specific_KynAnalysis');% <- MODIFY the PATH

Fracdata=readtable(fullfile(pathname, filename));%read  fracture data stored 
%in the previously defined XLSX file.

%% 2) IMPORT FRACTURE SET DATA
uiwait(msgbox('Select Fracture set data (XLSX file) to load'));
[filenameset, pathnameset] = uigetfile({'*.xlsx', 'Select Fracture set data (XLSX file) to load'},...
    'Select Fracture set data (XLSX file) to load',...
    pathname);
Fracset=readtable(fullfile(pathnameset, filenameset));%read fracture set 
%stored in the previously defined XLSX file.



%% 3) DEFINE DISCONTINUITES VARIABLES FOR CALCULATION
nplane=numel(Fracdata.Dip);%number of fractures/discontinuity planes)
xyz=[Fracdata.Xcenter(:),Fracdata.Ycenter(:),Fracdata.Zcenter(:)];
Nxyz=[Fracdata.Nx(:),Fracdata.Ny(:),Fracdata.Nz(:)];
dipdir =  Fracdata.DipDirection(:);%Fracture dip direction
dip =  Fracdata.Dip(:);%fracture dip angle
radius = Fracdata.Radius(:);
Set = Fracset.Set;% Fracture set (defined in the imported xlsx file)
Set(isnan(Set)) = max(Set)+1;% Definition of the random set (not defined in the imported xslx file)
Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};% define color for set from 1 to 7
%For what concern the color it is ossible to increase the number of sets


if export_AllIntersection==1
    if ispc
        for j=1:max(Set)
            mkdir (pathname,(['IntersSetsDisc\Set_', num2str(j)]))
        end
    elseif ismac
        for j=1:max(Set)
            mkdir (pathname,(['IntersSetsDisc/Set_', num2str(j)]))
        end
    end
end
%% 6) IMPORT AND READ  THE POINTCLOUD
uiwait(msgbox('Select PointCloud  (TXT file) to load'));
[PCfn,PCpn]=uigetfile({'*.txt', 'Select PointCloud  (TXT file) to load'},'Select PointCloud  (TXT file) to load',...
    pathname);%Import the path point cloud txt file
PC=importdata(fullfile(PCpn,PCfn));%import and read the pont cloud
ptCloud=pointCloud(PC);
%% Pre calculation definition
%Creating a Critical Disconinuity Matrix (CDM)
CDM=zeros(nplane,2);
nCritic = zeros(length(PC(:,1)),5);

%Creating some matrix containing the dip and dip direction of the
%disconinuity planes and the trend and plung of the disconinuity
%intersections
%Intersection definitions
disp('Starting to calculate all the disconinuities intersections')
[Int_data]=intersectionCalculator(pathname,Fracdata,Fracset,export_AllIntersection);%matrix contating all the information about the disconinuity intersections
disp('End of the calculation of the disconinuities intersections ')
num_Int=numel(Int_data.Trend);
CIM=zeros(num_Int,3);% Creating a Critical Intersection Matrix (CIM)
Trend=Int_data.Trend;
Plunge=Int_data.Plunge;
Int_Sets(:,1)=Int_data.Set_i;
Int_Sets(:,2)=Int_data.Set_j;
pole_Trend = zeros(num_Int,1);%pre-allocating the intersection trend vector
pole_Plunge = zeros(num_Int,1);%pre-allocating the intersection plunge vector
for i= 1 : num_Int %calculate discontinuity line pole (dip and dip direction)
    %this is an trick to plot plunge and trend line vector
    pole_Plunge(i,1) = 90 - Plunge(i);%discontinuity pole dip
    if Trend(i) < 180%discontinuity pole dip direction
        pole_Trend(i,1) = Trend(i) + 180;
    else
        pole_Trend(i,1) = Trend(i) - 180;
    end 
end
%Disconinuity definition
Dip=Fracdata.Dip(:);%read Dip value of discontinuities
DipDir=Fracdata.DipDirection(:);%read Dip Direction value of discontinuities
Set=Fracset.Set(:);%read Set value of discontinuities (random values are defined as NaN as default)
Set(isnan(Set))=0;%change Set value of random discontinuities from NaN to 0
Set_name=unique(Set);
nSet=numel(unique(Set));
pole_Dip=zeros(nplane,1);
pole_DipDir=zeros(nplane,1);
for i= 1 : nplane %calculate discontinuity line pole (dip and dip direction)
    %this is an trick to plot plunge and trend line vector
    pole_Dip(i,1) = 90 - Dip(i);%discontinuity pole dip
    if DipDir(i) < 180%discontinuity pole dip direction
        pole_DipDir(i,1) = DipDir(i) + 180;
    else
        pole_DipDir(i,1) = DipDir(i) - 180;
    end
end


%% Loop KA
h = waitbar(0,'Please wait...');%creating a status bar
for ptloop= 1: length(PC(:,1)) %define a loop foe every point of the cloud
if ptloop/100 == ceil(ptloop/100)
disp(['Point number ', num2str(ptloop)])
end
clearvars idxK A_SP SP_N SP_center v1 v2 v3 v4

[idxK] = findNearestNeighbors(ptCloud,PC(ptloop,:),Knn);%calculate the index of the Knn points.
% the idxK indicates the position of the Knn points inside the PC matrix;
SPpoints =PC(idxK,1:3);%deinfe the points belonging to the scan area (based on Knn algorithm)

[A_SP, SP_N, SP_center, v1, v2, v3, v4] = scanplanecalc(SPpoints);%calculate the scan plane

%a) calculating intersection between discontinuties and the infinite scan plane;
[L, P_interA, SP_inters]= CircFracTraceMap(nplane,xyz, Nxyz, SP_center, SP_N, radius);%find intersection with an infinitre plane
%b) calculating intersection between discontinties and finite scan plane
[in_out] = planeinsidewindow(nplane,v1,v2,v3,v4,A_SP,SP_inters,P_interA,xyz,Nxyz,radius);
[int_in_out] = lineinsidewindow(num_Int,v1,v2,v3,v4,A_SP,SP_N,SP_center,Int_data);
[CDM,CIM,nCritic(i,1:5)]=KynematicAnalysis(Fracset,Int_data, SP_N,CDM,CIM,uselatlimits,latlimits,frictionangle,in_out,int_in_out);  
end
waitbar(ptloop / length(PC(:,1)))

%Exporting Critical Discontinuites and Intersections
expAnalysis(pathname,Fracdata,Fracset,Int_data,CDM,CIM,PC,nCritic,uselatlimits)



disp('#######################')
disp('END OF TOTAL PROCESSES')
toc
disp('#######################')




% % % % %% 4) DEFINE MEAN ORIENTATIONS OF THE SETS and DRAW STEREOPLOTS
% % % % %Here, you can re-define the fracture sets
% % % % %Steroplot of poles of disconinuities--------------------------------------
% % % % [xp, yp]=Stereogram_colourless_Schmidt(dipdir, dip, nplane);
% % % % %load file xlsx in which set mean orientations are defined
% % % % uiwait(msgbox('Select Mean Orientation of Set data (XLSX file) to load'));
% % % % [filenameset, pathnameset] = uigetfile({'*.xlsx', 'Select Mean Orientation of Set data (XLSX file) to load'},'Select Mean Orientation of Set data (XLSX file) to load',...
% % % %     pathnameset);
% % % % MeanOrient=readtable(fullfile(pathnameset, filenameset));
% % % % 
% % % % DipDirDipClu=zeros(length(MeanOrient.Set),2);
% % % % for i=1:length(MeanOrient.Set) %Cycle to insert Set mean DipDirection and Dip
% % % %     DipDirDipClu (i,:) = [MeanOrient.MeanDipDirection(i),MeanOrient.MeanDip(i)];
% % % % end
% % % % nclu=length(MeanOrient.Set);
% % % % %Calculate Normal vector of Mean Orientation
% % % % 
% % % % V=zeros(1,3,nclu);
% % % % O=zeros(1,3,nclu);%CONTOLLARE
% % % % for r=1:nclu
% % % %     % Unit vector V, which origin is at the origo, in the orientation of the
% % % %     % dip/dip direction
% % % %     
% % % %     V(:,:,r)=[cosd(90-DipDirDipClu(r,1))*cosd(DipDirDipClu(r,2)) sind(90-DipDirDipClu(r,1))*cosd(DipDirDipClu(r,2)) -sind(DipDirDipClu(r,2))];
% % % %     % Unit vector O, which origin is at the origo, which is perpendicular to
% % % %     % the dip diprecion and is horizontal
% % % %     O(:,:,r)=[-sind(90-DipDirDipClu(r,1)) cosd(90-DipDirDipClu(r,1)) 0];
% % % % end
% % % % % Normal vector N of the surface defined with the vectors V and O
% % % % Nclu=zeros(nclu,3);
% % % % 
% % % % for k=1:nclu
% % % %     Nclu(k,:)=cross(V(:,:,k),O(:,:,k));
% % % % end
% % % % figure(3)
% % % % [xshp,yshp,zshp]=sphere;
% % % % 
% % % % s = surf(xshp,yshp,zshp,'FaceAlpha',0.3);
% % % % s.EdgeColor = 'none';
% % % % hold on
% % % % for i=1:nclu
% % % %     quiver3(0,0,0,-Nclu(i,1),-Nclu(i,2),-Nclu(i,3))
% % % %     hold on
% % % % end
% % % % legend('sphere','1','2','3','4')
% % % % axis equal
% % % % xlabel('East')
% % % % ylabel('North')
% % % % zlabel('Up')
% % % % view(0,90)
% % % % new_Nclu=Nclu;
% % % % 
% % % % % Draws the automated clustering results (kmeans-method) on a Schmidt's equal area net
% % % % Stereogram(dipdir, dip, nplane, Set, xp, yp)